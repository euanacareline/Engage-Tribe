import {
  users,
  socialMetrics,
  activities,
  achievements,
  connections,
  blogPosts,
  newsletterLeads,
  aiToolsUsage,
  socialAccounts,
  socialPosts,
  engagementActions,
  pointLedger,
  tokenUsageLogs,
  staffRoles,
  salaryHistory,
  timeclock,
  type User,
  type UpsertUser,
  type SocialMetrics,
  type InsertSocialMetrics,
  type Activity,
  type InsertActivity,
  type Achievement,
  type InsertAchievement,
  type Connection,
  type InsertConnection,
  type BlogPost,
  type InsertBlogPost,
  type NewsletterLead,
  type InsertNewsletterLead,
  type AiToolsUsage,
  type InsertAiToolsUsage,
  type SocialAccount,
  type InsertSocialAccount,
  type SocialPost,
  type InsertSocialPost,
  type EngagementAction,
  type InsertEngagementAction,
  type PointLedger,
  type InsertPointLedger,
  type TokenUsageLog,
  type InsertTokenUsageLog,
  type StaffRole,
  type InsertStaffRole,
  type SalaryHistory,
  type InsertSalaryHistory,
  type Timeclock,
  type InsertTimeclock,
} from "@shared/schema";
import { db } from "./db";
import { eq, and, desc, sql } from "drizzle-orm";

export interface IStorage {
  // User operations
  getUser(id: string): Promise<User | undefined>;
  upsertUser(user: UpsertUser): Promise<User>;
  getUsersByNiche(niche: string, limit?: number): Promise<User[]>;
  updateUserPoints(userId: string, pointsToAdd: number): Promise<void>;
  resetDailyPoints(userId: string): Promise<void>;
  updateUserLevel(userId: string, level: string): Promise<void>;
  updateUserSubscription(userId: string, data: Partial<User>): Promise<void>;
  getAllUsers(limit?: number, offset?: number): Promise<User[]>;
  getUserCount(): Promise<number>;
  
  // Social metrics operations
  getSocialMetrics(userId: string): Promise<SocialMetrics[]>;
  upsertSocialMetrics(metrics: InsertSocialMetrics): Promise<SocialMetrics>;
  
  // Activity operations
  getActivities(userId: string, limit?: number): Promise<Activity[]>;
  createActivity(activity: InsertActivity): Promise<Activity>;
  
  // Achievement operations
  getUserAchievements(userId: string): Promise<Achievement[]>;
  unlockAchievement(achievement: InsertAchievement): Promise<Achievement>;
  hasAchievement(userId: string, achievementKey: string): Promise<boolean>;
  
  // Connection operations
  getConnections(userId: string): Promise<Connection[]>;
  getRecommendedConnections(userId: string, limit?: number): Promise<User[]>;
  createConnection(connection: InsertConnection): Promise<Connection>;
  updateConnectionStatus(connectionId: string, status: string): Promise<void>;
  
  // Blog operations
  getAllBlogPosts(published?: boolean): Promise<BlogPost[]>;
  getBlogPost(id: string): Promise<BlogPost | undefined>;
  getBlogPostBySlug(slug: string): Promise<BlogPost | undefined>;
  createBlogPost(post: InsertBlogPost): Promise<BlogPost>;
  updateBlogPost(id: string, post: Partial<InsertBlogPost>): Promise<void>;
  
  // Newsletter operations
  createNewsletterLead(lead: InsertNewsletterLead): Promise<NewsletterLead>;
  
  // AI Tools operations
  createAiToolsUsage(usage: InsertAiToolsUsage): Promise<AiToolsUsage>;
  getAiToolsUsageHistory(userId: string, limit?: number): Promise<AiToolsUsage[]>;
  
  // Social Accounts operations
  getSocialAccounts(userId: string): Promise<SocialAccount[]>;
  getSocialAccount(id: string): Promise<SocialAccount | undefined>;
  createSocialAccount(account: InsertSocialAccount): Promise<SocialAccount>;
  updateSocialAccount(id: string, account: Partial<InsertSocialAccount>): Promise<void>;
  deleteSocialAccount(id: string): Promise<void>;
  
  // Social Posts operations
  getSocialPosts(userId: string, limit?: number): Promise<SocialPost[]>;
  getSocialPostsByAccount(accountId: string, limit?: number): Promise<SocialPost[]>;
  createSocialPost(post: InsertSocialPost): Promise<SocialPost>;
  updateSocialPost(id: string, post: Partial<InsertSocialPost>): Promise<void>;
  
  // Engagement Actions operations
  getEngagementActions(userId: string, limit?: number): Promise<EngagementAction[]>;
  getPendingEngagementActions(userId: string): Promise<EngagementAction[]>;
  createEngagementAction(action: InsertEngagementAction): Promise<EngagementAction>;
  updateEngagementAction(id: string, action: Partial<InsertEngagementAction>): Promise<void>;
  
  // Point Ledger operations
  getPointLedger(userId: string, limit?: number): Promise<PointLedger[]>;
  createPointLedgerEntry(entry: InsertPointLedger): Promise<PointLedger>;
  
  // Token Usage Logs operations
  getTokenUsageLogs(userId: string, limit?: number): Promise<TokenUsageLog[]>;
  getAllTokenUsageLogs(limit?: number, offset?: number): Promise<TokenUsageLog[]>;
  createTokenUsageLog(log: InsertTokenUsageLog): Promise<TokenUsageLog>;
  updateTokenUsageLogNotes(id: string, notes: string): Promise<void>;
  getTokenUsageStats(userId: string): Promise<{ totalUsed: number; thisMonth: number; remaining: number }>;
  
  // Staff Role operations
  getAllStaffRoles(): Promise<StaffRole[]>;
  getStaffRole(userId: string): Promise<StaffRole | null>;
  createStaffRole(data: InsertStaffRole): Promise<StaffRole>;
  updateStaffRole(userId: string, data: Partial<InsertStaffRole>): Promise<StaffRole>;
  deleteStaffRole(userId: string): Promise<void>;
  
  // Salary History operations
  getSalaryHistory(staffRoleId: string): Promise<SalaryHistory[]>;
  createSalaryHistory(data: InsertSalaryHistory): Promise<SalaryHistory>;
  
  // Timeclock operations
  clockIn(userId: string, recordedBy?: string, isManual?: boolean, location?: string, notes?: string): Promise<Timeclock>;
  clockOut(userId: string, recordedBy?: string, isManual?: boolean, location?: string, notes?: string): Promise<Timeclock>;
  breakStart(userId: string, recordedBy?: string, isManual?: boolean, location?: string, notes?: string): Promise<Timeclock>;
  breakEnd(userId: string, recordedBy?: string, isManual?: boolean, location?: string, notes?: string): Promise<Timeclock>;
  getTimeclockRecords(userId: string, limit?: number): Promise<Timeclock[]>;
  getTimeclockRecordsByDateRange(userId: string, startDate: Date, endDate: Date): Promise<Timeclock[]>;
  getAllTimeclockRecords(limit?: number, offset?: number): Promise<Timeclock[]>;
  calculateWorkedHours(userId: string, startDate: Date, endDate: Date): Promise<{ totalHours: number; regularHours: number; breakHours: number }>;
}

export class DatabaseStorage implements IStorage {
  // User operations
  async getUser(id: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user;
  }

  async upsertUser(userData: UpsertUser): Promise<User> {
    const [user] = await db
      .insert(users)
      .values(userData)
      .onConflictDoUpdate({
        target: users.id,
        set: {
          ...userData,
          updatedAt: new Date(),
        },
      })
      .returning();
    return user;
  }

  async getUsersByNiche(niche: string, limit: number = 10): Promise<User[]> {
    return await db
      .select()
      .from(users)
      .where(sql`${niche} = ANY(${users.niches})`)
      .limit(limit);
  }

  async updateUserPoints(userId: string, pointsToAdd: number): Promise<void> {
    await db
      .update(users)
      .set({
        points: sql`${users.points} + ${pointsToAdd}`,
        totalPoints: sql`${users.totalPoints} + ${pointsToAdd}`,
        updatedAt: new Date(),
      })
      .where(eq(users.id, userId));
  }

  async resetDailyPoints(userId: string): Promise<void> {
    await db
      .update(users)
      .set({
        dailyPointsUsed: 0,
        lastPointsReset: new Date(),
        updatedAt: new Date(),
      })
      .where(eq(users.id, userId));
  }

  async updateUserLevel(userId: string, level: string): Promise<void> {
    await db
      .update(users)
      .set({
        level,
        updatedAt: new Date(),
      })
      .where(eq(users.id, userId));
  }

  async updateUserSubscription(userId: string, data: Partial<User>): Promise<void> {
    await db
      .update(users)
      .set({
        ...data,
        updatedAt: new Date(),
      })
      .where(eq(users.id, userId));
  }

  async getAllUsers(limit: number = 100, offset: number = 0): Promise<User[]> {
    return await db
      .select()
      .from(users)
      .limit(limit)
      .offset(offset)
      .orderBy(desc(users.createdAt));
  }

  async getUserCount(): Promise<number> {
    const result = await db
      .select({ count: sql<number>`count(*)` })
      .from(users);
    return result[0]?.count || 0;
  }

  // Social metrics operations
  async getSocialMetrics(userId: string): Promise<SocialMetrics[]> {
    return await db
      .select()
      .from(socialMetrics)
      .where(eq(socialMetrics.userId, userId));
  }

  async upsertSocialMetrics(metrics: InsertSocialMetrics): Promise<SocialMetrics> {
    const [result] = await db
      .insert(socialMetrics)
      .values(metrics)
      .onConflictDoUpdate({
        target: [socialMetrics.userId, socialMetrics.platform],
        set: {
          ...metrics,
          updatedAt: new Date(),
        },
      })
      .returning();
    return result;
  }

  // Activity operations
  async getActivities(userId: string, limit: number = 20): Promise<Activity[]> {
    return await db
      .select()
      .from(activities)
      .where(eq(activities.userId, userId))
      .orderBy(desc(activities.createdAt))
      .limit(limit);
  }

  async createActivity(activity: InsertActivity): Promise<Activity> {
    const [result] = await db
      .insert(activities)
      .values(activity)
      .returning();
    return result;
  }

  // Achievement operations
  async getUserAchievements(userId: string): Promise<Achievement[]> {
    return await db
      .select()
      .from(achievements)
      .where(eq(achievements.userId, userId))
      .orderBy(desc(achievements.unlockedAt));
  }

  async unlockAchievement(achievement: InsertAchievement): Promise<Achievement> {
    const [result] = await db
      .insert(achievements)
      .values(achievement)
      .returning();
    return result;
  }

  async hasAchievement(userId: string, achievementKey: string): Promise<boolean> {
    const [result] = await db
      .select()
      .from(achievements)
      .where(
        and(
          eq(achievements.userId, userId),
          eq(achievements.achievementKey, achievementKey)
        )
      );
    return !!result;
  }

  // Connection operations
  async getConnections(userId: string): Promise<Connection[]> {
    return await db
      .select()
      .from(connections)
      .where(eq(connections.userId, userId))
      .orderBy(desc(connections.createdAt));
  }

  async getRecommendedConnections(userId: string, limit: number = 10): Promise<User[]> {
    const user = await this.getUser(userId);
    if (!user || !user.niches || user.niches.length === 0) {
      return await db
        .select()
        .from(users)
        .where(sql`${users.id} != ${userId}`)
        .limit(limit);
    }

    return await db
      .select()
      .from(users)
      .where(
        and(
          sql`${users.id} != ${userId}`,
          sql`${users.niches} && ${user.niches}`
        )
      )
      .limit(limit);
  }

  async createConnection(connection: InsertConnection): Promise<Connection> {
    const [result] = await db
      .insert(connections)
      .values(connection)
      .returning();
    return result;
  }

  async updateConnectionStatus(connectionId: string, status: string): Promise<void> {
    await db
      .update(connections)
      .set({ status })
      .where(eq(connections.id, connectionId));
  }

  // Blog operations
  async getAllBlogPosts(published?: boolean): Promise<BlogPost[]> {
    const query = db.select().from(blogPosts);
    
    if (published !== undefined) {
      return await query
        .where(eq(blogPosts.published, published))
        .orderBy(desc(blogPosts.createdAt));
    }
    
    return await query.orderBy(desc(blogPosts.createdAt));
  }

  async getBlogPost(id: string): Promise<BlogPost | undefined> {
    const [post] = await db
      .select()
      .from(blogPosts)
      .where(eq(blogPosts.id, id));
    return post;
  }

  async getBlogPostBySlug(slug: string): Promise<BlogPost | undefined> {
    const [post] = await db
      .select()
      .from(blogPosts)
      .where(eq(blogPosts.slug, slug));
    return post;
  }

  async createBlogPost(post: InsertBlogPost): Promise<BlogPost> {
    const [result] = await db
      .insert(blogPosts)
      .values(post)
      .returning();
    return result;
  }

  async updateBlogPost(id: string, post: Partial<InsertBlogPost>): Promise<void> {
    await db
      .update(blogPosts)
      .set({
        ...post,
        updatedAt: new Date(),
      })
      .where(eq(blogPosts.id, id));
  }

  // Newsletter operations
  async createNewsletterLead(lead: InsertNewsletterLead): Promise<NewsletterLead> {
    const [result] = await db
      .insert(newsletterLeads)
      .values(lead)
      .returning();
    return result;
  }

  // AI Tools operations
  async createAiToolsUsage(usage: InsertAiToolsUsage): Promise<AiToolsUsage> {
    const [result] = await db
      .insert(aiToolsUsage)
      .values(usage)
      .returning();
    return result;
  }

  async getAiToolsUsageHistory(userId: string, limit: number = 50): Promise<AiToolsUsage[]> {
    return await db
      .select()
      .from(aiToolsUsage)
      .where(eq(aiToolsUsage.userId, userId))
      .orderBy(desc(aiToolsUsage.createdAt))
      .limit(limit);
  }

  // Social Accounts operations
  async getSocialAccounts(userId: string): Promise<SocialAccount[]> {
    return await db
      .select()
      .from(socialAccounts)
      .where(eq(socialAccounts.userId, userId))
      .orderBy(desc(socialAccounts.createdAt));
  }

  async getSocialAccount(id: string): Promise<SocialAccount | undefined> {
    const [account] = await db
      .select()
      .from(socialAccounts)
      .where(eq(socialAccounts.id, id));
    return account;
  }

  async createSocialAccount(account: InsertSocialAccount): Promise<SocialAccount> {
    const [result] = await db
      .insert(socialAccounts)
      .values(account)
      .returning();
    return result;
  }

  async updateSocialAccount(id: string, account: Partial<InsertSocialAccount>): Promise<void> {
    await db
      .update(socialAccounts)
      .set({
        ...account,
        updatedAt: new Date(),
      })
      .where(eq(socialAccounts.id, id));
  }

  async deleteSocialAccount(id: string): Promise<void> {
    await db
      .delete(socialAccounts)
      .where(eq(socialAccounts.id, id));
  }

  // Social Posts operations
  async getSocialPosts(userId: string, limit: number = 50): Promise<SocialPost[]> {
    return await db
      .select()
      .from(socialPosts)
      .where(eq(socialPosts.userId, userId))
      .orderBy(desc(socialPosts.createdAt))
      .limit(limit);
  }

  async getSocialPostsByAccount(accountId: string, limit: number = 50): Promise<SocialPost[]> {
    return await db
      .select()
      .from(socialPosts)
      .where(eq(socialPosts.socialAccountId, accountId))
      .orderBy(desc(socialPosts.createdAt))
      .limit(limit);
  }

  async createSocialPost(post: InsertSocialPost): Promise<SocialPost> {
    const [result] = await db
      .insert(socialPosts)
      .values(post)
      .returning();
    return result;
  }

  async updateSocialPost(id: string, post: Partial<InsertSocialPost>): Promise<void> {
    await db
      .update(socialPosts)
      .set({
        ...post,
        updatedAt: new Date(),
      })
      .where(eq(socialPosts.id, id));
  }

  // Engagement Actions operations
  async getEngagementActions(userId: string, limit: number = 50): Promise<EngagementAction[]> {
    return await db
      .select()
      .from(engagementActions)
      .where(eq(engagementActions.fromUserId, userId))
      .orderBy(desc(engagementActions.createdAt))
      .limit(limit);
  }

  async getPendingEngagementActions(userId: string): Promise<EngagementAction[]> {
    return await db
      .select()
      .from(engagementActions)
      .where(and(
        eq(engagementActions.toUserId, userId),
        eq(engagementActions.status, "pending")
      ))
      .orderBy(desc(engagementActions.createdAt));
  }

  async createEngagementAction(action: InsertEngagementAction): Promise<EngagementAction> {
    const [result] = await db
      .insert(engagementActions)
      .values(action)
      .returning();
    return result;
  }

  async updateEngagementAction(id: string, action: Partial<InsertEngagementAction>): Promise<void> {
    await db
      .update(engagementActions)
      .set(action)
      .where(eq(engagementActions.id, id));
  }

  // Point Ledger operations
  async getPointLedger(userId: string, limit: number = 100): Promise<PointLedger[]> {
    return await db
      .select()
      .from(pointLedger)
      .where(eq(pointLedger.userId, userId))
      .orderBy(desc(pointLedger.createdAt))
      .limit(limit);
  }

  async createPointLedgerEntry(entry: InsertPointLedger): Promise<PointLedger> {
    const [result] = await db
      .insert(pointLedger)
      .values(entry)
      .returning();
    return result;
  }

  // Token Usage Logs operations
  async getTokenUsageLogs(userId: string, limit: number = 100): Promise<TokenUsageLog[]> {
    return await db
      .select()
      .from(tokenUsageLogs)
      .where(eq(tokenUsageLogs.userId, userId))
      .orderBy(desc(tokenUsageLogs.createdAt))
      .limit(limit);
  }

  async getAllTokenUsageLogs(limit: number = 100, offset: number = 0): Promise<TokenUsageLog[]> {
    return await db
      .select()
      .from(tokenUsageLogs)
      .orderBy(desc(tokenUsageLogs.createdAt))
      .limit(limit)
      .offset(offset);
  }

  async createTokenUsageLog(log: InsertTokenUsageLog): Promise<TokenUsageLog> {
    const [result] = await db
      .insert(tokenUsageLogs)
      .values(log)
      .returning();
    return result;
  }

  async updateTokenUsageLogNotes(id: string, notes: string): Promise<void> {
    await db
      .update(tokenUsageLogs)
      .set({ notes })
      .where(eq(tokenUsageLogs.id, id));
  }

  async getTokenUsageStats(userId: string): Promise<{ totalUsed: number; thisMonth: number; remaining: number }> {
    const user = await this.getUser(userId);
    if (!user) {
      return { totalUsed: 0, thisMonth: 0, remaining: 10000 };
    }

    const monthlyLimit = user.monthlyTokenLimit || 10000;
    const thisMonth = user.monthlyTokensUsed || 0;
    
    // Get first day of current month
    const now = new Date();
    const firstDayOfMonth = new Date(now.getFullYear(), now.getMonth(), 1);
    
    const [result] = await db
      .select({
        totalUsed: sql<number>`COALESCE(SUM(${tokenUsageLogs.tokensUsed}), 0)`,
      })
      .from(tokenUsageLogs)
      .where(
        and(
          eq(tokenUsageLogs.userId, userId),
          sql`${tokenUsageLogs.createdAt} >= ${firstDayOfMonth}`
        )
      );

    return {
      totalUsed: Number(result?.totalUsed || 0),
      thisMonth,
      remaining: monthlyLimit - thisMonth,
    };
  }

  async getAllStaffRoles(): Promise<StaffRole[]> {
    return db.select().from(staffRoles);
  }

  async getStaffRole(userId: string): Promise<StaffRole | null> {
    const [role] = await db.select().from(staffRoles).where(eq(staffRoles.userId, userId));
    return role || null;
  }

  async createStaffRole(data: InsertStaffRole): Promise<StaffRole> {
    const [role] = await db.insert(staffRoles).values(data).returning();
    return role;
  }

  async updateStaffRole(userId: string, data: Partial<InsertStaffRole>): Promise<StaffRole> {
    const [updated] = await db.update(staffRoles).set({ ...data, updatedAt: new Date() }).where(eq(staffRoles.userId, userId)).returning();
    return updated;
  }

  async deleteStaffRole(userId: string): Promise<void> {
    await db.delete(staffRoles).where(eq(staffRoles.userId, userId));
  }

  async getSalaryHistory(staffRoleId: string): Promise<SalaryHistory[]> {
    return db.select().from(salaryHistory).where(eq(salaryHistory.staffRoleId, staffRoleId)).orderBy(desc(salaryHistory.createdAt));
  }

  async createSalaryHistory(data: InsertSalaryHistory): Promise<SalaryHistory> {
    const [history] = await db.insert(salaryHistory).values(data).returning();
    return history;
  }

  // Timeclock operations
  async clockIn(userId: string, recordedBy?: string, isManual: boolean = false, location?: string, notes?: string): Promise<Timeclock> {
    const [record] = await db.insert(timeclock).values({
      userId,
      clockType: "clock_in",
      recordedBy,
      isManual,
      location,
      notes,
    }).returning();
    return record;
  }

  async clockOut(userId: string, recordedBy?: string, isManual: boolean = false, location?: string, notes?: string): Promise<Timeclock> {
    const [record] = await db.insert(timeclock).values({
      userId,
      clockType: "clock_out",
      recordedBy,
      isManual,
      location,
      notes,
    }).returning();
    return record;
  }

  async breakStart(userId: string, recordedBy?: string, isManual: boolean = false, location?: string, notes?: string): Promise<Timeclock> {
    const [record] = await db.insert(timeclock).values({
      userId,
      clockType: "break_start",
      recordedBy,
      isManual,
      location,
      notes,
    }).returning();
    return record;
  }

  async breakEnd(userId: string, recordedBy?: string, isManual: boolean = false, location?: string, notes?: string): Promise<Timeclock> {
    const [record] = await db.insert(timeclock).values({
      userId,
      clockType: "break_end",
      recordedBy,
      isManual,
      location,
      notes,
    }).returning();
    return record;
  }

  async getTimeclockRecords(userId: string, limit: number = 50): Promise<Timeclock[]> {
    return db.select().from(timeclock).where(eq(timeclock.userId, userId)).orderBy(desc(timeclock.timestamp)).limit(limit);
  }

  async getTimeclockRecordsByDateRange(userId: string, startDate: Date, endDate: Date): Promise<Timeclock[]> {
    return db.select().from(timeclock)
      .where(
        and(
          eq(timeclock.userId, userId),
          sql`${timeclock.timestamp} >= ${startDate}`,
          sql`${timeclock.timestamp} <= ${endDate}`
        )
      )
      .orderBy(timeclock.timestamp);
  }

  async getAllTimeclockRecords(limit: number = 100, offset: number = 0): Promise<Timeclock[]> {
    return db.select().from(timeclock).orderBy(desc(timeclock.timestamp)).limit(limit).offset(offset);
  }

  async calculateWorkedHours(userId: string, startDate: Date, endDate: Date): Promise<{ totalHours: number; regularHours: number; breakHours: number }> {
    const records = await this.getTimeclockRecordsByDateRange(userId, startDate, endDate);
    
    let regularHours = 0;
    let breakHours = 0;
    let lastClockIn: Date | null = null;
    let lastBreakStart: Date | null = null;

    for (const record of records) {
      const timestamp = new Date(record.timestamp);
      
      if (record.clockType === 'clock_in') {
        lastClockIn = timestamp;
      } else if (record.clockType === 'clock_out' && lastClockIn) {
        const hours = (timestamp.getTime() - lastClockIn.getTime()) / (1000 * 60 * 60);
        regularHours += hours;
        lastClockIn = null;
      } else if (record.clockType === 'break_start') {
        lastBreakStart = timestamp;
      } else if (record.clockType === 'break_end' && lastBreakStart) {
        const hours = (timestamp.getTime() - lastBreakStart.getTime()) / (1000 * 60 * 60);
        breakHours += hours;
        lastBreakStart = null;
      }
    }

    const totalHours = regularHours - breakHours;

    return {
      totalHours: Math.max(0, totalHours),
      regularHours,
      breakHours,
    };
  }
}

export const storage = new DatabaseStorage();
