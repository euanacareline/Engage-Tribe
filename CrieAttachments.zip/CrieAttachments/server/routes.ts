import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { isAuthenticated, isAdmin, isProPlan } from "./replitAuth";
import { z } from "zod";
import { insertSocialMetricsSchema, insertActivitySchema, insertConnectionSchema, insertBlogPostSchema, insertAchievementSchema, type User } from "@shared/schema";
import passport from "passport";
import bcrypt from "bcryptjs";

// Helper to get user ID from both auth methods
function getUserId(req: any): string | null {
  // Local auth: user object is the database user
  if (req.user && typeof req.user === 'object' && 'id' in req.user) {
    return req.user.id;
  }
  // Replit auth: user object has claims
  if (req.user && req.user.claims && req.user.claims.sub) {
    return req.user.claims.sub;
  }
  return null;
}

export async function registerRoutes(app: Express): Promise<Server> {
  app.get("/api/user", isAuthenticated, async (req, res) => {
    try {
      const userId = getUserId(req);
      if (!userId) {
        return res.status(401).json({ message: "Unauthorized" });
      }

      const user = await storage.getUser(userId);
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }

      res.json(user);
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  app.get("/api/user/activities", isAuthenticated, async (req, res) => {
    try {
      const userId = (req.user as any)?.claims?.sub;
      if (!userId) {
        return res.status(401).json({ message: "Unauthorized" });
      }

      const limit = req.query.limit ? parseInt(req.query.limit as string) : 20;
      const activities = await storage.getActivities(userId, limit);
      res.json(activities);
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  app.get("/api/user/achievements", isAuthenticated, async (req, res) => {
    try {
      const userId = (req.user as any)?.claims?.sub;
      if (!userId) {
        return res.status(401).json({ message: "Unauthorized" });
      }

      const achievements = await storage.getUserAchievements(userId);
      res.json(achievements);
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  app.get("/api/user/social-metrics", isAuthenticated, async (req, res) => {
    try {
      const userId = (req.user as any)?.claims?.sub;
      if (!userId) {
        return res.status(401).json({ message: "Unauthorized" });
      }

      const metrics = await storage.getSocialMetrics(userId);
      res.json(metrics);
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  app.post("/api/user/social-metrics", isAuthenticated, async (req, res) => {
    try {
      const userId = (req.user as any)?.claims?.sub;
      if (!userId) {
        return res.status(401).json({ message: "Unauthorized" });
      }

      const validatedData = insertSocialMetricsSchema.parse({
        ...req.body,
        userId,
      });

      const metrics = await storage.upsertSocialMetrics(validatedData);
      res.json(metrics);
    } catch (error: any) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Validation error", errors: error.errors });
      }
      res.status(500).json({ message: error.message });
    }
  });

  app.get("/api/user/connections", isAuthenticated, async (req, res) => {
    try {
      const userId = (req.user as any)?.claims?.sub;
      if (!userId) {
        return res.status(401).json({ message: "Unauthorized" });
      }

      const connections = await storage.getConnections(userId);
      res.json(connections);
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  app.get("/api/connections", isAuthenticated, async (req, res) => {
    try {
      const userId = (req.user as any)?.claims?.sub;
      if (!userId) {
        return res.status(401).json({ message: "Unauthorized" });
      }

      const connections = await storage.getConnections(userId);
      res.json(connections);
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  app.get("/api/connections/recommended", isAuthenticated, async (req, res) => {
    try {
      const userId = (req.user as any)?.claims?.sub;
      if (!userId) {
        return res.status(401).json({ message: "Unauthorized" });
      }

      const limit = req.query.limit ? parseInt(req.query.limit as string) : 10;
      const recommendations = await storage.getRecommendedConnections(userId, limit);
      res.json(recommendations);
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  app.post("/api/connections", isAuthenticated, async (req, res) => {
    try {
      const userId = (req.user as any)?.claims?.sub;
      if (!userId) {
        return res.status(401).json({ message: "Unauthorized" });
      }

      const validatedData = insertConnectionSchema.parse({
        ...req.body,
        userId,
      });

      const connection = await storage.createConnection(validatedData);
      
      await storage.createActivity({
        userId,
        type: "connection",
        content: `Connected with ${connection.connectedUserId}`,
        points: 10,
      });

      await storage.updateUserPoints(userId, 10);
      
      res.json(connection);
    } catch (error: any) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Validation error", errors: error.errors });
      }
      res.status(500).json({ message: error.message });
    }
  });

  app.get("/api/blog", async (req, res) => {
    try {
      const published = req.query.published === "true" ? true : req.query.published === "false" ? false : undefined;
      const posts = await storage.getAllBlogPosts(published);
      res.json(posts);
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  app.get("/api/blog/:slug", async (req, res) => {
    try {
      const post = await storage.getBlogPostBySlug(req.params.slug);
      if (!post) {
        return res.status(404).json({ message: "Post not found" });
      }
      res.json(post);
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  app.post("/api/blog", isAdmin, async (req, res) => {
    try {
      const validatedData = insertBlogPostSchema.parse(req.body);
      const post = await storage.createBlogPost(validatedData);
      res.json(post);
    } catch (error: any) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Validation error", errors: error.errors });
      }
      res.status(500).json({ message: error.message });
    }
  });

  app.post("/api/admin/blog/manual", isAdmin, async (req, res) => {
    try {
      const { title, excerpt, content, category, published } = req.body;
      
      if (!title || !content || !category || !excerpt) {
        return res.status(400).json({ message: "Título, resumo, conteúdo e categoria são obrigatórios" });
      }

      const userId = getUserId(req);
      if (!userId) {
        return res.status(401).json({ message: "Unauthorized" });
      }
      
      const slug = title
        .toLowerCase()
        .normalize('NFD')
        .replace(/[\u0300-\u036f]/g, '')
        .replace(/[^a-z0-9]+/g, '-')
        .replace(/(^-|-$)/g, '');
      
      const wordCount = content.split(/\s+/).length;
      const readTime = `${Math.ceil(wordCount / 200)} min`;
      
      const post = await storage.createBlogPost({
        title,
        slug,
        excerpt,
        content,
        category,
        readTime,
        published: published ?? true,
        authorId: userId,
      });
      
      res.json({ post, message: "Artigo criado com sucesso" });
    } catch (error: any) {
      console.error("Error creating manual article:", error);
      res.status(500).json({ message: error.message });
    }
  });

  app.post("/api/activities", isAuthenticated, async (req, res) => {
    try {
      const userId = (req.user as any)?.claims?.sub;
      if (!userId) {
        return res.status(401).json({ message: "Unauthorized" });
      }

      const validatedData = insertActivitySchema.parse({
        ...req.body,
        userId,
      });
      
      const activity = await storage.createActivity(validatedData);
      
      if (validatedData.points && validatedData.points > 0) {
        await storage.updateUserPoints(userId, validatedData.points);
      }
      
      res.json(activity);
    } catch (error: any) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Validation error", errors: error.errors });
      }
      res.status(500).json({ message: error.message });
    }
  });

  app.get("/api/activities", isAuthenticated, async (req, res) => {
    try {
      const userId = (req.user as any)?.claims?.sub;
      if (!userId) {
        return res.status(401).json({ message: "Unauthorized" });
      }

      const limit = req.query.limit ? parseInt(req.query.limit as string) : 20;
      const activities = await storage.getActivities(userId, limit);
      res.json(activities);
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  app.get("/api/achievements", isAuthenticated, async (req, res) => {
    try {
      const userId = (req.user as any)?.claims?.sub;
      if (!userId) {
        return res.status(401).json({ message: "Unauthorized" });
      }

      const achievements = await storage.getUserAchievements(userId);
      res.json(achievements);
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  app.post("/api/achievements", isAuthenticated, async (req, res) => {
    try {
      const userId = (req.user as any)?.claims?.sub;
      if (!userId) {
        return res.status(401).json({ message: "Unauthorized" });
      }

      const validatedData = insertAchievementSchema.parse({
        ...req.body,
        userId,
      });
      const achievement = await storage.unlockAchievement(validatedData);
      res.json(achievement);
    } catch (error: any) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Validation error", errors: error.errors });
      }
      res.status(500).json({ message: error.message });
    }
  });

  app.get("/api/connections", isAuthenticated, async (req, res) => {
    try {
      const userId = (req.user as any)?.claims?.sub;
      if (!userId) {
        return res.status(401).json({ message: "Unauthorized" });
      }

      const connections = await storage.getConnections(userId);
      res.json(connections);
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  app.post("/api/connections", isAuthenticated, async (req, res) => {
    try {
      const userId = (req.user as any)?.claims?.sub;
      if (!userId) {
        return res.status(401).json({ message: "Unauthorized" });
      }

      const validatedData = insertConnectionSchema.parse({
        ...req.body,
        userId,
      });
      
      const connection = await storage.createConnection(validatedData);
      
      await storage.updateUserPoints(userId, 10);
      
      await storage.createActivity({
        userId,
        fromUserId: validatedData.connectedUserId,
        type: "connection",
        content: "Nova conexão estabelecida",
        points: 10,
      });
      
      res.json(connection);
    } catch (error: any) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Validation error", errors: error.errors });
      }
      res.status(500).json({ message: error.message });
    }
  });

  app.get("/api/admin/check", async (req, res) => {
    const isAdminAuth = (req.session as any)?.adminAuthenticated === true;
    
    if (isAdminAuth) {
      return res.json({ isAdmin: true, sessionBased: true });
    }

    if (req.isAuthenticated()) {
      const user = req.user as any;
      const userId = user.id || user.claims?.sub;
      
      if (userId) {
        const dbUser = await storage.getUser(userId);
        if (dbUser?.isAdmin) {
          return res.json({ isAdmin: true, sessionBased: false, user: dbUser });
        }
      }
    }

    res.json({ isAdmin: false });
  });

  app.post("/api/admin/login", async (req, res) => {
    try {
      const { username, password } = req.body;
      
      const adminUsername = process.env.ADMIN_USERNAME || "admin";
      const adminPassword = process.env.ADMIN_PASSWORD || "admin123";

      if (username !== adminUsername || password !== adminPassword) {
        return res.status(401).send("Credenciais inválidas");
      }

      if (req.session) {
        (req.session as any).adminAuthenticated = true;
        await new Promise<void>((resolve, reject) => {
          req.session.save((err) => {
            if (err) reject(err);
            else resolve();
          });
        });
      }

      res.json({ success: true, message: "Login realizado com sucesso" });
    } catch (error: any) {
      console.error("Error in admin login:", error);
      res.status(500).json({ message: error.message });
    }
  });

  app.get("/api/admin/users", isAdmin, async (req, res) => {
    try {
      const limit = req.query.limit ? parseInt(req.query.limit as string) : 100;
      const offset = req.query.offset ? parseInt(req.query.offset as string) : 0;
      
      const users = await storage.getAllUsers(limit, offset);
      const count = await storage.getUserCount();
      
      res.json({ users, count });
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  // User deletion disabled for data integrity
  // app.delete("/api/admin/users/:userId", isAdmin, async (req, res) => {
  //   try {
  //     await storage.deleteUser(req.params.userId);
  //     res.json({ success: true, message: "User deleted successfully" });
  //   } catch (error: any) {
  //     res.status(500).json({ message: error.message });
  //   }
  // });

  app.patch("/api/admin/users/:userId/plan", isAdmin, async (req, res) => {
    try {
      const { plan } = req.body;
      
      if (!plan || !['starter', 'pro', 'elite'].includes(plan)) {
        return res.status(400).json({ message: "Plano inválido. Escolha: starter, pro ou elite" });
      }

      const user = await storage.getUser(req.params.userId);
      if (!user) {
        return res.status(404).json({ message: "Usuário não encontrado" });
      }

      const updateData: Partial<User> = {
        subscriptionPlan: plan,
        subscriptionStatus: 'active',
      };

      // If changing to PRO plan, reset monthly token counters
      if (plan === 'pro') {
        updateData.monthlyTokensUsed = 0;
        updateData.monthlyTokenLimit = 10000;
        updateData.lastMonthlyTokenReset = new Date();
        updateData.tokensUsedToday = 0; // Clear daily usage
      } 
      // If changing from PRO to other plans, reset daily counters
      else if (user.subscriptionPlan === 'pro') {
        updateData.tokensUsedToday = 0;
        updateData.lastTokenReset = new Date();
        updateData.dailyTokenLimit = plan === 'elite' ? 100000 : 5000;
      }

      await storage.updateUserSubscription(req.params.userId, updateData);

      res.json({ success: true, message: "Plano atualizado com sucesso" });
    } catch (error: any) {
      console.error("Error updating plan:", error);
      res.status(500).json({ message: error.message });
    }
  });

  app.post("/api/admin/users/:userId/reset-password", isAdmin, async (req, res) => {
    try {
      const { newPassword } = req.body;

      if (!newPassword || newPassword.length < 6) {
        return res.status(400).json({ message: "Nova senha deve ter pelo menos 6 caracteres" });
      }

      const user = await storage.getUser(req.params.userId);
      if (!user) {
        return res.status(404).json({ message: "Usuário não encontrado" });
      }

      const passwordHash = await bcrypt.hash(newPassword, 10);
      await storage.updateUserSubscription(req.params.userId, {
        passwordHash,
      });

      // SECURITY: Never return the password in the response
      // Log it securely for the admin to copy from server logs
      console.log(`[ADMIN] Password reset for ${user.email}: ${newPassword}`);

      res.json({ 
        success: true, 
        message: `Senha alterada com sucesso para ${user.email}. Nova senha: ${newPassword}`,
        email: user.email
      });
    } catch (error: any) {
      console.error("Error resetting password:", error);
      res.status(500).json({ message: error.message });
    }
  });

  app.patch("/api/admin/users/:userId/role", isAdmin, async (req, res) => {
    try {
      const { isAdmin: makeAdmin } = req.body;
      
      const user = await storage.getUser(req.params.userId);
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }

      await storage.updateUserSubscription(req.params.userId, {
        isAdmin: makeAdmin === true,
      });

      res.json({ success: true, message: "Role updated successfully" });
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  // Social Accounts Admin Routes
  app.get("/api/admin/social-accounts/:userId", isAdmin, async (req, res) => {
    try {
      const accounts = await storage.getSocialAccounts(req.params.userId);
      res.json({ accounts });
    } catch (error: any) {
      console.error("Error fetching social accounts:", error);
      res.status(500).json({ message: error.message });
    }
  });

  app.post("/api/admin/social-accounts", isAdmin, async (req, res) => {
    try {
      const { insertSocialAccountSchema } = await import("@shared/schema");
      const validated = insertSocialAccountSchema.parse(req.body);
      
      const account = await storage.createSocialAccount(validated);
      res.json({ success: true, account });
    } catch (error: any) {
      if (error.name === 'ZodError') {
        return res.status(400).json({ message: "Dados inválidos" });
      }
      console.error("Error creating social account:", error);
      res.status(500).json({ message: error.message });
    }
  });

  app.delete("/api/admin/social-accounts/:accountId", isAdmin, async (req, res) => {
    try {
      await storage.deleteSocialAccount(req.params.accountId);
      res.json({ success: true, message: "Conta removida com sucesso" });
    } catch (error: any) {
      console.error("Error deleting social account:", error);
      res.status(500).json({ message: error.message });
    }
  });

  // Social Posts Admin Routes
  app.get("/api/admin/social-posts/:userId", isAdmin, async (req, res) => {
    try {
      const posts = await storage.getSocialPosts(req.params.userId);
      res.json({ posts });
    } catch (error: any) {
      console.error("Error fetching social posts:", error);
      res.status(500).json({ message: error.message });
    }
  });

  // Token Usage Admin Routes - Management and Tracking
  app.get("/api/admin/token-usage", isAdmin, async (req, res) => {
    try {
      const limit = req.query.limit ? parseInt(req.query.limit as string) : 100;
      const offset = req.query.offset ? parseInt(req.query.offset as string) : 0;
      
      const logs = await storage.getAllTokenUsageLogs(limit, offset);
      res.json({ logs });
    } catch (error: any) {
      console.error("Error fetching token usage logs:", error);
      res.status(500).json({ message: error.message });
    }
  });

  app.get("/api/admin/token-usage/:userId", isAdmin, async (req, res) => {
    try {
      const limit = req.query.limit ? parseInt(req.query.limit as string) : 100;
      const logs = await storage.getTokenUsageLogs(req.params.userId, limit);
      res.json({ logs });
    } catch (error: any) {
      console.error("Error fetching user token usage logs:", error);
      res.status(500).json({ message: error.message });
    }
  });

  app.get("/api/admin/token-usage/:userId/stats", isAdmin, async (req, res) => {
    try {
      const stats = await storage.getTokenUsageStats(req.params.userId);
      const user = await storage.getUser(req.params.userId);
      
      res.json({ 
        stats,
        user: user ? {
          id: user.id,
          email: user.email,
          firstName: user.firstName,
          lastName: user.lastName,
          plan: user.subscriptionPlan,
          monthlyLimit: user.monthlyTokenLimit,
        } : null
      });
    } catch (error: any) {
      console.error("Error fetching token usage stats:", error);
      res.status(500).json({ message: error.message });
    }
  });

  app.patch("/api/admin/token-usage/:logId/notes", isAdmin, async (req, res) => {
    try {
      const { notes } = req.body;
      
      if (typeof notes !== 'string') {
        return res.status(400).json({ message: "Notas devem ser texto" });
      }
      
      await storage.updateTokenUsageLogNotes(req.params.logId, notes);
      res.json({ success: true, message: "Anotação adicionada com sucesso" });
    } catch (error: any) {
      console.error("Error updating token usage log notes:", error);
      res.status(500).json({ message: error.message });
    }
  });

  app.get("/api/admin/staff", isAdmin, async (req, res) => {
    try {
      const roles = await storage.getAllStaffRoles();
      const users = await storage.getAllUsers();
      
      const rolesWithUsers = roles.map(role => {
        const user = users.find(u => u.id === role.userId);
        return {
          ...role,
          user,
        };
      });
      
      res.json({ roles: rolesWithUsers });
    } catch (error: any) {
      console.error("Error fetching staff roles:", error);
      res.status(500).json({ message: error.message });
    }
  });

  app.post("/api/admin/staff", isAdmin, async (req, res) => {
    try {
      const { insertStaffRoleSchema } = await import("@shared/schema");
      const validated = insertStaffRoleSchema.parse(req.body);
      
      const role = await storage.createStaffRole(validated);
      res.json({ role, message: "Funcionário adicionado com sucesso" });
    } catch (error: any) {
      console.error("Error creating staff role:", error);
      res.status(500).json({ message: error.message });
    }
  });

  app.patch("/api/admin/staff/:userId", isAdmin, async (req, res) => {
    try {
      const { insertStaffRoleSchema } = await import("@shared/schema");
      const currentStaff = await storage.getStaffRole(req.params.userId);
      
      if (req.body.salary && currentStaff && req.body.salary !== currentStaff.salary) {
        await storage.createSalaryHistory({
          staffRoleId: currentStaff.id,
          previousSalary: currentStaff.salary || 0,
          newSalary: req.body.salary,
          reason: req.body.salaryChangeReason,
          changedBy: req.user?.id || undefined,
        });
      }
      
      const validated = insertStaffRoleSchema.partial().parse(req.body);
      const updated = await storage.updateStaffRole(req.params.userId, validated);
      res.json({ role: updated, message: "Funcionário atualizado com sucesso" });
    } catch (error: any) {
      console.error("Error updating staff role:", error);
      res.status(500).json({ message: error.message });
    }
  });

  app.delete("/api/admin/staff/:userId", isAdmin, async (req, res) => {
    try {
      await storage.deleteStaffRole(req.params.userId);
      res.json({ success: true, message: "Funcionário removido com sucesso" });
    } catch (error: any) {
      console.error("Error deleting staff role:", error);
      res.status(500).json({ message: error.message });
    }
  });

  app.get("/api/admin/staff/:userId/salary-history", isAdmin, async (req, res) => {
    try {
      const staff = await storage.getStaffRole(req.params.userId);
      if (!staff) {
        return res.status(404).json({ message: "Funcionário não encontrado" });
      }
      
      const history = await storage.getSalaryHistory(staff.id);
      res.json({ history });
    } catch (error: any) {
      console.error("Error fetching salary history:", error);
      res.status(500).json({ message: error.message });
    }
  });

  // Timeclock routes
  app.post("/api/timeclock/in", isAuthenticated, async (req, res) => {
    try {
      const userId = req.body.targetUserId || req.user!.id;
      const isManual = !!req.body.targetUserId && req.user!.isAdmin;
      const record = await storage.clockIn(
        userId,
        req.user!.id,
        isManual,
        req.body.location,
        req.body.notes
      );
      res.json({ record, message: "Entrada registrada com sucesso" });
    } catch (error: any) {
      console.error("Error clocking in:", error);
      res.status(500).json({ message: error.message });
    }
  });

  app.post("/api/timeclock/out", isAuthenticated, async (req, res) => {
    try {
      const userId = req.body.targetUserId || req.user!.id;
      const isManual = !!req.body.targetUserId && req.user!.isAdmin;
      const record = await storage.clockOut(
        userId,
        req.user!.id,
        isManual,
        req.body.location,
        req.body.notes
      );
      res.json({ record, message: "Saída registrada com sucesso" });
    } catch (error: any) {
      console.error("Error clocking out:", error);
      res.status(500).json({ message: error.message });
    }
  });

  app.post("/api/timeclock/break-start", isAuthenticated, async (req, res) => {
    try {
      const userId = req.body.targetUserId || req.user!.id;
      const isManual = !!req.body.targetUserId && req.user!.isAdmin;
      const record = await storage.breakStart(
        userId,
        req.user!.id,
        isManual,
        req.body.location,
        req.body.notes
      );
      res.json({ record, message: "Pausa iniciada" });
    } catch (error: any) {
      console.error("Error starting break:", error);
      res.status(500).json({ message: error.message });
    }
  });

  app.post("/api/timeclock/break-end", isAuthenticated, async (req, res) => {
    try {
      const userId = req.body.targetUserId || req.user!.id;
      const isManual = !!req.body.targetUserId && req.user!.isAdmin;
      const record = await storage.breakEnd(
        userId,
        req.user!.id,
        isManual,
        req.body.location,
        req.body.notes
      );
      res.json({ record, message: "Pausa finalizada" });
    } catch (error: any) {
      console.error("Error ending break:", error);
      res.status(500).json({ message: error.message });
    }
  });

  app.get("/api/timeclock/records", isAuthenticated, async (req, res) => {
    try {
      const userId = req.query.userId as string || req.user!.id;
      if (userId !== req.user!.id && !req.user!.isAdmin) {
        return res.status(403).json({ message: "Acesso negado" });
      }
      
      const limit = parseInt(req.query.limit as string) || 50;
      const records = await storage.getTimeclockRecords(userId, limit);
      res.json({ records });
    } catch (error: any) {
      console.error("Error fetching timeclock records:", error);
      res.status(500).json({ message: error.message });
    }
  });

  app.get("/api/timeclock/report", isAuthenticated, async (req, res) => {
    try {
      const userId = req.query.userId as string || req.user!.id;
      if (userId !== req.user!.id && !req.user!.isAdmin) {
        return res.status(403).json({ message: "Acesso negado" });
      }

      const startDate = new Date(req.query.startDate as string);
      const endDate = new Date(req.query.endDate as string);

      if (isNaN(startDate.getTime()) || isNaN(endDate.getTime())) {
        return res.status(400).json({ message: "Datas inválidas" });
      }

      const hoursData = await storage.calculateWorkedHours(userId, startDate, endDate);
      const records = await storage.getTimeclockRecordsByDateRange(userId, startDate, endDate);

      res.json({ hoursData, records });
    } catch (error: any) {
      console.error("Error generating timeclock report:", error);
      res.status(500).json({ message: error.message });
    }
  });

  app.get("/api/admin/timeclock/all", isAdmin, async (req, res) => {
    try {
      const limit = parseInt(req.query.limit as string) || 100;
      const offset = parseInt(req.query.offset as string) || 0;
      const records = await storage.getAllTimeclockRecords(limit, offset);
      res.json({ records });
    } catch (error: any) {
      console.error("Error fetching all timeclock records:", error);
      res.status(500).json({ message: error.message });
    }
  });

  // HR Chatbot route
  app.post("/api/admin/hr-chatbot", isAdmin, async (req, res) => {
    try {
      const { generateHRChatResponse } = await import("./ai/hrChatbot");
      const { message } = req.body;

      if (!message || typeof message !== 'string') {
        return res.status(400).json({ message: "Mensagem inválida" });
      }

      const response = await generateHRChatResponse(message, req.user!.id);
      res.json({ response });
    } catch (error: any) {
      console.error("HR Chatbot error:", error);
      res.status(500).json({ message: "Erro ao processar mensagem" });
    }
  });

  app.post("/api/newsletter/subscribe", async (req, res) => {
    try {
      const { insertNewsletterLeadSchema } = await import("@shared/schema");
      const validated = insertNewsletterLeadSchema.parse({
        email: req.body.email?.toLowerCase().trim(),
        source: req.body.source || "blog",
      });

      await storage.createNewsletterLead(validated);

      res.json({ success: true, message: "Inscrição realizada com sucesso" });
    } catch (error: any) {
      if (error.name === 'ZodError') {
        return res.status(400).json({ message: "Email inválido" });
      }
      if (error.constraint === 'newsletter_leads_email_unique' || error.code === '23505') {
        return res.status(409).json({ message: "Email já cadastrado" });
      }
      console.error("Error subscribing to newsletter:", error);
      res.status(500).json({ message: error.message || "Erro ao cadastrar email" });
    }
  });

  app.post("/api/chatbot", async (req, res) => {
    try {
      const { generateChatResponse } = await import("./ai/chatbot");
      const { message } = req.body;

      if (!message || typeof message !== 'string') {
        return res.status(400).json({ message: "Mensagem inválida" });
      }

      const response = await generateChatResponse(message);
      res.json({ response });
    } catch (error: any) {
      console.error("Chatbot error:", error);
      res.status(500).json({ message: "Erro ao processar mensagem" });
    }
  });

  app.post("/api/ai-tools/youtube", isAuthenticated, isProPlan, async (req, res) => {
    try {
      const { generateYouTubeContent } = await import("./ai/socialMediaTools");
      const { insertAiToolsUsageSchema } = await import("@shared/schema");
      const { checkTokenAvailability, deductTokens, TOKEN_COSTS } = await import("./ai/tokenManagement");
      
      const validated = z.object({
        videoTopic: z.string().min(1),
        videoType: z.enum(["short", "long"]),
        targetAudience: z.string().optional(),
      }).parse(req.body);

      const userId = (req.user as any)?.claims?.sub;
      if (!userId) {
        return res.status(401).json({ message: "Usuário não autenticado" });
      }

      // Estimate token cost based on video type
      const tokenCost = validated.videoType === "long" 
        ? TOKEN_COSTS.youtube_script_long 
        : TOKEN_COSTS.youtube_script_short;

      // Check if user has enough tokens
      const tokenCheck = await checkTokenAvailability(userId, tokenCost);
      if (!tokenCheck.success) {
        return res.status(429).json({ 
          message: tokenCheck.error,
          remainingTokens: tokenCheck.remainingTokens 
        });
      }

      // Generate content
      const result = await generateYouTubeContent(validated);
      
      // Only deduct tokens after successful generation
      const deduction = await deductTokens(
        userId, 
        tokenCost,
        "ai_tools",
        "gpt-4",
        `youtube_${validated.videoType}`,
        JSON.stringify(validated),
        JSON.stringify(result)
      );
      
      await storage.createAiToolsUsage({
        userId,
        toolType: "youtube",
        platform: "youtube",
        inputData: validated,
        outputData: result,
      });

      res.json({ ...result, remainingTokens: deduction.remainingTokens });
    } catch (error: any) {
      console.error("Error generating YouTube content:", error);
      res.status(500).json({ message: error.message || "Erro ao gerar conteúdo" });
    }
  });

  app.post("/api/ai-tools/instagram", isAuthenticated, isProPlan, async (req, res) => {
    try {
      const { generateInstagramContent } = await import("./ai/socialMediaTools");
      const { insertAiToolsUsageSchema } = await import("@shared/schema");
      const { checkTokenAvailability, deductTokens, TOKEN_COSTS } = await import("./ai/tokenManagement");
      
      const validated = z.object({
        contentType: z.enum(["feed", "reel", "story", "carousel"]),
        topic: z.string().min(1),
        tone: z.enum(["motivational", "educational", "inspirational", "casual"]).optional(),
      }).parse(req.body);

      const userId = (req.user as any)?.claims?.sub;
      if (!userId) {
        return res.status(401).json({ message: "Usuário não autenticado" });
      }

      // Estimate token cost based on content type
      const tokenCost = validated.contentType === "carousel" || validated.contentType === "reel"
        ? TOKEN_COSTS.instagram_carousel
        : TOKEN_COSTS.instagram_caption;

      // Check if user has enough tokens
      const tokenCheck = await checkTokenAvailability(userId, tokenCost);
      if (!tokenCheck.success) {
        return res.status(429).json({ 
          message: tokenCheck.error,
          remainingTokens: tokenCheck.remainingTokens 
        });
      }

      // Generate content
      const result = await generateInstagramContent(validated);
      
      // Only deduct tokens after successful generation
      const deduction = await deductTokens(
        userId,
        tokenCost,
        "ai_tools",
        "gpt-4",
        `instagram_${validated.contentType}`,
        JSON.stringify(validated),
        JSON.stringify(result)
      );
      
      await storage.createAiToolsUsage({
        userId,
        toolType: "instagram",
        platform: "instagram",
        inputData: validated,
        outputData: result,
      });

      res.json({ ...result, remainingTokens: deduction.remainingTokens });
    } catch (error: any) {
      console.error("Error generating Instagram content:", error);
      res.status(500).json({ message: error.message || "Erro ao gerar conteúdo" });
    }
  });

  app.post("/api/ai-tools/facebook", isAuthenticated, isProPlan, async (req, res) => {
    try {
      const { generateFacebookContent } = await import("./ai/socialMediaTools");
      const { insertAiToolsUsageSchema } = await import("@shared/schema");
      const { checkTokenAvailability, deductTokens, TOKEN_COSTS } = await import("./ai/tokenManagement");
      
      const validated = z.object({
        postType: z.enum(["engagement", "ad", "story", "article"]),
        topic: z.string().min(1),
        audience: z.string().optional(),
      }).parse(req.body);

      const userId = (req.user as any)?.claims?.sub;
      if (!userId) {
        return res.status(401).json({ message: "Usuário não autenticado" });
      }

      // Estimate token cost based on post type
      const tokenCost = validated.postType === "article" 
        ? TOKEN_COSTS.facebook_article
        : validated.postType === "ad"
        ? TOKEN_COSTS.facebook_ad
        : TOKEN_COSTS.facebook_post;

      // Check if user has enough tokens
      const tokenCheck = await checkTokenAvailability(userId, tokenCost);
      if (!tokenCheck.success) {
        return res.status(429).json({ 
          message: tokenCheck.error,
          remainingTokens: tokenCheck.remainingTokens 
        });
      }

      // Generate content
      const result = await generateFacebookContent(validated);
      
      // Only deduct tokens after successful generation
      const deduction = await deductTokens(
        userId,
        tokenCost,
        "ai_tools",
        "gpt-4",
        `facebook_${validated.postType}`,
        JSON.stringify(validated),
        JSON.stringify(result)
      );
      
      await storage.createAiToolsUsage({
        userId,
        toolType: "facebook",
        platform: "facebook",
        inputData: validated,
        outputData: result,
      });

      res.json({ ...result, remainingTokens: deduction.remainingTokens });
    } catch (error: any) {
      console.error("Error generating Facebook content:", error);
      res.status(500).json({ message: error.message || "Erro ao gerar conteúdo" });
    }
  });

  app.get("/api/ai-tools/history", isAuthenticated, isProPlan, async (req, res) => {
    try {
      const userId = (req.user as any)?.claims?.sub;
      const history = await storage.getAiToolsUsageHistory(userId);
      res.json(history);
    } catch (error: any) {
      console.error("Error fetching AI tools history:", error);
      res.status(500).json({ message: error.message || "Erro ao buscar histórico" });
    }
  });

  app.get("/api/ai-tools/token-status", isAuthenticated, async (req, res) => {
    try {
      const { getUserTokenStatus } = await import("./ai/tokenManagement");
      const userId = (req.user as any)?.claims?.sub;
      if (!userId) {
        return res.status(401).json({ message: "Usuário não autenticado" });
      }
      
      const status = await getUserTokenStatus(userId);
      res.json(status);
    } catch (error: any) {
      console.error("Error fetching token status:", error);
      res.status(500).json({ message: error.message || "Erro ao buscar status de tokens" });
    }
  });

  app.post("/api/admin/generate-article", isAdmin, async (req, res) => {
    try {
      const { generateSEOArticle } = await import("./ai/articleGenerator");
      const { generateArticleImage } = await import("./ai/articleGenerator");
      
      const article = await generateSEOArticle();
      
      if (!article) {
        return res.status(500).json({ message: "Failed to generate article" });
      }

      const existingPost = await storage.getBlogPostBySlug(article.slug);
      if (existingPost) {
        return res.status(409).json({ message: "Article with this title already exists" });
      }

      const coverImage = await generateArticleImage(article.title);

      const userId = (req.user as any)?.claims?.sub;
      
      const post = await storage.createBlogPost({
        authorId: userId,
        title: article.title,
        slug: article.slug,
        excerpt: article.excerpt,
        content: article.content,
        coverImage: coverImage || undefined,
        category: article.category,
        readTime: article.readTime,
        published: true,
      });

      res.json({ success: true, article: post });
    } catch (error: any) {
      console.error("Error generating article:", error);
      res.status(500).json({ message: error.message });
    }
  });

  // Local authentication routes (email/password)
  app.post("/api/auth/signup", async (req, res) => {
    try {
      const { email, password, firstName, lastName } = req.body;

      if (!email || !password) {
        return res.status(400).json({ message: "Email e senha são obrigatórios" });
      }

      const users = await storage.getAllUsers(1000, 0);
      const existingUser = users.find((u) => u.email === email);
      
      if (existingUser) {
        return res.status(400).json({ message: "Email já cadastrado" });
      }

      const passwordHash = await bcrypt.hash(password, 10);

      const user = await storage.upsertUser({
        email,
        passwordHash,
        firstName: firstName || email.split("@")[0],
        lastName: lastName || "",
      });

      req.login(user, (err) => {
        if (err) {
          return res.status(500).json({ message: "Erro ao fazer login automático" });
        }
        res.json({ success: true, user });
      });
    } catch (error: any) {
      console.error("Signup error:", error);
      res.status(500).json({ message: error.message });
    }
  });

  app.post("/api/auth/login", (req, res, next) => {
    passport.authenticate("local", (err: any, user: any, info: any) => {
      if (err) {
        return res.status(500).json({ message: "Erro no servidor" });
      }
      
      if (!user) {
        return res.status(401).json({ message: info?.message || "Credenciais inválidas" });
      }

      req.login(user, (err) => {
        if (err) {
          return res.status(500).json({ message: "Erro ao fazer login" });
        }
        res.json({ success: true, user });
      });
    })(req, res, next);
  });

  app.post("/api/auth/logout", (req, res) => {
    req.logout((err) => {
      if (err) {
        return res.status(500).json({ message: "Erro ao fazer logout" });
      }
      res.json({ success: true });
    });
  });

  app.get("/api/auth/session", (req, res) => {
    if (req.isAuthenticated()) {
      res.json({ authenticated: true, user: req.user });
    } else {
      res.json({ authenticated: false });
    }
  });

  const httpServer = createServer(app);

  return httpServer;
}
