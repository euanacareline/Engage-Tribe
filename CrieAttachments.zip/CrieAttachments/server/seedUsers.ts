import bcrypt from "bcryptjs";
import { storage } from "./storage";

export async function seedDefaultUsers() {
  try {
    // Usuário Plano Starter (R$ 39,90/mês)
    const starterPasswordHash = await bcrypt.hash("acesso2026#02", 10);
    await storage.upsertUser({
      id: "starter-user-001",
      email: "acesso2026#01",
      passwordHash: starterPasswordHash,
      firstName: "Cliente",
      lastName: "Starter",
      subscriptionPlan: "starter",
      subscriptionStatus: "active",
      dailyTokenLimit: 5000,
    });
    console.log("✅ Usuário Starter criado: acesso2026#01");

    // Usuário Plano PRO (R$ 497 - Membro Fundador)
    const proPasswordHash = await bcrypt.hash("acessopremium02#", 10);
    await storage.upsertUser({
      id: "pro-user-001",
      email: "acessopremium01#",
      passwordHash: proPasswordHash,
      firstName: "Cliente",
      lastName: "PRO",
      subscriptionPlan: "pro",
      subscriptionStatus: "active",
      dailyTokenLimit: 50000,
    });
    console.log("✅ Usuário PRO criado: acessopremium01#");

    console.log("✅ Usuários padrão criados com sucesso!");
  } catch (error) {
    console.error("❌ Erro ao criar usuários padrão:", error);
  }
}
