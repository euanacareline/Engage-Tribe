import OpenAI from "openai";

const openai = new OpenAI({
  apiKey: process.env.OPENAI_API_KEY,
});

export async function generateChatResponse(userMessage: string): Promise<string> {
  try {
    const completion = await openai.chat.completions.create({
      model: "gpt-4",
      messages: [
        {
          role: "system",
          content: `Você é um assistente virtual especializado da plataforma Engage Tribe, uma comunidade de criadores de conteúdo.

Sua função é ajudar visitantes a entenderem a plataforma e como ela pode ajudá-los a crescer organicamente nas redes sociais.

INFORMAÇÕES SOBRE A PLATAFORMA:
- Engage Tribe é uma plataforma de reciprocidade gamificada para criadores de conteúdo
- Ajuda criadores a crescerem organicamente através de engajamento autêntico
- Sistema de pontos e níveis para recompensar participação ativa
- Suporta YouTube, Instagram, TikTok, Facebook e outras redes
- Planos: Starter (R$ 39,90/mês), PRO (R$ 497 pagamento único), Elite (R$ 297/mês)
- PRO inclui: ferramentas de IA ilimitadas, sem limite de pontos, participa do conselho consultivo
- Starter: 1000 visualizações diárias, 5 tarefas obrigatórias/dia

COMO RESPONDER:
- Seja amigável, profissional e empolgante
- Responda em português brasileiro
- Se não souber algo, sugira que o visitante entre em contato
- Sempre termine oferecendo mais ajuda
- Seja conciso (2-4 parágrafos no máximo)
- Incentive cadastro/teste gratuito quando apropriado`,
        },
        {
          role: "user",
          content: userMessage,
        },
      ],
      temperature: 0.7,
      max_tokens: 500,
    });

    return completion.choices[0]?.message?.content || "Desculpe, não consegui processar sua mensagem. Pode tentar novamente?";
  } catch (error) {
    console.error("Chatbot error:", error);
    return "Desculpe, estou com problemas técnicos no momento. Por favor, tente novamente em alguns instantes.";
  }
}
