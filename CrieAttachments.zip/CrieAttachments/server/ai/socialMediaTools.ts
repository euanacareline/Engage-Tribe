import OpenAI from "openai";

const openai = new OpenAI({
  apiKey: process.env.OPENAI_API_KEY,
});

export interface YouTubeAIInput {
  videoTopic: string;
  videoType: "short" | "long";
  targetAudience?: string;
}

export interface YouTubeAIOutput {
  title: string;
  description: string;
  tags: string[];
  shortScript?: string;
  longScript?: string;
  thumbnailPrompt: string;
  hookIdeas: string[];
}

export interface InstagramAIInput {
  contentType: "feed" | "reel" | "story" | "carousel";
  topic: string;
  tone?: "motivational" | "educational" | "inspirational" | "casual";
}

export interface InstagramAIOutput {
  caption: string;
  hashtags: string;
  carousel?: string[];
  reelScript?: string;
  callToAction: string;
  engagementQuestion: string;
}

export interface FacebookAIInput {
  postType: "engagement" | "ad" | "story" | "article";
  topic: string;
  audience?: string;
}

export interface FacebookAIOutput {
  post: string;
  imagePrompt?: string;
  adCopy?: string;
  engagementQuestion: string;
  headline?: string;
}

export async function generateYouTubeContent(input: YouTubeAIInput): Promise<YouTubeAIOutput> {
  const systemPrompt = `Você é um especialista em YouTube com foco em alta taxa de clique (CTR) e retenção de audiência.
Seu objetivo é criar conteúdo otimizado para o algoritmo do YouTube que maximize visualizações e engajamento.

Estilo de escrita:
- Direto ao ponto
- Chamativo e curioso
- Focado em retenção
- Otimizado para SEO

Sempre entregue:
1. Título com alta taxa de clique (CTR)
2. Descrição completa com SEO
3. Tags otimizadas
4. Roteiro (short ou long)
5. Prompt para thumbnail
6. Ideias de gancho inicial`;

  const userPrompt = `Crie conteúdo para YouTube sobre: ${input.videoTopic}
Tipo de vídeo: ${input.videoType === "short" ? "YouTube Shorts (até 60 segundos)" : "Vídeo longo (8-15 minutos)"}
${input.targetAudience ? `Público-alvo: ${input.targetAudience}` : ""}

Formate a resposta EXATAMENTE como JSON válido:
{
  "title": "título otimizado",
  "description": "descrição completa com SEO",
  "tags": ["tag1", "tag2", "tag3"],
  ${input.videoType === "short" ? '"shortScript": "roteiro de 60 segundos",' : '"longScript": "roteiro detalhado com introdução, desenvolvimento e conclusão",'}
  "thumbnailPrompt": "prompt para criar thumbnail no DALL-E",
  "hookIdeas": ["gancho 1", "gancho 2", "gancho 3"]
}`;

  const completion = await openai.chat.completions.create({
    model: "gpt-4",
    messages: [
      { role: "system", content: systemPrompt },
      { role: "user", content: userPrompt }
    ],
    temperature: 0.7,
  });

  const content = completion.choices[0].message.content || "{}";
  const jsonMatch = content.match(/\{[\s\S]*\}/);
  const jsonStr = jsonMatch ? jsonMatch[0] : content;
  
  return JSON.parse(jsonStr);
}

export async function generateInstagramContent(input: InstagramAIInput): Promise<InstagramAIOutput> {
  const systemPrompt = `Você é um especialista em Instagram focado em criar conteúdo viral e engajamento autêntico.
Você entende profundamente o algoritmo do Instagram e como criar posts que geram retenção, saves e compartilhamentos.

Estilo de escrita:
- Curto e direto
- Estético e visual
- Emocional ou motivacional
- Formato perfeito para Reels e Feed

Sempre entregue:
1. Legenda otimizada
2. Hashtags estratégicas
3. Call-to-action efetivo
4. Pergunta para engajamento`;

  const contentTypeInstructions = {
    feed: "Crie uma legenda completa para post de feed com storytelling",
    reel: "Crie roteiro de 15-30 segundos para Reel viral",
    story: "Crie texto curto e direto para Story",
    carousel: "Crie slides informativos para carrossel (5-10 slides)"
  };

  const userPrompt = `Crie conteúdo para Instagram sobre: ${input.topic}
Tipo de conteúdo: ${input.contentType}
Tom: ${input.tone || "motivacional"}

Instruções específicas: ${contentTypeInstructions[input.contentType]}

Formate a resposta EXATAMENTE como JSON válido:
{
  "caption": "legenda otimizada",
  "hashtags": "#hashtag1 #hashtag2 #hashtag3",
  ${input.contentType === "carousel" ? '"carousel": ["slide 1", "slide 2", "slide 3", "slide 4", "slide 5"],' : ""}
  ${input.contentType === "reel" ? '"reelScript": "roteiro do reel",' : ""}
  "callToAction": "CTA efetivo",
  "engagementQuestion": "pergunta para gerar comentários"
}`;

  const completion = await openai.chat.completions.create({
    model: "gpt-4",
    messages: [
      { role: "system", content: systemPrompt },
      { role: "user", content: userPrompt }
    ],
    temperature: 0.7,
  });

  const content = completion.choices[0].message.content || "{}";
  const jsonMatch = content.match(/\{[\s\S]*\}/);
  const jsonStr = jsonMatch ? jsonMatch[0] : content;
  
  return JSON.parse(jsonStr);
}

export async function generateFacebookContent(input: FacebookAIInput): Promise<FacebookAIOutput> {
  const systemPrompt = `Você é um especialista em Facebook focado em criar conteúdo que gera conversas e engajamento profundo.
Você entende como criar posts que as pessoas querem comentar, compartilhar e interagir.

Estilo de escrita:
- Histórico e pessoal
- Storytelling emocional
- Conteúdo viral que gera discussão
- Estilo "desabafo" autêntico

Sempre entregue:
1. Post completo e envolvente
2. Pergunta para engajamento
3. Prompt para imagem (se aplicável)`;

  const postTypeInstructions = {
    engagement: "Crie post longo estilo storytelling que gera muitos comentários",
    ad: "Crie copy de anúncio persuasivo com headline e CTA",
    story: "Crie história pessoal emocionante",
    article: "Crie mini-artigo educativo estilo blog"
  };

  const userPrompt = `Crie conteúdo para Facebook sobre: ${input.topic}
Tipo de post: ${input.postType}
${input.audience ? `Público-alvo: ${input.audience}` : ""}

Instruções específicas: ${postTypeInstructions[input.postType]}

Formate a resposta EXATAMENTE como JSON válido:
{
  "post": "texto completo do post",
  ${input.postType === "ad" ? '"headline": "headline do anúncio",' : ""}
  ${input.postType === "ad" ? '"adCopy": "copy persuasivo do anúncio",' : ""}
  "imagePrompt": "prompt para criar imagem no DALL-E",
  "engagementQuestion": "pergunta poderosa para gerar comentários"
}`;

  const completion = await openai.chat.completions.create({
    model: "gpt-4",
    messages: [
      { role: "system", content: systemPrompt },
      { role: "user", content: userPrompt }
    ],
    temperature: 0.7,
  });

  const content = completion.choices[0].message.content || "{}";
  const jsonMatch = content.match(/\{[\s\S]*\}/);
  const jsonStr = jsonMatch ? jsonMatch[0] : content;
  
  return JSON.parse(jsonStr);
}
