import OpenAI from "openai";

const openai = new OpenAI({
  apiKey: process.env.OPENAI_API_KEY,
});

interface ArticleRequest {
  topic: string;
  category: string;
  keywords: string[];
}

interface GeneratedArticle {
  title: string;
  slug: string;
  excerpt: string;
  content: string;
  category: string;
  readTime: string;
  keywords: string[];
}

const ARTICLE_TOPICS = [
  {
    topic: "SEO para Iniciantes: Guia Completo para Rankear no Google em 2025",
    category: "SEO",
    keywords: ["SEO", "Google", "otimização", "tráfego orgânico", "palavras-chave", "backlinks"],
  },
  {
    topic: "Como Aumentar o Tráfego Orgânico do Seu Site em 300%",
    category: "Tráfego Orgânico",
    keywords: ["tráfego orgânico", "SEO", "visitantes", "Google Analytics", "conversão"],
  },
  {
    topic: "Estratégias de Marketing de Conteúdo que Geram Resultados Reais",
    category: "Marketing de Conteúdo",
    keywords: ["marketing de conteúdo", "blog", "estratégia", "ROI", "leads"],
  },
  {
    topic: "Instagram Marketing: Como Crescer Sua Conta Organicamente",
    category: "Redes Sociais",
    keywords: ["Instagram", "redes sociais", "engajamento", "seguidores", "algoritmo"],
  },
  {
    topic: "Link Building: Estratégias Avançadas para Conquistar Backlinks de Qualidade",
    category: "SEO",
    keywords: ["link building", "backlinks", "SEO off-page", "autoridade", "ranking"],
  },
  {
    topic: "Como Criar um Blog de Sucesso que Gera Tráfego e Receita",
    category: "Blogs",
    keywords: ["blog", "WordPress", "monetização", "tráfego", "conteúdo"],
  },
  {
    topic: "Otimização de Conversão: Transforme Visitantes em Clientes",
    category: "Marketing Digital",
    keywords: ["CRO", "conversão", "landing page", "funil de vendas", "taxa de conversão"],
  },
  {
    topic: "Facebook Ads vs Google Ads: Qual a Melhor Opção para Seu Negócio",
    category: "Tráfego Pago",
    keywords: ["Facebook Ads", "Google Ads", "tráfego pago", "ROI", "campanhas"],
  },
  {
    topic: "YouTube SEO: Como Ranquear Seus Vídeos nas Primeiras Posições",
    category: "YouTube",
    keywords: ["YouTube", "SEO para vídeos", "ranking", "visualizações", "otimização"],
  },
  {
    topic: "Email Marketing: Estratégias para Aumentar Taxa de Abertura e Conversão",
    category: "Email Marketing",
    keywords: ["email marketing", "newsletter", "automação", "conversão", "leads"],
  },
  {
    topic: "SEO Local: Como Aparecer no Google Maps e Atrair Clientes Locais",
    category: "SEO",
    keywords: ["SEO local", "Google Maps", "Google Meu Negócio", "pesquisa local"],
  },
  {
    topic: "Content Marketing: Como Criar Conteúdo que Vende",
    category: "Marketing de Conteúdo",
    keywords: ["content marketing", "storytelling", "copywriting", "vendas", "engajamento"],
  },
  {
    topic: "TikTok Marketing: Estratégias para Viralizar e Crescer Rapidamente",
    category: "Redes Sociais",
    keywords: ["TikTok", "viral", "trending", "algoritmo", "criadores"],
  },
  {
    topic: "Google Analytics 4: Guia Completo para Medir Resultados",
    category: "Analytics",
    keywords: ["Google Analytics", "GA4", "métricas", "dados", "relatórios"],
  },
  {
    topic: "Como Criar uma Estratégia de Redes Sociais de Alto Impacto",
    category: "Redes Sociais",
    keywords: ["estratégia", "redes sociais", "planejamento", "engajamento", "ROI"],
  },
  {
    topic: "SEO Técnico: Otimizações Essenciais para Performance do Site",
    category: "SEO",
    keywords: ["SEO técnico", "velocidade", "Core Web Vitals", "indexação", "performance"],
  },
  {
    topic: "Pinterest Marketing: Como Gerar Tráfego Qualificado para Seu Site",
    category: "Redes Sociais",
    keywords: ["Pinterest", "tráfego", "pins", "visual marketing", "referral"],
  },
  {
    topic: "Copywriting para Web: Como Escrever Textos que Convertem",
    category: "Marketing Digital",
    keywords: ["copywriting", "conversão", "persuasão", "headlines", "CTA"],
  },
  {
    topic: "LinkedIn Marketing B2B: Estratégias para Gerar Leads Qualificados",
    category: "Redes Sociais",
    keywords: ["LinkedIn", "B2B", "networking", "leads", "autoridade"],
  },
  {
    topic: "Palavra-Chave: Como Fazer Pesquisa e Escolher as Melhores",
    category: "SEO",
    keywords: ["palavras-chave", "keyword research", "intenção de busca", "volume", "competição"],
  },
];

function generateSlug(title: string): string {
  return title
    .toLowerCase()
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "")
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/^-+|-+$/g, "");
}

function calculateReadTime(content: string): string {
  const wordsPerMinute = 200;
  const words = content.split(/\s+/).length;
  const minutes = Math.ceil(words / wordsPerMinute);
  return `${minutes} min`;
}

export async function generateSEOArticle(): Promise<GeneratedArticle | null> {
  try {
    const randomTopic = ARTICLE_TOPICS[Math.floor(Math.random() * ARTICLE_TOPICS.length)];
    
    const systemPrompt = `Você é um especialista em SEO, marketing digital e tráfego orgânico com 10+ anos de experiência.
Escreva artigos EXTENSOS, PROFUNDOS e EXTREMAMENTE OTIMIZADOS para SEO que ranqueiam nas primeiras páginas do Google.

DIRETRIZES OBRIGATÓRIAS:
- Título: 60-70 caracteres, com palavra-chave principal no início
- Meta Description: 150-160 caracteres, persuasiva e com CTA
- Conteúdo: MÍNIMO 3000 PALAVRAS (não aceitar menos!)
- Estrutura: Introdução + 8-12 seções (H2) + 3-5 subseções por H2 (H3)
- SEO: Use palavra-chave principal 15-20x distribuída naturalmente
- Palavras-chave secundárias: Use variações e sinônimos 30-40x
- Formatação: Markdown com negrito, listas, tabelas, quotes
- Exemplos: Pelo menos 5 exemplos práticos reais
- Dados: Inclua estatísticas e números (pode inventar mas seja realista)
- Links internos: Mencione "veja mais em nosso blog" 3-5x
- CTA: Call-to-action forte no final
- Tom: Profissional, autoritativo, mas acessível
- Valor: Cada seção deve entregar valor acionável

ESTRUTURA IDEAL:
1. Introdução engajadora (problema + promessa de solução)
2. 8-12 seções principais com H2 (cada uma 250-400 palavras)
3. Conclusão com resumo + CTA forte
4. Dicas bônus ou FAQ no final`;

    const userPrompt = `Escreva um artigo EXTENSO e COMPLETO sobre: "${randomTopic.topic}"

Palavras-chave para otimizar: ${randomTopic.keywords.join(", ")}
Categoria: ${randomTopic.category}

REQUISITOS OBRIGATÓRIOS:
- MÍNIMO 3000 palavras (não aceitar menos!)
- Use a palavra-chave principal "${randomTopic.keywords[0]}" pelo menos 15 vezes
- Crie pelo menos 10 seções H2 com conteúdo rico
- Cada H2 deve ter 2-4 subseções H3
- Inclua listas numeradas e bullet points
- Use tabelas comparativas quando aplicável
- Adicione quotes e destaques
- Termine com CTA forte para captura de leads

FORMATO DA RESPOSTA - RETORNE APENAS JSON PURO (sem texto antes ou depois):
{
  "title": "Título otimizado para SEO com palavra-chave no início",
  "excerpt": "Meta description de 150-160 caracteres com CTA e palavra-chave",
  "content": "Conteúdo EXTENSO em Markdown (mínimo 3000 palavras) com H2, H3, listas, tabelas, negrito, quotes, etc."
}

IMPORTANTE: 
- RETORNE APENAS O OBJETO JSON, SEM NENHUM TEXTO ADICIONAL ANTES OU DEPOIS
- O artigo PRECISA ter 3000+ palavras para ranquear bem
- Seja específico, acionável e autoritativo
- Use dados e estatísticas para dar credibilidade
- Inclua exemplos práticos do mundo real`;

    const completion = await openai.chat.completions.create({
      model: "gpt-4",
      messages: [
        { role: "system", content: systemPrompt },
        { role: "user", content: userPrompt },
      ],
      temperature: 0.7,
      max_tokens: 6000,
    });

    const response = completion.choices[0]?.message?.content;
    if (!response) {
      throw new Error("No response from AI");
    }

    // Limpar markdown code blocks se houver
    let jsonContent = response.trim();
    jsonContent = jsonContent.replace(/^```json\s*/g, '').replace(/\s*```$/g, '');
    
    // Extrair apenas o objeto JSON
    const jsonMatch = jsonContent.match(/\{[\s\S]*\}/);
    if (jsonMatch) {
      jsonContent = jsonMatch[0];
    }

    // Tentar parse com tratamento de erros
    let parsed;
    try {
      parsed = JSON.parse(jsonContent);
    } catch (firstError) {
      // Se falhar, tentar com sanitização mais agressiva
      console.log("First JSON parse failed, trying with sanitization...");
      try {
        // Remove control characters EXCETO os que estão dentro de strings válidas
        const sanitized = jsonContent.replace(/[\u0000-\u0008\u000B-\u000C\u000E-\u001F\u007F-\u009F]/g, '');
        parsed = JSON.parse(sanitized);
      } catch (secondError) {
        console.error("JSON parsing failed even after sanitization");
        console.error("Original content:", jsonContent.substring(0, 500));
        throw new Error("Failed to parse AI response as JSON");
      }
    }
    const slug = generateSlug(parsed.title);
    const readTime = calculateReadTime(parsed.content);

    return {
      title: parsed.title,
      slug,
      excerpt: parsed.excerpt,
      content: parsed.content,
      category: randomTopic.category,
      readTime,
      keywords: randomTopic.keywords,
    };
  } catch (error) {
    console.error("Error generating article:", error);
    return null;
  }
}

export async function generateArticleImage(title: string): Promise<string | null> {
  try {
    // DALL-E desabilitado temporariamente
    // A organização OpenAI precisa estar verificada para usar o modelo "gpt-image-1"
    // Erro 403: Organization não verificada para geração de imagens
    // 
    // SOLUÇÃO FUTURA:
    // - Aguardar verificação da organização OpenAI, OU
    // - Usar stock images de APIs gratuitas (Unsplash, Pexels), OU
    // - Usar modelos de imagem alternativos (dall-e-2, dall-e-3)
    //
    // Por enquanto, artigos funcionam perfeitamente sem imagem de capa
    
    // const prompt = `Create a professional, eye-catching blog post cover image for: "${title}". 
    // Style: Modern, clean, professional with vibrant gradients.
    // Elements: Abstract tech shapes, geometric patterns, data visualization elements.
    // Colors: Bold gradients (blue to purple, orange to pink, or teal to blue).
    // Composition: Balanced, minimal text space, perfect for blog header.
    // Quality: High-resolution, professional marketing material.
    // NO TEXT in the image - pure visual design.`;

    // const response = await openai.images.generate({
    //   model: "gpt-image-1",
    //   prompt,
    //   n: 1,
    //   size: "1536x1024",
    // });

    // return response.data?.[0]?.url || null;
    
    return null;
  } catch (error) {
    console.error("Error generating image:", error);
    return null;
  }
}
