import OpenAI from "openai";
import { storage } from "../storage";

const openai = new OpenAI({
  apiKey: process.env.OPENAI_API_KEY,
});

export async function generateHRChatResponse(message: string, adminUserId: string): Promise<string> {
  const staffMembers = await storage.getAllStaffRoles();
  const usersData = await storage.getAllUsers();
  
  const staffContext = staffMembers.map((staff) => {
    const user = usersData.find(u => u.id === staff.userId);
    return {
      name: user ? `${user.firstName} ${user.lastName}` : "Unknown",
      role: staff.role,
      department: staff.department,
      salary: ((staff.salary || 0) / 100).toFixed(2),
      hiredAt: new Date(staff.hiredAt).toLocaleDateString('pt-BR'),
    };
  });

  const completion = await openai.chat.completions.create({
    model: "gpt-4",
    messages: [
      {
        role: "system",
        content: `Você é um assistente de RH especializado da Engage Tribe. Ajude o administrador com informações sobre:

DADOS DA EQUIPE ATUAL:
${JSON.stringify(staffContext, null, 2)}

SUAS RESPONSABILIDADES:
- Responder perguntas sobre funcionários (salários, cargos, departamentos)
- Fornecer análises de custo de folha de pagamento
- Sugerir relatórios e insights de RH
- Ajudar com cálculos de horas trabalhadas e pagamentos
- Orientar sobre gestão de ponto eletrônico
- Fornecer estatísticas sobre a equipe

CAPACIDADES TÉCNICAS:
- Consultar dados de ponto (entrada/saída/pausas)
- Calcular horas trabalhadas por período
- Gerar relatórios de custos mensais/anuais
- Analisar histórico de salários
- Identificar padrões de jornada de trabalho

COMO RESPONDER:
- Seja profissional e objetivo
- Use dados reais quando disponíveis
- Forneça números precisos (salários, horas, custos)
- Responda em português brasileiro
- Seja conciso (2-4 parágrafos máximo)
- Sugira ações práticas quando relevante`,
      },
      {
        role: "user",
        content: message,
      },
    ],
    temperature: 0.7,
    max_tokens: 500,
  });

  return completion.choices[0]?.message?.content || "Desculpe, não consegui processar sua solicitação.";
}
