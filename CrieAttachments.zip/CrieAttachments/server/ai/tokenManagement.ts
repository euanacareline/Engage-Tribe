import { storage } from "../storage";
import type { User } from "@shared/schema";

// Token limits per subscription plan
const DAILY_TOKEN_LIMITS = {
  starter: 5000,   // 5,000 tokens/day for Starter plan (R$ 39.90/month)
  elite: 100000,   // 100,000 tokens/day for Elite plan
  free: 1000,      // 1,000 tokens/day for free users
};

const MONTHLY_TOKEN_LIMITS = {
  pro: 10000,      // 10,000 tokens/month for PRO plan (R$ 497 one-time)
};

// Estimated tokens per AI operation
export const TOKEN_COSTS = {
  youtube_title: 150,
  youtube_description: 300,
  youtube_tags: 100,
  youtube_script_short: 500,
  youtube_script_long: 1000,
  youtube_thumbnail: 200,
  youtube_hooks: 250,
  instagram_caption: 200,
  instagram_hashtags: 100,
  instagram_carousel: 400,
  instagram_reel: 400,
  instagram_engagement: 150,
  instagram_cta: 150,
  facebook_post: 300,
  facebook_ad: 400,
  facebook_story: 350,
  facebook_article: 800,
  facebook_image: 200,
  article_generation: 6000,
  article_image: 500,
};

// Helper function to check if it's a new month
function isNewMonth(lastReset: Date, now: Date): boolean {
  return lastReset.getMonth() !== now.getMonth() || lastReset.getFullYear() !== now.getFullYear();
}

// Check if user has enough tokens (without deducting)
export async function checkTokenAvailability(
  userId: string,
  tokenCost: number
): Promise<{ success: boolean; remainingTokens?: number; error?: string }> {
  try {
    const user = await storage.getUser(userId);
    if (!user) {
      return { success: false, error: "Usuário não encontrado" };
    }

    const userPlan = user.subscriptionPlan || "starter";
    const now = new Date();

    // PRO plan uses monthly limits
    if (userPlan === "pro") {
      const lastReset = user.lastMonthlyTokenReset ? new Date(user.lastMonthlyTokenReset) : new Date(0);
      const shouldResetMonth = isNewMonth(lastReset, now);

      let monthlyTokensUsed = user.monthlyTokensUsed || 0;
      if (shouldResetMonth) {
        monthlyTokensUsed = 0;
      }

      const monthlyLimit = MONTHLY_TOKEN_LIMITS.pro;
      const remainingTokens = monthlyLimit - monthlyTokensUsed;

      if (remainingTokens < tokenCost) {
        return {
          success: false,
          error: `Limite de tokens mensal excedido. Você tem ${remainingTokens} tokens restantes este mês, mas esta operação requer ${tokenCost} tokens. O limite renova no dia 1º do próximo mês.`,
          remainingTokens,
        };
      }

      return {
        success: true,
        remainingTokens,
      };
    }

    // Other plans use daily limits
    const lastReset = user.lastTokenReset ? new Date(user.lastTokenReset) : new Date(0);
    const isNewDay = now.toDateString() !== lastReset.toDateString();

    let tokensUsedToday = user.tokensUsedToday || 0;
    if (isNewDay) {
      tokensUsedToday = 0;
    }

    const dailyLimit = DAILY_TOKEN_LIMITS[userPlan as keyof typeof DAILY_TOKEN_LIMITS] || DAILY_TOKEN_LIMITS.free;
    const remainingTokens = dailyLimit - tokensUsedToday;

    if (remainingTokens < tokenCost) {
      return {
        success: false,
        error: `Limite de tokens diário excedido. Você tem ${remainingTokens} tokens restantes hoje, mas esta operação requer ${tokenCost} tokens.`,
        remainingTokens,
      };
    }

    return {
      success: true,
      remainingTokens,
    };
  } catch (error) {
    console.error("Error checking token availability:", error);
    return {
      success: false,
      error: "Erro ao verificar limite de tokens",
    };
  }
}

// Deduct tokens after successful AI generation with logging
export async function deductTokens(
  userId: string,
  tokenCost: number,
  usageType: string = "unknown",
  model?: string,
  feature?: string,
  inputText?: string,
  outputText?: string
): Promise<{ success: boolean; remainingTokens?: number; error?: string }> {
  try {
    const user = await storage.getUser(userId);
    if (!user) {
      return { success: false, error: "Usuário não encontrado" };
    }

    const userPlan = user.subscriptionPlan || "starter";
    const now = new Date();

    // PRO plan uses monthly limits
    if (userPlan === "pro") {
      const lastReset = user.lastMonthlyTokenReset ? new Date(user.lastMonthlyTokenReset) : new Date(0);
      const shouldResetMonth = isNewMonth(lastReset, now);

      let monthlyTokensUsed = user.monthlyTokensUsed || 0;
      if (shouldResetMonth) {
        monthlyTokensUsed = 0;
      }

      const tokensBefore = monthlyTokensUsed;
      const newMonthlyTokensUsed = monthlyTokensUsed + tokenCost;
      const tokensAfter = newMonthlyTokensUsed;

      const updateData: Partial<User> = {
        monthlyTokensUsed: newMonthlyTokensUsed,
        monthlyTokenLimit: MONTHLY_TOKEN_LIMITS.pro,
      };

      if (shouldResetMonth) {
        updateData.lastMonthlyTokenReset = now;
      }

      await storage.updateUserSubscription(userId, updateData);

      // Log token usage for tracking and admin analytics
      await storage.createTokenUsageLog({
        userId,
        tokensUsed: tokenCost,
        tokensBefore,
        tokensAfter,
        usageType,
        model,
        feature,
        inputText: inputText?.substring(0, 1000), // Limit to 1000 chars
        outputText: outputText?.substring(0, 2000), // Limit to 2000 chars
      });

      return {
        success: true,
        remainingTokens: MONTHLY_TOKEN_LIMITS.pro - newMonthlyTokensUsed,
      };
    }

    // Other plans use daily limits
    const lastReset = user.lastTokenReset ? new Date(user.lastTokenReset) : new Date(0);
    const isNewDay = now.toDateString() !== lastReset.toDateString();

    let tokensUsedToday = user.tokensUsedToday || 0;
    if (isNewDay) {
      tokensUsedToday = 0;
    }

    const tokensBefore = tokensUsedToday;
    const dailyLimit = DAILY_TOKEN_LIMITS[userPlan as keyof typeof DAILY_TOKEN_LIMITS] || DAILY_TOKEN_LIMITS.free;
    const newTokensUsed = tokensUsedToday + tokenCost;
    const tokensAfter = newTokensUsed;

    const updateData: Partial<User> = {
      tokensUsedToday: newTokensUsed,
      dailyTokenLimit: dailyLimit,
    };

    if (isNewDay) {
      updateData.lastTokenReset = now;
    }

    await storage.updateUserSubscription(userId, updateData);

    // Log token usage for tracking and admin analytics
    await storage.createTokenUsageLog({
      userId,
      tokensUsed: tokenCost,
      tokensBefore,
      tokensAfter,
      usageType,
      model,
      feature,
      inputText: inputText?.substring(0, 1000),
      outputText: outputText?.substring(0, 2000),
    });

    return {
      success: true,
      remainingTokens: dailyLimit - newTokensUsed,
    };
  } catch (error) {
    console.error("Error deducting tokens:", error);
    return {
      success: false,
      error: "Erro ao deduzir tokens",
    };
  }
}

export async function getUserTokenStatus(userId: string): Promise<{
  tokensUsed: number;
  limit: number;
  remainingTokens: number;
  plan: string;
  resetTime: string;
  isMonthly: boolean;
}> {
  const user = await storage.getUser(userId);
  if (!user) {
    throw new Error("Usuário não encontrado");
  }

  const userPlan = user.subscriptionPlan || "starter";
  const now = new Date();

  // PRO plan uses monthly limits
  if (userPlan === "pro") {
    const lastReset = user.lastMonthlyTokenReset ? new Date(user.lastMonthlyTokenReset) : new Date(0);
    const shouldResetMonth = isNewMonth(lastReset, now);

    let monthlyTokensUsed = user.monthlyTokensUsed || 0;
    if (shouldResetMonth) {
      monthlyTokensUsed = 0;
      await storage.updateUserSubscription(userId, {
        monthlyTokensUsed: 0,
        lastMonthlyTokenReset: now,
      });
    }

    const monthlyLimit = MONTHLY_TOKEN_LIMITS.pro;
    
    // Calculate first day of next month
    const nextReset = new Date(now.getFullYear(), now.getMonth() + 1, 1, 0, 0, 0, 0);

    return {
      tokensUsed: monthlyTokensUsed,
      limit: monthlyLimit,
      remainingTokens: monthlyLimit - monthlyTokensUsed,
      plan: userPlan,
      resetTime: nextReset.toISOString(),
      isMonthly: true,
    };
  }

  // Other plans use daily limits
  const lastReset = user.lastTokenReset ? new Date(user.lastTokenReset) : new Date(0);
  const isNewDay = now.toDateString() !== lastReset.toDateString();

  let tokensUsedToday = user.tokensUsedToday || 0;
  if (isNewDay) {
    tokensUsedToday = 0;
    await storage.updateUserSubscription(userId, {
      tokensUsedToday: 0,
      lastTokenReset: now,
    });
  }

  const dailyLimit = DAILY_TOKEN_LIMITS[userPlan as keyof typeof DAILY_TOKEN_LIMITS] || DAILY_TOKEN_LIMITS.free;

  // Calculate next reset time (midnight)
  const nextReset = new Date(now);
  nextReset.setHours(24, 0, 0, 0);

  return {
    tokensUsed: tokensUsedToday,
    limit: dailyLimit,
    remainingTokens: dailyLimit - tokensUsedToday,
    plan: userPlan,
    resetTime: nextReset.toISOString(),
    isMonthly: false,
  };
}
