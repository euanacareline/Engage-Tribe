import { storage } from "../storage";
import { generateSEOArticle, generateArticleImage } from "./articleGenerator";

let schedulerInterval: NodeJS.Timeout | null = null;
let isGenerating = false;

async function generateAndPublishArticle() {
  if (isGenerating) {
    console.log("[Article Scheduler] Already generating an article, skipping...");
    return;
  }

  isGenerating = true;
  console.log("[Article Scheduler] Starting article generation...");

  try {
    const article = await generateSEOArticle();
    
    if (!article) {
      console.error("[Article Scheduler] Failed to generate article");
      isGenerating = false;
      return;
    }

    console.log(`[Article Scheduler] Generated article: "${article.title}"`);

    const existingPost = await storage.getBlogPostBySlug(article.slug);
    if (existingPost) {
      console.log("[Article Scheduler] Article with this slug already exists, skipping...");
      isGenerating = false;
      return;
    }

    console.log("[Article Scheduler] Generating cover image...");
    const coverImage = await generateArticleImage(article.title);

    let authorId = "ai-system";
    try {
      const adminUsers = await storage.getAllUsers(100, 0);
      const adminUser = adminUsers.find(u => u.isAdmin);
      
      if (adminUser) {
        authorId = adminUser.id;
      } else {
        const aiUser = await storage.upsertUser({
          id: "ai-system",
          email: "ai@engagetribe.com",
          firstName: "Engage",
          lastName: "Tribe AI",
          isAdmin: true,
        });
        authorId = aiUser.id;
      }
    } catch (error) {
      console.error("[Article Scheduler] Error getting author:", error);
      const aiUser = await storage.upsertUser({
        id: "ai-system",
        email: "ai@engagetribe.com",
        firstName: "Engage",
        lastName: "Tribe AI",
        isAdmin: true,
      });
      authorId = aiUser.id;
    }

    await storage.createBlogPost({
      authorId,
      title: article.title,
      slug: article.slug,
      excerpt: article.excerpt,
      content: article.content,
      coverImage: coverImage || undefined,
      category: article.category,
      readTime: article.readTime,
      published: true,
    });

    console.log(`[Article Scheduler] ✅ Published article: "${article.title}"`);
  } catch (error) {
    console.error("[Article Scheduler] Error generating article:", error);
  } finally {
    isGenerating = false;
  }
}

export function startArticleScheduler() {
  if (schedulerInterval) {
    console.log("[Article Scheduler] Already running");
    return;
  }

  console.log("[Article Scheduler] Starting - will publish 1 article every 5 minutes");

  generateAndPublishArticle();

  schedulerInterval = setInterval(() => {
    generateAndPublishArticle();
  }, 5 * 60 * 1000);
}

export function stopArticleScheduler() {
  if (schedulerInterval) {
    clearInterval(schedulerInterval);
    schedulerInterval = null;
    console.log("[Article Scheduler] Stopped");
  }
}
