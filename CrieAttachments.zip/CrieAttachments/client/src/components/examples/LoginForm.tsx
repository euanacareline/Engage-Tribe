import { LoginForm } from '../auth/LoginForm';

export default function LoginFormExample() {
  return (
    <div className="min-h-screen flex items-center justify-center p-4">
      <LoginForm />
    </div>
  );
}
