import { StatsCard } from '../dashboard/StatsCard';
import { Eye } from 'lucide-react';

export default function StatsCardExample() {
  return (
    <div className="p-8 max-w-sm">
      <StatsCard
        title="Visualizações YouTube"
        value="12,345"
        icon={Eye}
        trend={{ value: 23, label: "vs. mês anterior" }}
      />
    </div>
  );
}
