import { BlogCard } from '../blog/BlogCard';

export default function BlogCardExample() {
  return (
    <div className="p-8 max-w-md">
      <BlogCard
        id="1"
        title="Como crescer no YouTube em 2024"
        excerpt="Descubra as estratégias que funcionam para crescimento orgânico no YouTube neste ano."
        category="YouTube"
        author={{ name: "João Silva" }}
        readTime="5 min"
        publishedAt="15 Jan"
      />
    </div>
  );
}
