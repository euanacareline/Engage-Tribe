import { Youtube, Music2, FileText, Twitter, Linkedin } from "lucide-react";

export function Footer() {
  return (
    <footer className="bg-card border-t mt-20">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          <div>
            <div className="flex items-center gap-2 mb-4">
              <div className="w-8 h-8 rounded-lg bg-primary flex items-center justify-center">
                <span className="text-primary-foreground font-bold text-sm">ET</span>
              </div>
              <span className="font-bold text-lg">Engage Tribe</span>
            </div>
            <p className="text-sm text-muted-foreground mb-4">
              Conexão inteligente entre criadores de conteúdo, com reciprocidade real.
            </p>
            <div className="flex items-center gap-3">
              <a href="#" target="_blank" rel="noopener noreferrer" className="hover-elevate p-2 rounded-md" aria-label="YouTube">
                <Youtube className="h-5 w-5" />
              </a>
              <a href="#" target="_blank" rel="noopener noreferrer" className="hover-elevate p-2 rounded-md" aria-label="Spotify">
                <Music2 className="h-5 w-5" />
              </a>
              <a href="#" target="_blank" rel="noopener noreferrer" className="hover-elevate p-2 rounded-md" aria-label="Medium">
                <FileText className="h-5 w-5" />
              </a>
              <a href="#" target="_blank" rel="noopener noreferrer" className="hover-elevate p-2 rounded-md" aria-label="Twitter">
                <Twitter className="h-5 w-5" />
              </a>
              <a href="#" target="_blank" rel="noopener noreferrer" className="hover-elevate p-2 rounded-md" aria-label="LinkedIn">
                <Linkedin className="h-5 w-5" />
              </a>
            </div>
          </div>

          <div>
            <h3 className="font-semibold mb-4">Produto</h3>
            <ul className="space-y-2">
              <li>
                <a href="/#como-funciona" className="text-sm text-muted-foreground hover:text-foreground" data-testid="link-footer-how-it-works">
                  Como Funciona
                </a>
              </li>
              <li>
                <a href="/#planos" className="text-sm text-muted-foreground hover:text-foreground" data-testid="link-footer-plans">
                  Planos
                </a>
              </li>
              <li>
                <a href="/blog" className="text-sm text-muted-foreground hover:text-foreground" data-testid="link-footer-blog">
                  Blog
                </a>
              </li>
            </ul>
          </div>

          <div>
            <h3 className="font-semibold mb-4">Conteúdo</h3>
            <ul className="space-y-2">
              <li>
                <a href="#" target="_blank" rel="noopener noreferrer" className="text-sm text-muted-foreground hover:text-foreground flex items-center gap-2">
                  <Youtube className="h-4 w-4" />
                  YouTube
                </a>
              </li>
              <li>
                <a href="#" target="_blank" rel="noopener noreferrer" className="text-sm text-muted-foreground hover:text-foreground flex items-center gap-2">
                  <Music2 className="h-4 w-4" />
                  Podcast
                </a>
              </li>
              <li>
                <a href="#" target="_blank" rel="noopener noreferrer" className="text-sm text-muted-foreground hover:text-foreground flex items-center gap-2">
                  <FileText className="h-4 w-4" />
                  Medium
                </a>
              </li>
            </ul>
          </div>

          <div>
            <h3 className="font-semibold mb-4">Legal</h3>
            <ul className="space-y-2">
              <li>
                <a href="/privacy" className="text-sm text-muted-foreground hover:text-foreground" data-testid="link-footer-privacy">
                  Política de Privacidade
                </a>
              </li>
              <li>
                <a href="/cookies" className="text-sm text-muted-foreground hover:text-foreground" data-testid="link-footer-cookies">
                  Política de Cookies
                </a>
              </li>
            </ul>
          </div>
        </div>

        <div className="mt-12 pt-8 border-t text-center">
          <p className="text-sm text-muted-foreground">
            © {new Date().getFullYear()} Engage Tribe. Todos os direitos reservados.
          </p>
        </div>
      </div>
    </footer>
  );
}
