import { Card, CardContent, CardFooter, CardHeader } from "@/components/ui/card";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";
import { Clock, Calendar } from "lucide-react";
import { Link } from "wouter";

interface BlogCardProps {
  id: string;
  title: string;
  excerpt: string;
  coverImage?: string;
  author: {
    name: string;
    avatar?: string;
  };
  category: string;
  readTime: string;
  publishedAt: string;
}

export function BlogCard({ id, title, excerpt, coverImage, author, category, readTime, publishedAt }: BlogCardProps) {
  return (
    <Link href={`/blog/${id}`}>
      <Card className="overflow-hidden hover-elevate cursor-pointer h-full flex flex-col" data-testid={`blog-card-${id}`}>
        {coverImage && (
          <div className="aspect-video bg-muted overflow-hidden">
            <img 
              src={coverImage} 
              alt={title}
              className="w-full h-full object-cover transition-transform hover:scale-105"
            />
          </div>
        )}
        <CardHeader className="flex-1">
          <Badge variant="secondary" className="w-fit mb-2">{category}</Badge>
          <h3 className="text-lg sm:text-xl font-semibold line-clamp-2 leading-tight">{title}</h3>
        </CardHeader>
        <CardContent>
          <p className="text-muted-foreground line-clamp-3 text-sm leading-relaxed">{excerpt}</p>
        </CardContent>
        <CardFooter className="flex items-center justify-between gap-2 flex-wrap">
          <div className="flex items-center gap-2 min-w-0">
            <Avatar className="h-6 w-6 flex-shrink-0">
              <AvatarImage src={author.avatar} />
              <AvatarFallback className="text-xs">{author.name[0]}</AvatarFallback>
            </Avatar>
            <span className="text-xs sm:text-sm text-muted-foreground truncate">{author.name}</span>
          </div>
          <div className="flex items-center gap-3 sm:gap-4 text-xs text-muted-foreground flex-shrink-0">
            <span className="flex items-center gap-1">
              <Clock className="h-3 w-3" />
              {readTime}
            </span>
            <span className="flex items-center gap-1 hidden sm:flex">
              <Calendar className="h-3 w-3" />
              {publishedAt}
            </span>
          </div>
        </CardFooter>
      </Card>
    </Link>
  );
}
