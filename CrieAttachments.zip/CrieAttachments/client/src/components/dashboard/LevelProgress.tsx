import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { Badge } from "@/components/ui/badge";
import { Trophy, Zap } from "lucide-react";

interface LevelProgressProps {
  currentLevel: string;
  currentPoints: number;
  nextLevelPoints: number;
  totalPoints: number;
}

const levelColors = {
  "Iniciante": "bg-gray-500",
  "Ativo": "bg-blue-500",
  "Power": "bg-purple-500",
  "Elite": "bg-amber-500",
};

export function LevelProgress({ currentLevel, currentPoints, nextLevelPoints, totalPoints }: LevelProgressProps) {
  const progress = (currentPoints / nextLevelPoints) * 100;

  return (
    <Card>
      <CardHeader>
        <div className="flex items-center justify-between gap-2 flex-wrap">
          <div>
            <CardTitle>Seu Nível</CardTitle>
            <CardDescription>Continue engajando para subir de nível</CardDescription>
          </div>
          <Badge className="gap-1">
            <Trophy className="h-3 w-3" />
            {currentLevel}
          </Badge>
        </div>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="flex items-center justify-between gap-4">
          <div className="flex items-center gap-2">
            <Zap className="h-5 w-5 text-primary" />
            <span className="text-2xl font-bold font-mono" data-testid="text-current-points">{currentPoints.toLocaleString()}</span>
          </div>
          <span className="text-sm text-muted-foreground">de {nextLevelPoints.toLocaleString()} pontos</span>
        </div>
        
        <div className="space-y-2">
          <Progress value={progress} className="h-2" data-testid="progress-level" />
          <p className="text-xs text-muted-foreground">
            Faltam {(nextLevelPoints - currentPoints).toLocaleString()} pontos para o próximo nível
          </p>
        </div>

        <div className="pt-2 border-t">
          <p className="text-xs text-muted-foreground mb-2">Total de pontos ganhos</p>
          <p className="text-xl font-bold font-mono">{totalPoints.toLocaleString()}</p>
        </div>
      </CardContent>
    </Card>
  );
}
