import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";
import { Heart, MessageCircle, Share2, Eye } from "lucide-react";

interface Activity {
  id: string;
  type: 'view' | 'comment' | 'share' | 'like';
  user: {
    name: string;
    avatar?: string;
  };
  content: string;
  points: number;
  timestamp: string;
}

interface ActivityFeedProps {
  activities?: Activity[];
}

const iconMap = {
  view: Eye,
  comment: MessageCircle,
  share: Share2,
  like: Heart,
};

export function ActivityFeed({ activities = [] }: ActivityFeedProps) {
  return (
    <Card>
      <CardHeader>
        <CardTitle>Atividade Recente</CardTitle>
        <CardDescription>Engajamento que você recebeu hoje</CardDescription>
      </CardHeader>
      <CardContent className="space-y-4">
        {activities.length === 0 ? (
          <p className="text-sm text-muted-foreground text-center py-8">
            Nenhuma atividade ainda. Comece a engajar com outros criadores!
          </p>
        ) : (
          activities.map((activity) => {
            const Icon = iconMap[activity.type];
            return (
              <div key={activity.id} className="flex items-start gap-4 hover-elevate rounded-lg p-3" data-testid={`activity-${activity.id}`}>
                <Avatar>
                  <AvatarImage src={activity.user.avatar} />
                  <AvatarFallback>{activity.user.name[0]}</AvatarFallback>
                </Avatar>
                <div className="flex-1 space-y-1 min-w-0">
                  <div className="flex items-center gap-2 flex-wrap">
                    <p className="text-sm font-medium">{activity.user.name}</p>
                    <Badge variant="secondary" className="gap-1">
                      <Icon className="h-3 w-3" />
                      {activity.type === 'view' ? 'visualizou' : activity.type === 'comment' ? 'comentou' : activity.type === 'share' ? 'compartilhou' : 'curtiu'}
                    </Badge>
                  </div>
                  <p className="text-sm text-muted-foreground line-clamp-2">{activity.content}</p>
                  <div className="flex items-center gap-4 text-xs text-muted-foreground">
                    <span>{activity.timestamp}</span>
                    <span className="text-primary font-medium">+{activity.points} pontos</span>
                  </div>
                </div>
              </div>
            );
          })
        )}
      </CardContent>
    </Card>
  );
}
