import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { CheckCircle2, Crown, TrendingUp, Target, Users, Gift, Eye } from "lucide-react";

interface PlanBenefitsProps {
  subscriptionTier: string;
}

export function PlanBenefits({ subscriptionTier }: PlanBenefitsProps) {
  const isStarter = subscriptionTier === "starter";
  const isPro = subscriptionTier === "pro";
  
  if (!isStarter && !isPro) return null;

  const benefits = isStarter ? [
    {
      icon: Eye,
      title: "+1.000 Visualizações Diárias",
      description: "Receba mais de 1.000 visualizações todos os dias em uma de suas redes sociais",
    },
    {
      icon: TrendingUp,
      title: "Rateio de 10% do Lucro",
      description: "Faça parte do rateio de 10% do lucro da plataforma após 6 meses de participação",
    },
    {
      icon: Target,
      title: "5 Tarefas Diárias",
      description: "Complete 5 tarefas por dia nas redes sociais (visitar, curtir, comentar, compartilhar)",
    },
  ] : [
    {
      icon: Gift,
      title: "Rede Social Nova",
      description: "Receba uma nova rede social para expandir sua presença online",
    },
    {
      icon: Users,
      title: "Conselho Consultivo",
      description: "Participe do Conselho Consultivo com reuniões trimestrais (a cada 3 meses)",
    },
    {
      icon: TrendingUp,
      title: "Rateio de 15% do Lucro",
      description: "Participe do rateio de 15% do lucro da plataforma após 6 meses",
    },
    {
      icon: Crown,
      title: "Participação Exclusiva",
      description: "Sua participação é pessoal e intransferível, garantindo exclusividade",
    },
  ];

  return (
    <Card className="p-6">
      <div className="flex items-center justify-between mb-6">
        <div>
          <h3 className="text-lg font-semibold flex items-center gap-2" data-testid="heading-plan-benefits">
            {isPro && <Crown className="h-5 w-5 text-yellow-500" data-testid="icon-crown" />}
            Benefícios do Seu Plano
          </h3>
          <p className="text-sm text-muted-foreground" data-testid="text-plan-description">
            Aproveite todos os recursos exclusivos
          </p>
        </div>
        <Badge variant={isPro ? "default" : "secondary"} className="px-3 py-1" data-testid="badge-plan-price">
          {isPro ? "PRO - R$ 497,00" : "Starter - R$ 39,90/mês"}
        </Badge>
      </div>

      <div className="space-y-4">
        {benefits.map((benefit, index) => (
          <div key={index} className="flex gap-3" data-testid={`benefit-${index}`}>
            <div className="flex-shrink-0 w-10 h-10 rounded-lg bg-primary/10 flex items-center justify-center">
              <benefit.icon className="h-5 w-5 text-primary" />
            </div>
            <div className="flex-1">
              <div className="flex items-start gap-2">
                <CheckCircle2 className="h-4 w-4 text-green-500 mt-0.5 flex-shrink-0" />
                <div>
                  <h4 className="font-medium text-sm">{benefit.title}</h4>
                  <p className="text-xs text-muted-foreground mt-1">
                    {benefit.description}
                  </p>
                </div>
              </div>
            </div>
          </div>
        ))}
      </div>

      {isPro && (
        <div className="mt-6 p-3 rounded-lg bg-yellow-500/10 border border-yellow-500/20" data-testid="card-founder-badge">
          <p className="text-xs text-yellow-700 dark:text-yellow-400 flex items-center gap-2" data-testid="text-founder-message">
            <Crown className="h-3 w-3" />
            <span className="font-medium">Membro Fundador:</span> Benefícios vitalícios e exclusivos
          </p>
        </div>
      )}
    </Card>
  );
}
