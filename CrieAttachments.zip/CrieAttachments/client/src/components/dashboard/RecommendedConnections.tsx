import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { UserPlus } from "lucide-react";

interface Connection {
  id: string;
  name: string;
  avatar?: string;
  niche: string;
  matchScore: number;
  followers: string;
}

interface RecommendedConnectionsProps {
  connections?: Connection[];
}

export function RecommendedConnections({ connections = [] }: RecommendedConnectionsProps) {
  return (
    <Card>
      <CardHeader>
        <CardTitle>Conexões Recomendadas</CardTitle>
        <CardDescription>Criadores compatíveis com seu perfil</CardDescription>
      </CardHeader>
      <CardContent className="space-y-4">
        {connections.length === 0 ? (
          <p className="text-sm text-muted-foreground text-center py-8">
            Complete seu perfil para receber recomendações personalizadas
          </p>
        ) : (
          connections.map((connection) => (
            <div key={connection.id} className="flex items-center gap-4 hover-elevate rounded-lg p-3" data-testid={`connection-${connection.id}`}>
              <Avatar>
                <AvatarImage src={connection.avatar} />
                <AvatarFallback>{connection.name[0]}</AvatarFallback>
              </Avatar>
              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-2 flex-wrap mb-1">
                  <p className="text-sm font-medium">{connection.name}</p>
                  <Badge variant="secondary" className="text-xs">
                    {connection.matchScore}% match
                  </Badge>
                </div>
                <p className="text-xs text-muted-foreground">{connection.niche}</p>
                <p className="text-xs text-muted-foreground">{connection.followers} seguidores</p>
              </div>
              <Button size="sm" variant="outline" className="gap-1 shrink-0" data-testid={`button-connect-${connection.id}`}>
                <UserPlus className="h-4 w-4" />
                <span className="hidden sm:inline">Conectar</span>
              </Button>
            </div>
          ))
        )}
      </CardContent>
    </Card>
  );
}
