import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Award, Lock } from "lucide-react";

interface Achievement {
  id: string;
  title: string;
  description: string;
  unlocked: boolean;
  unlockedAt?: string;
}

interface AchievementsListProps {
  achievements?: Achievement[];
}

export function AchievementsList({ achievements = [] }: AchievementsListProps) {
  const unlockedCount = achievements.filter(a => a.unlocked).length;

  return (
    <Card>
      <CardHeader>
        <div className="flex items-center justify-between gap-2 flex-wrap">
          <div>
            <CardTitle>Conquistas</CardTitle>
            <CardDescription>
              {unlockedCount} de {achievements.length} desbloqueadas
            </CardDescription>
          </div>
          <Badge variant="secondary" className="gap-1">
            <Award className="h-3 w-3" />
            {unlockedCount}
          </Badge>
        </div>
      </CardHeader>
      <CardContent className="space-y-3">
        {achievements.map((achievement) => (
          <div 
            key={achievement.id}
            className={`flex items-start gap-4 p-3 rounded-lg border ${achievement.unlocked ? 'bg-primary/5 border-primary/20' : 'opacity-50'}`}
            data-testid={`achievement-${achievement.id}`}
          >
            <div className={`w-10 h-10 rounded-full flex items-center justify-center shrink-0 ${achievement.unlocked ? 'bg-primary/10' : 'bg-muted'}`}>
              {achievement.unlocked ? (
                <Award className="h-5 w-5 text-primary" />
              ) : (
                <Lock className="h-5 w-5 text-muted-foreground" />
              )}
            </div>
            <div className="flex-1 min-w-0">
              <p className="text-sm font-medium">{achievement.title}</p>
              <p className="text-xs text-muted-foreground mt-1">{achievement.description}</p>
              {achievement.unlocked && achievement.unlockedAt && (
                <p className="text-xs text-primary mt-1">Desbloqueada em {achievement.unlockedAt}</p>
              )}
            </div>
          </div>
        ))}
      </CardContent>
    </Card>
  );
}
