import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Zap, Clock } from "lucide-react";

interface TokenStatus {
  tokensUsed: number;
  limit: number;
  remainingTokens: number;
  plan: string;
  resetTime: string;
  isMonthly: boolean;
}

export function TokenStatus() {
  const { data: tokenStatus, isLoading, error } = useQuery<TokenStatus>({
    queryKey: ["/api/ai-tools/token-status"],
  });

  if (isLoading) {
    return (
      <Card data-testid="card-token-status-loading">
        <CardHeader>
          <CardTitle className="text-sm font-medium">Tokens Disponíveis</CardTitle>
        </CardHeader>
        <CardContent>
          <p className="text-sm text-muted-foreground">Carregando...</p>
        </CardContent>
      </Card>
    );
  }

  if (error || !tokenStatus) {
    return (
      <Card data-testid="card-token-status-error">
        <CardHeader>
          <CardTitle className="text-sm font-medium">Tokens Disponíveis</CardTitle>
        </CardHeader>
        <CardContent>
          <p className="text-sm text-destructive">
            Erro ao carregar status de tokens. Faça login para continuar.
          </p>
        </CardContent>
      </Card>
    );
  }

  const percentage = (tokenStatus.tokensUsed / tokenStatus.limit) * 100;
  const isLow = percentage > 80;
  const isCritical = percentage > 95;

  const resetDate = new Date(tokenStatus.resetTime);
  const now = new Date();
  const timeUntilReset = resetDate.getTime() - now.getTime();
  const hoursUntilReset = Math.ceil(timeUntilReset / (1000 * 60 * 60));
  const daysUntilReset = Math.ceil(timeUntilReset / (1000 * 60 * 60 * 24));

  return (
    <Card data-testid="card-token-status">
      <CardHeader className="flex flex-row items-center justify-between gap-2 space-y-0 pb-2">
        <CardTitle className="text-sm font-medium">
          Tokens Disponíveis {tokenStatus.isMonthly ? "(Mensal)" : "(Diário)"}
        </CardTitle>
        <Badge 
          variant={isCritical ? "destructive" : isLow ? "secondary" : "default"}
          data-testid="badge-token-plan"
        >
          {tokenStatus.plan.toUpperCase()}
        </Badge>
      </CardHeader>
      <CardContent>
        <div className="space-y-2">
          <div className="flex items-baseline justify-between">
            <div>
              <span className="text-2xl font-bold" data-testid="text-tokens-remaining">
                {tokenStatus.remainingTokens.toLocaleString()}
              </span>
              <span className="text-muted-foreground ml-1">
                / {tokenStatus.limit.toLocaleString()}
              </span>
            </div>
            <div className="flex items-center gap-1 text-xs text-muted-foreground">
              <Clock className="h-3 w-3" />
              <span data-testid="text-reset-time">
                {tokenStatus.isMonthly 
                  ? `Reset em ${daysUntilReset}d` 
                  : `Reset em ${hoursUntilReset}h`}
              </span>
            </div>
          </div>
          
          <div className="w-full bg-secondary rounded-full h-2">
            <div
              className={`h-2 rounded-full transition-all ${
                isCritical
                  ? "bg-destructive"
                  : isLow
                  ? "bg-yellow-500"
                  : "bg-primary"
              }`}
              style={{ width: `${Math.min(100, percentage)}%` }}
              data-testid="progress-token-usage"
            />
          </div>

          <p className="text-xs text-muted-foreground flex items-center gap-1">
            <Zap className="h-3 w-3" />
            {tokenStatus.tokensUsed.toLocaleString()} tokens usados {tokenStatus.isMonthly ? "este mês" : "hoje"}
          </p>
        </div>
      </CardContent>
    </Card>
  );
}
