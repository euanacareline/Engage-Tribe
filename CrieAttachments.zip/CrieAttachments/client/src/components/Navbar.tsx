import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { ThemeToggle } from "./ThemeToggle";
import { Menu, X } from "lucide-react";
import { useState } from "react";

interface NavbarProps {
  isAuthenticated?: boolean;
  isAdmin?: boolean;
}

export function Navbar({ isAuthenticated = false, isAdmin = false }: NavbarProps) {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  return (
    <nav className="fixed top-0 left-0 right-0 z-50 bg-background/80 backdrop-blur-lg border-b">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16 gap-4">
          <a href="/" className="flex items-center gap-2 hover-elevate active-elevate-2 rounded-lg px-3 py-2" data-testid="link-home">
            <div className="w-8 h-8 rounded-lg bg-primary flex items-center justify-center">
              <span className="text-primary-foreground font-bold text-sm">ET</span>
            </div>
            <span className="font-bold text-xl hidden sm:block">Engage Tribe</span>
          </a>

          <div className="hidden md:flex items-center gap-6">
            <a href="/#como-funciona" className="text-sm font-medium hover-elevate active-elevate-2 px-3 py-2 rounded-md" data-testid="link-how-it-works">
              Como Funciona
            </a>
            <a href="/#planos" className="text-sm font-medium hover-elevate active-elevate-2 px-3 py-2 rounded-md" data-testid="link-plans">
              Planos
            </a>
            <a href="/blog" className="text-sm font-medium hover-elevate active-elevate-2 px-3 py-2 rounded-md" data-testid="link-blog">
              Blog
            </a>
          </div>

          <div className="flex items-center gap-2">
            <ThemeToggle />
            
            {!isAuthenticated ? (
              <div className="hidden md:flex items-center gap-2">
                <Button variant="ghost" asChild data-testid="button-login">
                  <a href="/login">Entrar</a>
                </Button>
                <Button asChild data-testid="button-signup">
                  <a href="/cadastro">Começar Agora</a>
                </Button>
              </div>
            ) : (
              <div className="hidden md:flex items-center gap-2">
                <Button variant="ghost" asChild data-testid="button-dashboard">
                  <a href={isAdmin ? "/admin" : "/dashboard"}>
                    {isAdmin ? "Admin" : "Dashboard"}
                  </a>
                </Button>
                <Button variant="ghost" data-testid="button-logout">
                  Sair
                </Button>
              </div>
            )}

            <Button
              variant="ghost"
              size="icon"
              className="md:hidden"
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              data-testid="button-mobile-menu"
            >
              {mobileMenuOpen ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
            </Button>
          </div>
        </div>
      </div>

      {mobileMenuOpen && (
        <div className="md:hidden border-t bg-background">
          <div className="px-4 py-4 space-y-2">
            <a href="/#como-funciona" className="block px-3 py-2 rounded-md hover-elevate active-elevate-2" data-testid="link-mobile-how-it-works">
              Como Funciona
            </a>
            <a href="/#planos" className="block px-3 py-2 rounded-md hover-elevate active-elevate-2" data-testid="link-mobile-plans">
              Planos
            </a>
            <a href="/blog" className="block px-3 py-2 rounded-md hover-elevate active-elevate-2" data-testid="link-mobile-blog">
              Blog
            </a>
            <div className="pt-2 space-y-2">
              {!isAuthenticated ? (
                <>
                  <Button variant="ghost" className="w-full" asChild data-testid="button-mobile-login">
                    <a href="/login">Entrar</a>
                  </Button>
                  <Button className="w-full" asChild data-testid="button-mobile-signup">
                    <a href="/cadastro">Começar Agora</a>
                  </Button>
                </>
              ) : (
                <>
                  <Button variant="ghost" className="w-full" asChild data-testid="button-mobile-dashboard">
                    <a href={isAdmin ? "/admin" : "/dashboard"}>
                      {isAdmin ? "Admin" : "Dashboard"}
                    </a>
                  </Button>
                  <Button variant="ghost" className="w-full" data-testid="button-mobile-logout">
                    Sair
                  </Button>
                </>
              )}
            </div>
          </div>
        </div>
      )}
    </nav>
  );
}
