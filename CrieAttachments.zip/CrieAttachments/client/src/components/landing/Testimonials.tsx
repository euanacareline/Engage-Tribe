import { Card, CardContent } from "@/components/ui/card";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Star } from "lucide-react";
import femaleAvatar from "@assets/generated_images/Testimonial_avatar_female_a7e227ea.png";
import maleAvatar from "@assets/generated_images/Testimonial_avatar_male_ef47a8a6.png";

const testimonials = [
  {
    name: "Ana Paula Silva",
    role: "YouTuber de Lifestyle",
    avatar: femaleAvatar,
    content: "A Engage Tribe mudou completamente minha estratégia de crescimento. Em 3 meses, meu canal cresceu 280% com engajamento real e autêntico!",
    rating: 5,
  },
  {
    name: "Carlos Eduardo",
    role: "Criador de Conteúdo Tech",
    avatar: maleAvatar,
    content: "Finalmente encontrei uma plataforma que entende o valor da reciprocidade genuína. As conexões que fiz aqui são incríveis!",
    rating: 5,
  },
  {
    name: "Juliana Martins",
    role: "Influenciadora Digital",
    avatar: femaleAvatar,
    content: "O sistema de pontos e gamificação torna tudo muito mais divertido. Além disso, os resultados são mensuráveis e reais.",
    rating: 5,
  },
];

export function Testimonials() {
  return (
    <section className="py-20 bg-card">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-bold mb-4">O Que Dizem Nossos Criadores</h2>
          <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
            Milhares de criadores já estão crescendo com a Engage Tribe
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {testimonials.map((testimonial, index) => (
            <Card key={index} className="hover-elevate" data-testid={`testimonial-${index}`}>
              <CardContent className="pt-6">
                <div className="flex gap-1 mb-4">
                  {Array.from({ length: testimonial.rating }).map((_, i) => (
                    <Star key={i} className="h-5 w-5 fill-primary text-primary" />
                  ))}
                </div>
                
                <p className="text-muted-foreground mb-6 leading-relaxed">
                  "{testimonial.content}"
                </p>

                <div className="flex items-center gap-3">
                  <Avatar>
                    <AvatarImage src={testimonial.avatar} alt={testimonial.name} />
                    <AvatarFallback>{testimonial.name.split(' ').map(n => n[0]).join('')}</AvatarFallback>
                  </Avatar>
                  <div>
                    <div className="font-semibold">{testimonial.name}</div>
                    <div className="text-sm text-muted-foreground">{testimonial.role}</div>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </section>
  );
}
