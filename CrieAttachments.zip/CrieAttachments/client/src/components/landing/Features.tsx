import { Sparkles, Target, BarChart3, Shield, Users, Zap } from "lucide-react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";

const features = [
  {
    icon: Sparkles,
    title: "Engine de Reciprocidade",
    description: "Algoritmo inteligente que conecta você com criadores compatíveis baseado em nicho, qualidade e timing perfeito.",
  },
  {
    icon: Target,
    title: "Matching por Nicho",
    description: "Encontre criadores do seu segmento automaticamente para colaborações e engajamento genuíno.",
  },
  {
    icon: BarChart3,
    title: "Analytics em Tempo Real",
    description: "Acompanhe suas métricas de crescimento, engajamento e desempenho com dashboards completos.",
  },
  {
    icon: Shield,
    title: "Sistema de Reputação",
    description: "Construa sua credibilidade com pontuação baseada em qualidade e consistência das interações.",
  },
  {
    icon: Users,
    title: "Comunidade Ativa",
    description: "Faça parte de uma comunidade engajada de milhares de criadores de conteúdo autênticos.",
  },
  {
    icon: Zap,
    title: "Gamificação Inteligente",
    description: "Sistema de pontos, níveis e conquistas que tornam o crescimento divertido e motivador.",
  },
];

export function Features() {
  return (
    <section className="py-20">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-bold mb-4">Recursos Poderosos</h2>
          <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
            Tudo que você precisa para crescer sua audiência de forma orgânica e autêntica
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {features.map((feature, index) => (
            <Card key={index} className="hover-elevate" data-testid={`feature-${index}`}>
              <CardHeader>
                <div className="w-12 h-12 rounded-lg bg-primary/10 flex items-center justify-center mb-4">
                  <feature.icon className="h-6 w-6 text-primary" />
                </div>
                <CardTitle>{feature.title}</CardTitle>
              </CardHeader>
              <CardContent>
                <CardDescription className="text-base leading-relaxed">
                  {feature.description}
                </CardDescription>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </section>
  );
}
