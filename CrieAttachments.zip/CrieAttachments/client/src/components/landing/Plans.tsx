import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Check } from "lucide-react";
import { Link } from "wouter";

const plans = [
  {
    name: "Starter",
    price: "R$ 39,90",
    period: "/mês",
    description: "Ideal para criadores que estão começando a crescer",
    features: [
      "+1.000 visualizações diárias garantidas em uma rede social",
      "5 tarefas diárias obrigatórias (visitar, curtir, comentar, compartilhar)",
      "Sistema de reciprocidade com criadores do seu nicho",
      "Dashboard com métricas de crescimento",
      "Participação no rateio de 10% do lucro da plataforma após 6 meses",
      "Suporte por email",
    ],
    cta: "Em Breve",
    checkoutUrl: "#",
    popular: false,
  },
  {
    name: "PRO - Membros Fundadores",
    price: "R$ 497,00",
    period: "pagamento único",
    description: "Edição limitada com benefícios vitalícios e exclusivos",
    features: [
      "Recebe uma nova rede social para expandir presença",
      "Participação no Conselho Consultivo (reuniões a cada 3 meses)",
      "Participação no rateio de 15% do lucro da plataforma após 6 meses",
      "Sistema de reciprocidade prioritário",
      "Dashboard executivo com analytics avançado",
      "Participação pessoal e intransferível (não passa para herdeiros)",
      "Benefícios vitalícios garantidos",
      "Suporte prioritário 24/7",
    ],
    cta: "Vagas Limitadas",
    checkoutUrl: "#",
    popular: true,
  },
];

export function Plans() {
  return (
    <section id="planos" className="py-20">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-bold mb-4">Escolha seu Plano</h2>
          <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
            Planos flexíveis para criadores de todos os tamanhos
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 max-w-5xl mx-auto">
          {plans.map((plan, index) => (
            <Card 
              key={index}
              className={`relative flex flex-col ${plan.popular ? 'border-primary shadow-xl scale-105' : ''}`}
              data-testid={`plan-${plan.name.toLowerCase()}`}
            >
              {plan.popular && (
                <div className="absolute -top-4 left-1/2 -translate-x-1/2">
                  <span className="bg-primary text-primary-foreground px-4 py-1 rounded-full text-sm font-semibold">
                    Mais Popular
                  </span>
                </div>
              )}
              
              <CardHeader>
                <CardTitle className="text-2xl">{plan.name}</CardTitle>
                <CardDescription>{plan.description}</CardDescription>
                <div className="mt-4">
                  <span className="text-4xl font-bold">{plan.price}</span>
                  <span className="text-muted-foreground">{plan.period}</span>
                </div>
              </CardHeader>

              <CardContent className="flex-1">
                <ul className="space-y-3">
                  {plan.features.map((feature, featureIndex) => (
                    <li key={featureIndex} className="flex items-start gap-3">
                      <Check className="h-5 w-5 text-primary shrink-0 mt-0.5" />
                      <span className="text-sm">{feature}</span>
                    </li>
                  ))}
                </ul>
              </CardContent>

              <CardFooter>
                <Button 
                  className="w-full" 
                  variant={plan.popular ? "default" : "outline"}
                  disabled={plan.checkoutUrl === "#"}
                  data-testid={`button-select-${plan.name.toLowerCase()}`}
                >
                  {plan.cta}
                </Button>
              </CardFooter>
            </Card>
          ))}
        </div>
      </div>
    </section>
  );
}
