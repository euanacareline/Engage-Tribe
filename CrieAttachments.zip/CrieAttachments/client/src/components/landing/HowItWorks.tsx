import { UserPlus, Heart, TrendingUp, Award } from "lucide-react";

const steps = [
  {
    number: "01",
    icon: UserPlus,
    title: "Cadastre-se",
    description: "Crie sua conta gratuita e configure seu perfil de criador de conteúdo em poucos minutos.",
  },
  {
    number: "02",
    icon: Heart,
    title: "Engaje com Outros",
    description: "Interaja com conteúdo de outros criadores através de visualizações, comentários e compartilhamentos.",
  },
  {
    number: "03",
    icon: TrendingUp,
    title: "Receba Reciprocidade",
    description: "Nossa IA conecta você com criadores compatíveis que retribuirão seu engajamento de forma autêntica.",
  },
  {
    number: "04",
    icon: Award,
    title: "Cresça Organicamente",
    description: "Acompanhe seu crescimento através de métricas reais e desbloqueie conquistas conforme avança.",
  },
];

export function HowItWorks() {
  return (
    <section id="como-funciona" className="py-20 bg-card">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-bold mb-4">Como Funciona</h2>
          <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
            Um sistema simples e eficaz para crescer sua audiência de forma orgânica
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {steps.map((step, index) => (
            <div 
              key={index} 
              className="relative hover-elevate active-elevate-2 rounded-xl p-6"
              data-testid={`step-${step.number}`}
            >
              <div className="absolute -top-4 -left-4 text-8xl font-mono font-bold text-primary/10">
                {step.number}
              </div>
              <div className="relative">
                <div className="w-16 h-16 rounded-xl bg-primary/10 flex items-center justify-center mb-6">
                  <step.icon className="h-8 w-8 text-primary" />
                </div>
                <h3 className="text-xl font-semibold mb-3">{step.title}</h3>
                <p className="text-muted-foreground">{step.description}</p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
