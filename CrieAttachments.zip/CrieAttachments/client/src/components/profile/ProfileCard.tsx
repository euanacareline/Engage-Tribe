import { Card, CardContent, CardHeader } from "@/components/ui/card";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { MapPin, Link as LinkIcon, Calendar } from "lucide-react";

interface ProfileCardProps {
  user: {
    name: string;
    avatar?: string;
    bio?: string;
    location?: string;
    website?: string;
    joinedAt: string;
    level: string;
    niches: string[];
  };
}

export function ProfileCard({ user }: ProfileCardProps) {
  return (
    <Card>
      <CardHeader>
        <div className="flex flex-col sm:flex-row items-start sm:items-center gap-4">
          <Avatar className="h-20 w-20">
            <AvatarImage src={user.avatar} />
            <AvatarFallback className="text-2xl">{user.name[0]}</AvatarFallback>
          </Avatar>
          <div className="flex-1">
            <div className="flex items-center gap-2 flex-wrap mb-2">
              <h2 className="text-2xl font-bold">{user.name}</h2>
              <Badge>{user.level}</Badge>
            </div>
            {user.bio && (
              <p className="text-muted-foreground mb-2">{user.bio}</p>
            )}
            <div className="flex flex-wrap gap-4 text-sm text-muted-foreground">
              {user.location && (
                <span className="flex items-center gap-1">
                  <MapPin className="h-4 w-4" />
                  {user.location}
                </span>
              )}
              {user.website && (
                <a href={user.website} target="_blank" rel="noopener noreferrer" className="flex items-center gap-1 hover:text-foreground">
                  <LinkIcon className="h-4 w-4" />
                  {new URL(user.website).hostname}
                </a>
              )}
              <span className="flex items-center gap-1">
                <Calendar className="h-4 w-4" />
                Desde {user.joinedAt}
              </span>
            </div>
          </div>
          <Button data-testid="button-edit-profile">Editar Perfil</Button>
        </div>
      </CardHeader>
      <CardContent>
        <div>
          <h3 className="text-sm font-semibold mb-2">Nichos</h3>
          <div className="flex flex-wrap gap-2">
            {user.niches.map((niche, index) => (
              <Badge key={index} variant="outline">{niche}</Badge>
            ))}
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
