import { useParams } from "wouter";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Navbar } from "@/components/Navbar";
import { Footer } from "@/components/Footer";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card } from "@/components/ui/card";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Clock, Calendar, ArrowLeft, Mail } from "lucide-react";
import { Link } from "wouter";
import type { BlogPost as BlogPostType } from "@shared/schema";
import { useState } from "react";
import { useToast } from "@/hooks/use-toast";
import ReactMarkdown from 'react-markdown';
import remarkGfm from 'remark-gfm';
import { apiRequest } from "@/lib/queryClient";

export default function BlogPost() {
  const { id } = useParams();
  const [email, setEmail] = useState("");
  const { toast } = useToast();

  const { data: post, isLoading } = useQuery<BlogPostType>({
    queryKey: ["/api/blog", id],
    enabled: !!id,
  });

  const subscribeMutation = useMutation({
    mutationFn: async (email: string) => {
      return await apiRequest("POST", "/api/newsletter/subscribe", { email });
    },
    onSuccess: () => {
      toast({
        title: "Inscrição realizada!",
        description: "Você receberá nossos melhores conteúdos sobre marketing digital.",
      });
      setEmail("");
    },
    onError: () => {
      toast({
        title: "Erro",
        description: "Este email já está cadastrado ou ocorreu um erro.",
        variant: "destructive",
      });
    },
  });

  const handleSubscribe = (e: React.FormEvent) => {
    e.preventDefault();
    if (!email) return;
    subscribeMutation.mutate(email);
  };

  if (isLoading) {
    return (
      <div className="min-h-screen">
        <Navbar />
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-24">
          <p className="text-center text-muted-foreground">Carregando artigo...</p>
        </div>
        <Footer />
      </div>
    );
  }

  if (!post) {
    return (
      <div className="min-h-screen">
        <Navbar />
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-24 text-center">
          <h1 className="text-3xl font-bold mb-4">Artigo não encontrado</h1>
          <Link href="/blog">
            <Button variant="outline" className="gap-2">
              <ArrowLeft className="h-4 w-4" />
              Voltar ao Blog
            </Button>
          </Link>
        </div>
        <Footer />
      </div>
    );
  }

  return (
    <div className="min-h-screen">
      <Navbar />
      
      <article className="pt-24 pb-12">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <Link href="/blog">
            <Button variant="ghost" size="sm" className="gap-2 mb-6">
              <ArrowLeft className="h-4 w-4" />
              Voltar ao Blog
            </Button>
          </Link>

          <Badge variant="secondary" className="mb-4">{post.category}</Badge>
          
          <h1 className="text-3xl sm:text-4xl md:text-5xl font-bold mb-6 leading-tight">
            {post.title}
          </h1>

          <div className="flex items-center gap-6 text-sm text-muted-foreground mb-8 flex-wrap">
            <div className="flex items-center gap-2">
              <Avatar className="h-8 w-8">
                <AvatarImage src="" />
                <AvatarFallback className="text-xs">ET</AvatarFallback>
              </Avatar>
              <span>Engage Tribe AI</span>
            </div>
            <span className="flex items-center gap-1">
              <Calendar className="h-4 w-4" />
              {new Date(post.createdAt).toLocaleDateString('pt-BR', {
                day: 'numeric',
                month: 'long',
                year: 'numeric'
              })}
            </span>
            <span className="flex items-center gap-1">
              <Clock className="h-4 w-4" />
              {post.readTime}
            </span>
          </div>

          {post.coverImage && (
            <div className="aspect-video rounded-lg overflow-hidden mb-12 bg-muted">
              <img 
                src={post.coverImage} 
                alt={post.title}
                className="w-full h-full object-cover"
                data-testid="blog-cover-image"
              />
            </div>
          )}

          <div className="prose prose-lg max-w-none prose-headings:font-bold prose-h2:text-2xl prose-h2:mt-12 prose-h2:mb-4 prose-h3:text-xl prose-h3:mt-8 prose-h3:mb-3 prose-p:leading-relaxed prose-p:mb-4 prose-li:mb-2 prose-a:text-primary prose-a:no-underline hover:prose-a:underline prose-strong:text-foreground prose-blockquote:border-l-4 prose-blockquote:border-primary prose-blockquote:pl-4 prose-blockquote:italic prose-img:rounded-lg prose-ul:list-disc prose-ul:pl-6 prose-ol:list-decimal prose-ol:pl-6 prose-table:border prose-th:border prose-th:p-2 prose-td:border prose-td:p-2">
            <ReactMarkdown remarkPlugins={[remarkGfm]}>
              {post.content}
            </ReactMarkdown>
          </div>

          <Card className="mt-16 p-8 bg-gradient-to-br from-primary/5 to-primary/10 border-primary/20">
            <div className="text-center max-w-2xl mx-auto">
              <div className="inline-flex items-center justify-center w-16 h-16 rounded-full bg-primary/10 mb-4">
                <Mail className="h-8 w-8 text-primary" />
              </div>
              <h3 className="text-2xl font-bold mb-3">
                Quer receber mais conteúdo como este?
              </h3>
              <p className="text-muted-foreground mb-6">
                Cadastre-se e receba semanalmente estratégias exclusivas de marketing digital, 
                SEO e tráfego orgânico direto no seu email. 100% gratuito!
              </p>
              <form onSubmit={handleSubscribe} className="flex gap-2 max-w-md mx-auto">
                <Input
                  type="email"
                  placeholder="Seu melhor email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  className="flex-1"
                  required
                  data-testid="input-subscribe-email"
                />
                <Button type="submit" disabled={subscribeMutation.isPending} data-testid="button-subscribe">
                  {subscribeMutation.isPending ? "Cadastrando..." : "Quero Receber"}
                </Button>
              </form>
              <p className="text-xs text-muted-foreground mt-4">
                Seus dados estão protegidos. Sem spam.
              </p>
            </div>
          </Card>
        </div>
      </article>

      <Footer />
    </div>
  );
}

