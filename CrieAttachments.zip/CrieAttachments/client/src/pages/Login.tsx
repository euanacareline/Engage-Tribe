import { LoginForm } from "@/components/auth/LoginForm";
import { Navbar } from "@/components/Navbar";

export default function Login() {
  return (
    <div className="min-h-screen flex flex-col">
      <Navbar />
      <div className="flex-1 flex items-center justify-center p-4 pt-24">
        <LoginForm />
      </div>
    </div>
  );
}
