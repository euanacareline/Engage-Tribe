import { Navbar } from "@/components/Navbar";
import { Footer } from "@/components/Footer";
import { ProfileCard } from "@/components/profile/ProfileCard";
import { StatsCard } from "@/components/dashboard/StatsCard";
import { Eye, Heart, Share2, TrendingUp } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";

// TODO: Remove mock data
const mockUser = {
  name: "Ana Paula Silva",
  bio: "Criadora de conteúdo apaixonada por tecnologia e inovação. Compartilhando conhecimento sobre YouTube e redes sociais.",
  location: "São Paulo, Brasil",
  website: "https://anapaulasilva.com",
  joinedAt: "Janeiro 2024",
  level: "Ativo",
  niches: ["Tecnologia", "YouTube", "Educação", "Marketing Digital"],
};

export default function Profile() {
  return (
    <div className="min-h-screen">
      <Navbar isAuthenticated={true} />
      
      <div className="pt-24 pb-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-6">
          <ProfileCard user={mockUser} />

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
            <StatsCard
              title="Visualizações Totais"
              value="125,430"
              icon={Eye}
              description="Todas as plataformas"
            />
            <StatsCard
              title="Engajamento Total"
              value="42,180"
              icon={Heart}
              description="Curtidas e comentários"
            />
            <StatsCard
              title="Compartilhamentos"
              value="8,234"
              icon={Share2}
              description="Total compartilhado"
            />
            <StatsCard
              title="Pontos Acumulados"
              value="18,567"
              icon={TrendingUp}
              description="Desde o início"
            />
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle>Métricas do YouTube</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex justify-between items-center">
                  <span className="text-sm text-muted-foreground">Inscritos</span>
                  <span className="text-lg font-bold font-mono">25,430</span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-sm text-muted-foreground">Visualizações (30d)</span>
                  <span className="text-lg font-bold font-mono">84,250</span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-sm text-muted-foreground">Vídeos Publicados</span>
                  <span className="text-lg font-bold font-mono">127</span>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Métricas do Instagram</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex justify-between items-center">
                  <span className="text-sm text-muted-foreground">Seguidores</span>
                  <span className="text-lg font-bold font-mono">18,920</span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-sm text-muted-foreground">Taxa de Engajamento</span>
                  <span className="text-lg font-bold font-mono">4.8%</span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-sm text-muted-foreground">Posts (30d)</span>
                  <span className="text-lg font-bold font-mono">42</span>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>

      <Footer />
    </div>
  );
}
