import { Card } from "@/components/ui/card";

export default function Privacy() {
  return (
    <div className="container max-w-4xl mx-auto py-12 px-4">
      <h1 className="text-4xl font-bold mb-8" data-testid="heading-privacy">Política de Privacidade</h1>
      
      <Card className="p-8 space-y-6" data-testid="card-privacy">
        <section>
          <h2 className="text-2xl font-semibold mb-4" data-testid="heading-section-1">1. Informações que Coletamos</h2>
          <p className="text-muted-foreground" data-testid="text-section-1">
            A Engage Tribe coleta informações necessárias para fornecer nossos serviços, incluindo:
            nome, email, informações de perfil de redes sociais, dados de engajamento e métricas de desempenho.
            Todas as informações são tratadas com confidencialidade e segurança.
          </p>
        </section>

        <section>
          <h2 className="text-2xl font-semibold mb-4" data-testid="heading-section-2">2. Como Usamos suas Informações</h2>
          <p className="text-muted-foreground" data-testid="text-section-2">
            Utilizamos suas informações para: fornecer e melhorar nossos serviços, personalizar sua experiência,
            processar transações, enviar comunicações importantes sobre a plataforma, e analisar padrões
            de uso para otimizar a experiência do usuário.
          </p>
        </section>

        <section>
          <h2 className="text-2xl font-semibold mb-4" data-testid="heading-section-3">3. Compartilhamento de Dados</h2>
          <p className="text-muted-foreground" data-testid="text-section-3">
            Não vendemos suas informações pessoais. Compartilhamos dados apenas quando necessário
            para operar a plataforma (processadores de pagamento, serviços de hospedagem) ou quando
            exigido por lei. Todos os parceiros são cuidadosamente selecionados e seguem rigorosos
            padrões de segurança.
          </p>
        </section>

        <section>
          <h2 className="text-2xl font-semibold mb-4" data-testid="heading-section-4">4. Cookies e Tecnologias Similares</h2>
          <p className="text-muted-foreground" data-testid="text-section-4">
            Utilizamos cookies essenciais para funcionamento da plataforma, cookies de desempenho
            para melhorar a experiência, e cookies de publicidade (Google AdSense) para monetização.
            Você pode gerenciar suas preferências de cookies nas configurações do navegador.
          </p>
        </section>

        <section>
          <h2 className="text-2xl font-semibold mb-4" data-testid="heading-section-5">5. Seus Direitos</h2>
          <p className="text-muted-foreground" data-testid="text-section-5">
            Você tem direito a acessar, corrigir, deletar ou exportar suas informações pessoais.
            Para exercer esses direitos ou tirar dúvidas sobre privacidade, entre em contato através
            do email: privacidade@engagetribe.com
          </p>
        </section>

        <section>
          <h2 className="text-2xl font-semibold mb-4" data-testid="heading-section-6">6. Segurança</h2>
          <p className="text-muted-foreground" data-testid="text-section-6">
            Implementamos medidas de segurança técnicas e organizacionais para proteger suas informações
            contra acesso não autorizado, alteração, divulgação ou destruição.
          </p>
        </section>

        <section>
          <h2 className="text-2xl font-semibold mb-4" data-testid="heading-section-7">7. Alterações nesta Política</h2>
          <p className="text-muted-foreground" data-testid="text-section-7">
            Esta política pode ser atualizada periodicamente. Notificaremos usuários sobre mudanças
            significativas por email ou através de aviso na plataforma.
          </p>
        </section>

        <div className="pt-6 border-t">
          <p className="text-sm text-muted-foreground" data-testid="text-last-updated">
            Última atualização: Novembro de 2025
          </p>
        </div>
      </Card>
    </div>
  );
}
