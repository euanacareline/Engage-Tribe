import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { useState } from "react";

export default function Cookies() {
  const [preferences, setPreferences] = useState({
    essential: true,
    analytics: true,
    advertising: true,
  });

  const handleSave = () => {
    localStorage.setItem('cookiePreferences', JSON.stringify(preferences));
    window.location.reload();
  };

  return (
    <div className="container max-w-4xl mx-auto py-12 px-4">
      <h1 className="text-4xl font-bold mb-8" data-testid="heading-cookies">Política de Cookies</h1>
      
      <Card className="p-8 space-y-6 mb-8" data-testid="card-cookies-policy">
        <section>
          <h2 className="text-2xl font-semibold mb-4" data-testid="heading-what-are-cookies">O que são Cookies?</h2>
          <p className="text-muted-foreground" data-testid="text-what-are-cookies">
            Cookies são pequenos arquivos de texto armazenados em seu dispositivo quando você visita
            um site. Eles ajudam a melhorar sua experiência, lembrar preferências e fornecer
            funcionalidades essenciais da plataforma.
          </p>
        </section>

        <section>
          <h2 className="text-2xl font-semibold mb-4" data-testid="heading-cookie-types">Tipos de Cookies que Usamos</h2>
          
          <div className="space-y-4">
            <div>
              <h3 className="font-semibold mb-2" data-testid="heading-essential-cookies">Cookies Essenciais (Obrigatórios)</h3>
              <p className="text-muted-foreground text-sm" data-testid="text-essential-cookies">
                Necessários para o funcionamento básico da plataforma, como autenticação,
                sessão do usuário e segurança. Não podem ser desabilitados.
              </p>
            </div>

            <div>
              <h3 className="font-semibold mb-2" data-testid="heading-performance-cookies">Cookies de Desempenho e Análise</h3>
              <p className="text-muted-foreground text-sm" data-testid="text-performance-cookies">
                Coletam informações sobre como você usa a plataforma para nos ajudar a melhorar
                o desempenho e a experiência do usuário.
              </p>
            </div>

            <div>
              <h3 className="font-semibold mb-2" data-testid="heading-advertising-cookies">Cookies de Publicidade (Google AdSense)</h3>
              <p className="text-muted-foreground text-sm" data-testid="text-advertising-cookies">
                Usados para exibir anúncios relevantes através do Google AdSense. Esses cookies
                ajudam a monetizar a plataforma e manter nossos serviços gratuitos ou acessíveis.
              </p>
            </div>
          </div>
        </section>

        <section>
          <h2 className="text-2xl font-semibold mb-4" data-testid="heading-manage-preferences">Gerenciar suas Preferências</h2>
          <p className="text-muted-foreground mb-4" data-testid="text-manage-intro">
            Você pode controlar quais cookies aceita. Note que desabilitar certos cookies pode
            afetar a funcionalidade da plataforma.
          </p>
          
          <div className="space-y-3 bg-muted p-4 rounded-md" data-testid="container-preferences">
            <div className="flex items-center justify-between">
              <div>
                <p className="font-medium" data-testid="text-essential-label">Cookies Essenciais</p>
                <p className="text-sm text-muted-foreground" data-testid="text-essential-status">Sempre ativados</p>
              </div>
              <span className="text-sm text-muted-foreground" data-testid="text-essential-required">Obrigatório</span>
            </div>

            <div className="flex items-center justify-between">
              <div>
                <p className="font-medium" data-testid="text-analytics-label">Cookies de Análise</p>
                <p className="text-sm text-muted-foreground" data-testid="text-analytics-help">Melhoram a experiência</p>
              </div>
              <Button
                variant={preferences.analytics ? "default" : "outline"}
                size="sm"
                onClick={() => setPreferences({...preferences, analytics: !preferences.analytics})}
                data-testid="button-toggle-analytics"
              >
                {preferences.analytics ? "Ativado" : "Desativado"}
              </Button>
            </div>

            <div className="flex items-center justify-between">
              <div>
                <p className="font-medium" data-testid="text-advertising-label">Cookies de Publicidade</p>
                <p className="text-sm text-muted-foreground" data-testid="text-advertising-platform">Google AdSense</p>
              </div>
              <Button
                variant={preferences.advertising ? "default" : "outline"}
                size="sm"
                onClick={() => setPreferences({...preferences, advertising: !preferences.advertising})}
                data-testid="button-toggle-advertising"
              >
                {preferences.advertising ? "Ativado" : "Desativado"}
              </Button>
            </div>
          </div>

          <Button 
            className="mt-4 w-full" 
            onClick={handleSave}
            data-testid="button-save-preferences"
          >
            Salvar Preferências
          </Button>
        </section>

        <div className="pt-6 border-t">
          <p className="text-sm text-muted-foreground" data-testid="text-privacy-link">
            Para mais informações sobre privacidade, consulte nossa <a href="/privacy" className="underline">Política de Privacidade</a>.
          </p>
          <p className="text-sm text-muted-foreground mt-2" data-testid="text-cookies-last-updated">
            Última atualização: Novembro de 2025
          </p>
        </div>
      </Card>
    </div>
  );
}
