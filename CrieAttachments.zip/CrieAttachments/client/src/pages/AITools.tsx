import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import { Youtube, Instagram, Facebook, Sparkles, History, Copy, Check } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { TokenStatus } from "@/components/TokenStatus";

interface YouTubeResult {
  title: string;
  description: string;
  tags: string[];
  shortScript?: string;
  longScript?: string;
  thumbnailPrompt: string;
  hookIdeas: string[];
}

interface InstagramResult {
  caption: string;
  hashtags: string;
  carousel?: string[];
  reelScript?: string;
  callToAction: string;
  engagementQuestion: string;
}

interface FacebookResult {
  post: string;
  imagePrompt?: string;
  adCopy?: string;
  engagementQuestion: string;
  headline?: string;
}

export default function AITools() {
  const { toast } = useToast();
  const [activeTab, setActiveTab] = useState("youtube");
  const [copiedField, setCopiedField] = useState<string | null>(null);

  const [youtubeData, setYoutubeData] = useState({
    videoTopic: "",
    videoType: "short" as "short" | "long",
    targetAudience: "",
  });

  const [instagramData, setInstagramData] = useState({
    contentType: "reel" as "feed" | "reel" | "story" | "carousel",
    topic: "",
    tone: "motivational" as "motivational" | "educational" | "inspirational" | "casual",
  });

  const [facebookData, setFacebookData] = useState({
    postType: "engagement" as "engagement" | "ad" | "story" | "article",
    topic: "",
    audience: "",
  });

  const [youtubeResult, setYoutubeResult] = useState<YouTubeResult | null>(null);
  const [instagramResult, setInstagramResult] = useState<InstagramResult | null>(null);
  const [facebookResult, setFacebookResult] = useState<FacebookResult | null>(null);

  const youtubeMutation = useMutation({
    mutationFn: async (data: typeof youtubeData) => {
      const response = await apiRequest("POST", "/api/ai-tools/youtube", data);
      return await response.json() as YouTubeResult;
    },
    onSuccess: (data) => {
      setYoutubeResult(data);
      toast({ title: "Conteúdo gerado com sucesso!" });
      queryClient.invalidateQueries({ queryKey: ["/api/ai-tools/token-status"] });
    },
    onError: (error: any) => {
      toast({ 
        title: error.message || "Erro ao gerar conteúdo", 
        variant: "destructive" 
      });
    },
  });

  const instagramMutation = useMutation({
    mutationFn: async (data: typeof instagramData) => {
      const response = await apiRequest("POST", "/api/ai-tools/instagram", data);
      return await response.json() as InstagramResult;
    },
    onSuccess: (data) => {
      setInstagramResult(data);
      toast({ title: "Conteúdo gerado com sucesso!" });
      queryClient.invalidateQueries({ queryKey: ["/api/ai-tools/token-status"] });
    },
    onError: (error: any) => {
      toast({ 
        title: error.message || "Erro ao gerar conteúdo", 
        variant: "destructive" 
      });
    },
  });

  const facebookMutation = useMutation({
    mutationFn: async (data: typeof facebookData) => {
      const response = await apiRequest("POST", "/api/ai-tools/facebook", data);
      return await response.json() as FacebookResult;
    },
    onSuccess: (data) => {
      setFacebookResult(data);
      toast({ title: "Conteúdo gerado com sucesso!" });
      queryClient.invalidateQueries({ queryKey: ["/api/ai-tools/token-status"] });
    },
    onError: (error: any) => {
      toast({ 
        title: error.message || "Erro ao gerar conteúdo", 
        variant: "destructive" 
      });
    },
  });

  const copyToClipboard = async (text: string, field: string) => {
    await navigator.clipboard.writeText(text);
    setCopiedField(field);
    toast({ title: "Copiado para área de transferência!" });
    setTimeout(() => setCopiedField(null), 2000);
  };

  return (
    <div className="min-h-screen bg-background">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="mb-8">
          <div className="flex items-center gap-3 mb-2">
            <Sparkles className="h-8 w-8 text-primary" />
            <h1 className="text-4xl font-bold">Ferramentas IA PRO</h1>
          </div>
          <p className="text-lg text-muted-foreground">
            IAs especializadas para cada rede social - Exclusivo para membros PRO
          </p>
        </div>

        <div className="mb-6 max-w-md">
          <TokenStatus />
        </div>

        <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
          <TabsList className="grid w-full grid-cols-3">
            <TabsTrigger value="youtube" className="gap-2" data-testid="tab-youtube">
              <Youtube className="h-4 w-4" />
              YouTube
            </TabsTrigger>
            <TabsTrigger value="instagram" className="gap-2" data-testid="tab-instagram">
              <Instagram className="h-4 w-4" />
              Instagram
            </TabsTrigger>
            <TabsTrigger value="facebook" className="gap-2" data-testid="tab-facebook">
              <Facebook className="h-4 w-4" />
              Facebook
            </TabsTrigger>
          </TabsList>

          <TabsContent value="youtube" className="space-y-6">
            <div className="grid md:grid-cols-2 gap-6">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Youtube className="h-5 w-5" />
                    Gerador YouTube
                  </CardTitle>
                  <CardDescription>
                    Títulos, descrições, tags e roteiros otimizados para CTR
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="space-y-2">
                    <Label htmlFor="youtube-topic">Tópico do Vídeo</Label>
                    <Input
                      id="youtube-topic"
                      placeholder="Ex: Como aumentar seguidores no Instagram"
                      value={youtubeData.videoTopic}
                      onChange={(e) => setYoutubeData({ ...youtubeData, videoTopic: e.target.value })}
                      data-testid="input-youtube-topic"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="youtube-type">Tipo de Vídeo</Label>
                    <Select
                      value={youtubeData.videoType}
                      onValueChange={(value: "short" | "long") => setYoutubeData({ ...youtubeData, videoType: value })}
                    >
                      <SelectTrigger id="youtube-type" data-testid="select-youtube-type">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="short">YouTube Shorts (60s)</SelectItem>
                        <SelectItem value="long">Vídeo Longo (8-15min)</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="youtube-audience">Público-Alvo (Opcional)</Label>
                    <Input
                      id="youtube-audience"
                      placeholder="Ex: Criadores de conteúdo iniciantes"
                      value={youtubeData.targetAudience}
                      onChange={(e) => setYoutubeData({ ...youtubeData, targetAudience: e.target.value })}
                      data-testid="input-youtube-audience"
                    />
                  </div>
                </CardContent>
                <CardFooter>
                  <Button
                    className="w-full"
                    onClick={() => youtubeMutation.mutate(youtubeData)}
                    disabled={!youtubeData.videoTopic || youtubeMutation.isPending}
                    data-testid="button-generate-youtube"
                  >
                    {youtubeMutation.isPending ? "Gerando..." : "Gerar Conteúdo"}
                  </Button>
                </CardFooter>
              </Card>

              {youtubeResult && (
                <Card>
                  <CardHeader>
                    <CardTitle>Resultado</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="space-y-2">
                      <div className="flex items-center justify-between">
                        <Label className="text-sm font-semibold">Título</Label>
                        <Button
                          size="sm"
                          variant="ghost"
                          onClick={() => copyToClipboard(youtubeResult.title, "youtube-title")}
                          data-testid="button-copy-youtube-title"
                        >
                          {copiedField === "youtube-title" ? <Check className="h-4 w-4" /> : <Copy className="h-4 w-4" />}
                        </Button>
                      </div>
                      <p className="text-sm p-3 bg-muted rounded-md" data-testid="result-youtube-title">{youtubeResult.title}</p>
                    </div>

                    <div className="space-y-2">
                      <div className="flex items-center justify-between">
                        <Label className="text-sm font-semibold">Descrição</Label>
                        <Button
                          size="sm"
                          variant="ghost"
                          onClick={() => copyToClipboard(youtubeResult.description, "youtube-desc")}
                        >
                          {copiedField === "youtube-desc" ? <Check className="h-4 w-4" /> : <Copy className="h-4 w-4" />}
                        </Button>
                      </div>
                      <p className="text-sm p-3 bg-muted rounded-md whitespace-pre-wrap" data-testid="result-youtube-description">{youtubeResult.description}</p>
                    </div>

                    <div className="space-y-2">
                      <Label className="text-sm font-semibold">Tags</Label>
                      <div className="flex flex-wrap gap-2">
                        {youtubeResult.tags.map((tag, i) => (
                          <Badge key={i} variant="secondary">{tag}</Badge>
                        ))}
                      </div>
                    </div>

                    {youtubeResult.shortScript && (
                      <div className="space-y-2">
                        <div className="flex items-center justify-between">
                          <Label className="text-sm font-semibold">Roteiro Short</Label>
                          <Button
                            size="sm"
                            variant="ghost"
                            onClick={() => copyToClipboard(youtubeResult.shortScript!, "youtube-script")}
                          >
                            {copiedField === "youtube-script" ? <Check className="h-4 w-4" /> : <Copy className="h-4 w-4" />}
                          </Button>
                        </div>
                        <p className="text-sm p-3 bg-muted rounded-md whitespace-pre-wrap">{youtubeResult.shortScript}</p>
                      </div>
                    )}

                    {youtubeResult.longScript && (
                      <div className="space-y-2">
                        <div className="flex items-center justify-between">
                          <Label className="text-sm font-semibold">Roteiro Completo</Label>
                          <Button
                            size="sm"
                            variant="ghost"
                            onClick={() => copyToClipboard(youtubeResult.longScript!, "youtube-long-script")}
                          >
                            {copiedField === "youtube-long-script" ? <Check className="h-4 w-4" /> : <Copy className="h-4 w-4" />}
                          </Button>
                        </div>
                        <p className="text-sm p-3 bg-muted rounded-md whitespace-pre-wrap max-h-64 overflow-y-auto">{youtubeResult.longScript}</p>
                      </div>
                    )}
                  </CardContent>
                </Card>
              )}
            </div>
          </TabsContent>

          <TabsContent value="instagram" className="space-y-6">
            <div className="grid md:grid-cols-2 gap-6">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Instagram className="h-5 w-5" />
                    Gerador Instagram
                  </CardTitle>
                  <CardDescription>
                    Legendas, reels, carrosséis e hashtags estratégicas
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="space-y-2">
                    <Label htmlFor="instagram-type">Tipo de Conteúdo</Label>
                    <Select
                      value={instagramData.contentType}
                      onValueChange={(value: typeof instagramData.contentType) => setInstagramData({ ...instagramData, contentType: value })}
                    >
                      <SelectTrigger id="instagram-type" data-testid="select-instagram-type">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="feed">Post de Feed</SelectItem>
                        <SelectItem value="reel">Reel</SelectItem>
                        <SelectItem value="story">Story</SelectItem>
                        <SelectItem value="carousel">Carrossel</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="instagram-topic">Tópico</Label>
                    <Input
                      id="instagram-topic"
                      placeholder="Ex: Dicas de produtividade para criadores"
                      value={instagramData.topic}
                      onChange={(e) => setInstagramData({ ...instagramData, topic: e.target.value })}
                      data-testid="input-instagram-topic"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="instagram-tone">Tom</Label>
                    <Select
                      value={instagramData.tone}
                      onValueChange={(value: typeof instagramData.tone) => setInstagramData({ ...instagramData, tone: value })}
                    >
                      <SelectTrigger id="instagram-tone" data-testid="select-instagram-tone">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="motivational">Motivacional</SelectItem>
                        <SelectItem value="educational">Educativo</SelectItem>
                        <SelectItem value="inspirational">Inspirador</SelectItem>
                        <SelectItem value="casual">Casual</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </CardContent>
                <CardFooter>
                  <Button
                    className="w-full"
                    onClick={() => instagramMutation.mutate(instagramData)}
                    disabled={!instagramData.topic || instagramMutation.isPending}
                    data-testid="button-generate-instagram"
                  >
                    {instagramMutation.isPending ? "Gerando..." : "Gerar Conteúdo"}
                  </Button>
                </CardFooter>
              </Card>

              {instagramResult && (
                <Card>
                  <CardHeader>
                    <CardTitle>Resultado</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="space-y-2">
                      <div className="flex items-center justify-between">
                        <Label className="text-sm font-semibold">Legenda</Label>
                        <Button
                          size="sm"
                          variant="ghost"
                          onClick={() => copyToClipboard(instagramResult.caption, "instagram-caption")}
                          data-testid="button-copy-instagram-caption"
                        >
                          {copiedField === "instagram-caption" ? <Check className="h-4 w-4" /> : <Copy className="h-4 w-4" />}
                        </Button>
                      </div>
                      <p className="text-sm p-3 bg-muted rounded-md whitespace-pre-wrap" data-testid="result-instagram-caption">{instagramResult.caption}</p>
                    </div>

                    <div className="space-y-2">
                      <div className="flex items-center justify-between">
                        <Label className="text-sm font-semibold">Hashtags</Label>
                        <Button
                          size="sm"
                          variant="ghost"
                          onClick={() => copyToClipboard(instagramResult.hashtags, "instagram-hashtags")}
                        >
                          {copiedField === "instagram-hashtags" ? <Check className="h-4 w-4" /> : <Copy className="h-4 w-4" />}
                        </Button>
                      </div>
                      <p className="text-sm p-3 bg-muted rounded-md">{instagramResult.hashtags}</p>
                    </div>

                    {instagramResult.carousel && (
                      <div className="space-y-2">
                        <Label className="text-sm font-semibold">Slides do Carrossel</Label>
                        <div className="space-y-2">
                          {instagramResult.carousel.map((slide, i) => (
                            <div key={i} className="p-3 bg-muted rounded-md">
                              <p className="text-xs font-semibold mb-1">Slide {i + 1}</p>
                              <p className="text-sm">{slide}</p>
                            </div>
                          ))}
                        </div>
                      </div>
                    )}

                    {instagramResult.reelScript && (
                      <div className="space-y-2">
                        <div className="flex items-center justify-between">
                          <Label className="text-sm font-semibold">Roteiro do Reel</Label>
                          <Button
                            size="sm"
                            variant="ghost"
                            onClick={() => copyToClipboard(instagramResult.reelScript!, "instagram-reel")}
                          >
                            {copiedField === "instagram-reel" ? <Check className="h-4 w-4" /> : <Copy className="h-4 w-4" />}
                          </Button>
                        </div>
                        <p className="text-sm p-3 bg-muted rounded-md whitespace-pre-wrap">{instagramResult.reelScript}</p>
                      </div>
                    )}

                    <div className="space-y-2">
                      <Label className="text-sm font-semibold">Call to Action</Label>
                      <p className="text-sm p-3 bg-muted rounded-md">{instagramResult.callToAction}</p>
                    </div>
                  </CardContent>
                </Card>
              )}
            </div>
          </TabsContent>

          <TabsContent value="facebook" className="space-y-6">
            <div className="grid md:grid-cols-2 gap-6">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Facebook className="h-5 w-5" />
                    Gerador Facebook
                  </CardTitle>
                  <CardDescription>
                    Posts virais, anúncios e storytelling emocional
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="space-y-2">
                    <Label htmlFor="facebook-type">Tipo de Post</Label>
                    <Select
                      value={facebookData.postType}
                      onValueChange={(value: typeof facebookData.postType) => setFacebookData({ ...facebookData, postType: value })}
                    >
                      <SelectTrigger id="facebook-type" data-testid="select-facebook-type">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="engagement">Engajamento</SelectItem>
                        <SelectItem value="ad">Anúncio</SelectItem>
                        <SelectItem value="story">História</SelectItem>
                        <SelectItem value="article">Mini-Artigo</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="facebook-topic">Tópico</Label>
                    <Input
                      id="facebook-topic"
                      placeholder="Ex: Como superei o medo de criar conteúdo"
                      value={facebookData.topic}
                      onChange={(e) => setFacebookData({ ...facebookData, topic: e.target.value })}
                      data-testid="input-facebook-topic"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="facebook-audience">Público-Alvo (Opcional)</Label>
                    <Input
                      id="facebook-audience"
                      placeholder="Ex: Empreendedores iniciantes"
                      value={facebookData.audience}
                      onChange={(e) => setFacebookData({ ...facebookData, audience: e.target.value })}
                      data-testid="input-facebook-audience"
                    />
                  </div>
                </CardContent>
                <CardFooter>
                  <Button
                    className="w-full"
                    onClick={() => facebookMutation.mutate(facebookData)}
                    disabled={!facebookData.topic || facebookMutation.isPending}
                    data-testid="button-generate-facebook"
                  >
                    {facebookMutation.isPending ? "Gerando..." : "Gerar Conteúdo"}
                  </Button>
                </CardFooter>
              </Card>

              {facebookResult && (
                <Card>
                  <CardHeader>
                    <CardTitle>Resultado</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="space-y-2">
                      <div className="flex items-center justify-between">
                        <Label className="text-sm font-semibold">Post</Label>
                        <Button
                          size="sm"
                          variant="ghost"
                          onClick={() => copyToClipboard(facebookResult.post, "facebook-post")}
                          data-testid="button-copy-facebook-post"
                        >
                          {copiedField === "facebook-post" ? <Check className="h-4 w-4" /> : <Copy className="h-4 w-4" />}
                        </Button>
                      </div>
                      <p className="text-sm p-3 bg-muted rounded-md whitespace-pre-wrap max-h-64 overflow-y-auto" data-testid="result-facebook-post">{facebookResult.post}</p>
                    </div>

                    {facebookResult.headline && (
                      <div className="space-y-2">
                        <Label className="text-sm font-semibold">Headline</Label>
                        <p className="text-sm p-3 bg-muted rounded-md">{facebookResult.headline}</p>
                      </div>
                    )}

                    {facebookResult.adCopy && (
                      <div className="space-y-2">
                        <div className="flex items-center justify-between">
                          <Label className="text-sm font-semibold">Copy do Anúncio</Label>
                          <Button
                            size="sm"
                            variant="ghost"
                            onClick={() => copyToClipboard(facebookResult.adCopy!, "facebook-ad")}
                          >
                            {copiedField === "facebook-ad" ? <Check className="h-4 w-4" /> : <Copy className="h-4 w-4" />}
                          </Button>
                        </div>
                        <p className="text-sm p-3 bg-muted rounded-md whitespace-pre-wrap">{facebookResult.adCopy}</p>
                      </div>
                    )}

                    {facebookResult.imagePrompt && (
                      <div className="space-y-2">
                        <Label className="text-sm font-semibold">Prompt para Imagem (DALL-E)</Label>
                        <p className="text-sm p-3 bg-muted rounded-md">{facebookResult.imagePrompt}</p>
                      </div>
                    )}

                    <div className="space-y-2">
                      <Label className="text-sm font-semibold">Pergunta de Engajamento</Label>
                      <p className="text-sm p-3 bg-muted rounded-md">{facebookResult.engagementQuestion}</p>
                    </div>
                  </CardContent>
                </Card>
              )}
            </div>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}
