import { useState } from "react";
import {
  SidebarProvider,
  Sidebar,
  SidebarContent,
  SidebarGroup,
  SidebarGroupContent,
  SidebarGroupLabel,
  SidebarMenu,
  SidebarMenuButton,
  SidebarMenuItem,
  SidebarTrigger,
} from "@/components/ui/sidebar";
import { ThemeToggle } from "@/components/ThemeToggle";
import { StatsCard } from "@/components/dashboard/StatsCard";
import { ActivityFeed } from "@/components/dashboard/ActivityFeed";
import { LevelProgress } from "@/components/dashboard/LevelProgress";
import { RecommendedConnections } from "@/components/dashboard/RecommendedConnections";
import { AchievementsList } from "@/components/dashboard/AchievementsList";
import { PlanBenefits } from "@/components/dashboard/PlanBenefits";
import { Home, BarChart3, Users, Award, Settings, LogOut, Sparkles, ArrowRight } from "lucide-react";
import { Eye, Heart, Share2, TrendingUp } from "lucide-react";
import { Link } from "wouter";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { useQuery } from "@tanstack/react-query";
import type { User, Activity, Achievement, Connection, SocialMetrics } from "@shared/schema";

const menuItems = [
  { title: "Dashboard", icon: Home, url: "/dashboard" },
  { title: "Analytics", icon: BarChart3, url: "/analytics" },
  { title: "Conexões", icon: Users, url: "/connections" },
  { title: "Conquistas", icon: Award, url: "/achievements" },
  { title: "Configurações", icon: Settings, url: "/settings" },
];

export default function Dashboard() {
  const [activePage, setActivePage] = useState("Dashboard");

  const { data: user } = useQuery<User>({
    queryKey: ["/api/user"],
  });

  const { data: activities = [] } = useQuery<Activity[]>({
    queryKey: ["/api/user/activities"],
  });

  const { data: achievements = [] } = useQuery<Achievement[]>({
    queryKey: ["/api/user/achievements"],
  });

  const { data: connections = [] } = useQuery<Connection[]>({
    queryKey: ["/api/user/connections"],
  });

  const { data: socialMetrics = [] } = useQuery<SocialMetrics[]>({
    queryKey: ["/api/user/social-metrics"],
  });

  const youtubMetrics = socialMetrics.find(m => m.platform === "YouTube");
  const instagramMetrics = socialMetrics.find(m => m.platform === "Instagram");

  const formattedActivities = activities.slice(0, 10).map(activity => ({
    id: activity.id,
    type: activity.type as "view" | "comment" | "share" | "like",
    user: { name: "Usuário" },
    content: activity.content,
    points: activity.points,
    timestamp: new Date(activity.createdAt).toLocaleDateString('pt-BR'),
  }));

  const formattedConnections = connections.slice(0, 3).map(conn => ({
    id: conn.id,
    name: `Criador ${conn.connectedUserId.substring(0, 8)}`,
    niche: "Criador de Conteúdo",
    matchScore: conn.matchScore || 0,
    followers: "10K+",
  }));

  const formattedAchievements = achievements.map(ach => ({
    id: ach.id,
    title: ach.title,
    description: ach.description,
    unlocked: true,
    unlockedAt: ach.unlockedAt ? new Date(ach.unlockedAt).toLocaleDateString('pt-BR') : undefined,
  }));

  const calculateNextLevel = (points: number) => {
    const levels = [
      { name: "Iniciante", min: 0, max: 1000 },
      { name: "Ativo", min: 1000, max: 5000 },
      { name: "Engajado", min: 5000, max: 15000 },
      { name: "Influenciador", min: 15000, max: 50000 },
      { name: "Elite", min: 50000, max: Infinity },
    ];
    
    const currentLevel = levels.find(l => points >= l.min && points < l.max) || levels[0];
    const nextLevel = levels[levels.findIndex(l => l === currentLevel) + 1];
    
    return {
      currentLevel: currentLevel.name,
      currentPoints: points,
      nextLevelPoints: nextLevel ? nextLevel.min : currentLevel.max,
    };
  };

  const levelInfo = user ? calculateNextLevel(user.points) : {
    currentLevel: "Iniciante",
    currentPoints: 0,
    nextLevelPoints: 1000,
  };

  const style = {
    "--sidebar-width": "16rem",
  };

  return (
    <SidebarProvider style={style as React.CSSProperties}>
      <div className="flex h-screen w-full">
        <Sidebar>
          <SidebarContent>
            <SidebarGroup>
              <SidebarGroupLabel>
                <div className="flex items-center gap-2">
                  <div className="w-6 h-6 rounded-md bg-primary flex items-center justify-center">
                    <span className="text-primary-foreground font-bold text-xs">ET</span>
                  </div>
                  <span className="font-bold">Engage Tribe</span>
                </div>
              </SidebarGroupLabel>
              <SidebarGroupContent>
                <SidebarMenu>
                  {menuItems.map((item) => (
                    <SidebarMenuItem key={item.title}>
                      <SidebarMenuButton
                        isActive={activePage === item.title}
                        onClick={() => setActivePage(item.title)}
                        data-testid={`sidebar-${item.title.toLowerCase()}`}
                      >
                        <item.icon className="h-4 w-4" />
                        <span>{item.title}</span>
                      </SidebarMenuButton>
                    </SidebarMenuItem>
                  ))}
                </SidebarMenu>
              </SidebarGroupContent>
            </SidebarGroup>

            <SidebarGroup className="mt-auto">
              <SidebarMenu>
                <SidebarMenuItem>
                  <SidebarMenuButton data-testid="sidebar-logout">
                    <LogOut className="h-4 w-4" />
                    <span>Sair</span>
                  </SidebarMenuButton>
                </SidebarMenuItem>
              </SidebarMenu>
            </SidebarGroup>
          </SidebarContent>
        </Sidebar>

        <div className="flex flex-col flex-1 overflow-hidden">
          <header className="flex items-center justify-between p-4 border-b gap-4">
            <SidebarTrigger data-testid="button-sidebar-toggle" />
            <div className="flex items-center gap-2">
              <ThemeToggle />
            </div>
          </header>

          <main className="flex-1 overflow-y-auto p-6">
            <div className="max-w-7xl mx-auto space-y-6">
              <div>
                <h1 className="text-3xl font-bold mb-2">Dashboard</h1>
                <p className="text-muted-foreground">
                  Bem-vindo de volta{user ? `, ${user.firstName}` : ""}! Aqui está seu resumo de hoje.
                </p>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
                <StatsCard
                  title="Visualizações YouTube"
                  value={youtubMetrics?.views?.toLocaleString() || "0"}
                  icon={Eye}
                  trend={{ value: 23, label: "vs. mês anterior" }}
                  description="Total de visualizações"
                />
                <StatsCard
                  title="Engajamento Instagram"
                  value={instagramMetrics?.engagementRate?.toLocaleString() || "0"}
                  icon={Heart}
                  trend={{ value: 15, label: "vs. semana anterior" }}
                  description="Taxa de engajamento"
                />
                <StatsCard
                  title="Posts Totais"
                  value={socialMetrics.reduce((sum, m) => sum + (m.posts || 0), 0).toLocaleString()}
                  icon={Share2}
                  trend={{ value: -5, label: "vs. mês anterior" }}
                  description="Total de publicações"
                />
                <StatsCard
                  title="Pontos Totais"
                  value={user?.totalPoints?.toLocaleString() || "0"}
                  icon={TrendingUp}
                  trend={{ value: 42, label: "este mês" }}
                  description="Pontos de reciprocidade"
                />
              </div>

              {user && (user.subscriptionPlan === "starter" || user.subscriptionPlan === "pro") && (
                <PlanBenefits subscriptionTier={user.subscriptionPlan} />
              )}

              {user && user.subscriptionPlan === "pro" && (
                <Card className="border-primary bg-gradient-to-r from-primary/5 to-primary/10">
                  <CardHeader>
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-3">
                        <div className="p-2 bg-primary/10 rounded-lg">
                          <Sparkles className="h-6 w-6 text-primary" />
                        </div>
                        <div>
                          <CardTitle className="text-xl">Ferramentas IA PRO</CardTitle>
                          <CardDescription>
                            IAs especializadas para YouTube, Instagram e Facebook
                          </CardDescription>
                        </div>
                      </div>
                      <Link href="/ferramentas-ia">
                        <Button data-testid="button-ai-tools">
                          Acessar
                          <ArrowRight className="h-4 w-4 ml-2" />
                        </Button>
                      </Link>
                    </div>
                  </CardHeader>
                  <CardContent>
                    <p className="text-sm text-muted-foreground">
                      Gere títulos otimizados, legendas virais, roteiros profissionais e muito mais com inteligência artificial especializada em cada plataforma.
                    </p>
                  </CardContent>
                </Card>
              )}

              <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                <div className="lg:col-span-2 space-y-6">
                  <ActivityFeed activities={formattedActivities} />
                  <RecommendedConnections connections={formattedConnections} />
                </div>
                <div className="space-y-6">
                  <LevelProgress
                    currentLevel={levelInfo.currentLevel}
                    currentPoints={levelInfo.currentPoints}
                    nextLevelPoints={levelInfo.nextLevelPoints}
                    totalPoints={user?.totalPoints || 0}
                  />
                  <AchievementsList achievements={formattedAchievements} />
                </div>
              </div>
            </div>
          </main>
        </div>
      </div>
    </SidebarProvider>
  );
}
