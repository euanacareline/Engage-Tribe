import { SignupForm } from "@/components/auth/SignupForm";
import { Navbar } from "@/components/Navbar";

export default function Signup() {
  return (
    <div className="min-h-screen flex flex-col">
      <Navbar />
      <div className="flex-1 flex items-center justify-center p-4 pt-24">
        <SignupForm />
      </div>
    </div>
  );
}
