import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Calendar } from "@/components/ui/calendar";
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from "@/components/ui/popover";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { 
  Users, 
  Clock, 
  BarChart3, 
  MessageSquare, 
  Edit, 
  Trash2, 
  CalendarIcon,
  LogIn,
  LogOut,
  Coffee,
  Play,
  Send,
  DollarSign,
  TrendingUp
} from "lucide-react";
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from "recharts";
import { format } from "date-fns";
import type { User, StaffRole, Timeclock } from "@shared/schema";

interface StaffMember extends User {
  staffRole?: StaffRole;
}

interface TimeclockRecord extends Timeclock {
  userName?: string;
}

interface ChatMessage {
  role: "user" | "assistant";
  content: string;
}

interface TimeclockReport {
  dailyHours: Array<{ date: string; hours: number }>;
  totalHours: number;
  averageHours: number;
  totalCost: number;
}

export default function AdminStaff() {
  const { toast } = useToast();
  const [activeTab, setActiveTab] = useState("equipe");
  const [selectedUserId, setSelectedUserId] = useState<string>("");
  const [editingStaff, setEditingStaff] = useState<StaffMember | null>(null);
  const [editDialogOpen, setEditDialogOpen] = useState(false);
  const [reportStartDate, setReportStartDate] = useState<Date>();
  const [reportEndDate, setReportEndDate] = useState<Date>();
  const [reportUserId, setReportUserId] = useState<string>("");
  const [chatMessages, setChatMessages] = useState<ChatMessage[]>([]);
  const [chatInput, setChatInput] = useState("");

  // Fetch staff members
  const { data: staffResponse } = useQuery<{
    roles: (StaffRole & { user?: User })[];
  }>({
    queryKey: ["/api/admin/staff"],
  });

  const staffData = (staffResponse?.roles || []).map((role) => ({
    ...role.user,
    staffRole: role,
  })) as StaffMember[];

  // Fetch timeclock records for selected user
  const { data: timeclockData } = useQuery<{ records: TimeclockRecord[] }>({
    queryKey: ["/api/timeclock/records", selectedUserId],
    enabled: !!selectedUserId && activeTab === "ponto",
  });

  // Fetch timeclock report
  const { data: reportApiData } = useQuery<{
    hoursData: { totalHours: number; regularHours: number; breakHours: number };
    records: Timeclock[];
  }>({
    queryKey: [
      "/api/timeclock/report",
      reportUserId,
      reportStartDate?.toISOString(),
      reportEndDate?.toISOString(),
    ],
    enabled: !!reportUserId && !!reportStartDate && !!reportEndDate && activeTab === "relatorios",
  });

  // Process report data
  const reportData: TimeclockReport | undefined = reportApiData
    ? (() => {
        const records = reportApiData.records;
        const dayMap = new Map<string, number>();
        
        // Group records by day and calculate hours
        let lastClockIn: Date | null = null;
        records.forEach((record) => {
          const recordDate = new Date(record.timestamp);
          const dateKey = format(recordDate, "yyyy-MM-dd");
          
          if (record.clockType === "clock_in") {
            lastClockIn = recordDate;
          } else if (record.clockType === "clock_out" && lastClockIn) {
            const hours = (recordDate.getTime() - lastClockIn.getTime()) / (1000 * 60 * 60);
            dayMap.set(dateKey, (dayMap.get(dateKey) || 0) + hours);
            lastClockIn = null;
          }
        });

        const dailyHours = Array.from(dayMap.entries())
          .map(([date, hours]) => ({
            date: format(new Date(date), "dd/MM"),
            hours: Math.round(hours * 100) / 100,
          }))
          .sort((a, b) => a.date.localeCompare(b.date));

        const totalHours = reportApiData.hoursData.totalHours;
        const numDays = dailyHours.length || 1;
        const averageHours = totalHours / numDays;

        // Calculate cost based on staff salary
        const staffMember = staffData.find((s) => s.staffRole?.userId === reportUserId);
        const hourlySalary = staffMember?.staffRole?.salary
          ? (staffMember.staffRole.salary / 100) / (22 * 8) // Monthly salary -> hourly rate (22 work days, 8h/day)
          : 0;
        const totalCost = Math.round(totalHours * hourlySalary * 100); // in cents

        return {
          dailyHours,
          totalHours,
          averageHours,
          totalCost,
        };
      })()
    : undefined;

  // Clock in mutation
  const clockInMutation = useMutation({
    mutationFn: async (userId: string) => {
      return await apiRequest("POST", "/api/timeclock/in", { targetUserId: userId });
    },
    onSuccess: () => {
      toast({ title: "Sucesso", description: "Entrada registrada" });
      queryClient.invalidateQueries({ queryKey: ["/api/timeclock/records"] });
    },
    onError: () => {
      toast({ title: "Erro", description: "Falha ao registrar entrada", variant: "destructive" });
    },
  });

  // Clock out mutation
  const clockOutMutation = useMutation({
    mutationFn: async (userId: string) => {
      return await apiRequest("POST", "/api/timeclock/out", { targetUserId: userId });
    },
    onSuccess: () => {
      toast({ title: "Sucesso", description: "Saída registrada" });
      queryClient.invalidateQueries({ queryKey: ["/api/timeclock/records"] });
    },
    onError: () => {
      toast({ title: "Erro", description: "Falha ao registrar saída", variant: "destructive" });
    },
  });

  // Break start mutation
  const breakStartMutation = useMutation({
    mutationFn: async (userId: string) => {
      return await apiRequest("POST", "/api/timeclock/break-start", { targetUserId: userId });
    },
    onSuccess: () => {
      toast({ title: "Sucesso", description: "Pausa iniciada" });
      queryClient.invalidateQueries({ queryKey: ["/api/timeclock/records"] });
    },
    onError: () => {
      toast({ title: "Erro", description: "Falha ao iniciar pausa", variant: "destructive" });
    },
  });

  // Break end mutation
  const breakEndMutation = useMutation({
    mutationFn: async (userId: string) => {
      return await apiRequest("POST", "/api/timeclock/break-end", { targetUserId: userId });
    },
    onSuccess: () => {
      toast({ title: "Sucesso", description: "Pausa finalizada" });
      queryClient.invalidateQueries({ queryKey: ["/api/timeclock/records"] });
    },
    onError: () => {
      toast({ title: "Erro", description: "Falha ao finalizar pausa", variant: "destructive" });
    },
  });

  // Delete staff mutation
  const deleteStaffMutation = useMutation({
    mutationFn: async (userId: string) => {
      return await apiRequest("DELETE", `/api/admin/staff/${userId}`);
    },
    onSuccess: () => {
      toast({ title: "Sucesso", description: "Funcionário removido" });
      queryClient.invalidateQueries({ queryKey: ["/api/admin/staff"] });
    },
    onError: () => {
      toast({ title: "Erro", description: "Falha ao remover funcionário", variant: "destructive" });
    },
  });

  // Update staff mutation
  const updateStaffMutation = useMutation({
    mutationFn: async (data: { userId: string; updates: Partial<StaffRole> }) => {
      return await apiRequest("PATCH", `/api/admin/staff/${data.userId}`, data.updates);
    },
    onSuccess: () => {
      toast({ title: "Sucesso", description: "Funcionário atualizado" });
      setEditDialogOpen(false);
      setEditingStaff(null);
      queryClient.invalidateQueries({ queryKey: ["/api/admin/staff"] });
    },
    onError: () => {
      toast({ title: "Erro", description: "Falha ao atualizar funcionário", variant: "destructive" });
    },
  });

  // HR Chatbot mutation
  const chatbotMutation = useMutation({
    mutationFn: async (message: string) => {
      return await apiRequest("POST", "/api/admin/hr-chatbot", { message });
    },
    onSuccess: (data: any) => {
      setChatMessages((prev) => [...prev, { role: "assistant", content: data.response }]);
    },
    onError: () => {
      toast({ title: "Erro", description: "Falha ao enviar mensagem", variant: "destructive" });
    },
  });

  const handleSendMessage = () => {
    if (!chatInput.trim()) return;
    
    setChatMessages((prev) => [...prev, { role: "user", content: chatInput }]);
    chatbotMutation.mutate(chatInput);
    setChatInput("");
  };

  const handleSuggestedQuestion = (question: string) => {
    setChatMessages((prev) => [...prev, { role: "user", content: question }]);
    chatbotMutation.mutate(question);
  };

  const handleEditStaff = (staff: StaffMember) => {
    setEditingStaff(staff);
    setEditDialogOpen(true);
  };

  const handleSaveStaff = () => {
    if (!editingStaff) return;
    
    updateStaffMutation.mutate({
      userId: editingStaff.id,
      updates: {
        role: editingStaff.staffRole?.role || "",
        department: editingStaff.staffRole?.department || "",
        salary: editingStaff.staffRole?.salary || 0,
      },
    });
  };

  const formatCurrency = (cents: number) => {
    return `R$ ${(cents / 100).toFixed(2).replace(".", ",")}`;
  };

  const getClockTypeBadge = (type: string) => {
    const badges: Record<string, { label: string; variant: "default" | "secondary" | "destructive" | "outline" }> = {
      clock_in: { label: "Entrada", variant: "default" },
      clock_out: { label: "Saída", variant: "secondary" },
      break_start: { label: "Início Pausa", variant: "outline" },
      break_end: { label: "Fim Pausa", variant: "outline" },
    };
    const badge = badges[type] || { label: type, variant: "default" as const };
    return <Badge variant={badge.variant} data-testid={`badge-${type}`}>{badge.label}</Badge>;
  };

  return (
    <div className="container mx-auto p-6 max-w-7xl">
      <div className="mb-6">
        <h1 className="text-3xl font-bold mb-2">Gestão de Equipe</h1>
        <p className="text-muted-foreground">
          Gerencie funcionários, ponto eletrônico e relatórios
        </p>
      </div>

      <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
        <TabsList className="grid w-full grid-cols-4" data-testid="tabs-staff">
          <TabsTrigger value="equipe" data-testid="tab-equipe">
            <Users className="h-4 w-4 mr-2" />
            Equipe
          </TabsTrigger>
          <TabsTrigger value="ponto" data-testid="tab-ponto">
            <Clock className="h-4 w-4 mr-2" />
            Ponto
          </TabsTrigger>
          <TabsTrigger value="relatorios" data-testid="tab-relatorios">
            <BarChart3 className="h-4 w-4 mr-2" />
            Relatórios
          </TabsTrigger>
          <TabsTrigger value="chatbot" data-testid="tab-chatbot">
            <MessageSquare className="h-4 w-4 mr-2" />
            Chatbot RH
          </TabsTrigger>
        </TabsList>

        {/* Tab Equipe */}
        <TabsContent value="equipe" className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {staffData.map((staff) => (
              <Card key={staff.id} data-testid={`card-staff-${staff.id}`}>
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2 gap-2">
                  <CardTitle className="text-lg">
                    {staff.firstName} {staff.lastName}
                  </CardTitle>
                  <div className="flex gap-2">
                    <Button
                      size="icon"
                      variant="ghost"
                      onClick={() => handleEditStaff(staff)}
                      data-testid={`button-edit-${staff.id}`}
                    >
                      <Edit className="h-4 w-4" />
                    </Button>
                    <Button
                      size="icon"
                      variant="ghost"
                      onClick={() => deleteStaffMutation.mutate(staff.id)}
                      data-testid={`button-delete-${staff.id}`}
                    >
                      <Trash2 className="h-4 w-4" />
                    </Button>
                  </div>
                </CardHeader>
                <CardContent className="space-y-2">
                  <div>
                    <p className="text-sm text-muted-foreground">Cargo</p>
                    <p className="font-medium" data-testid={`text-role-${staff.id}`}>
                      {staff.staffRole?.role || "Não definido"}
                    </p>
                  </div>
                  <div>
                    <p className="text-sm text-muted-foreground">Departamento</p>
                    <p className="font-medium" data-testid={`text-department-${staff.id}`}>
                      {staff.staffRole?.department || "Não definido"}
                    </p>
                  </div>
                  <div>
                    <p className="text-sm text-muted-foreground">Salário</p>
                    <p className="font-medium" data-testid={`text-salary-${staff.id}`}>
                      {formatCurrency(staff.staffRole?.salary || 0)}
                    </p>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>

        {/* Tab Ponto */}
        <TabsContent value="ponto" className="space-y-4">
          <Card data-testid="card-timeclock">
            <CardHeader>
              <CardTitle>Registrar Ponto</CardTitle>
              <CardDescription>Selecione um funcionário para registrar ponto</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <Label htmlFor="employee-select">Funcionário</Label>
                <Select value={selectedUserId} onValueChange={setSelectedUserId}>
                  <SelectTrigger id="employee-select" data-testid="input-employee-select">
                    <SelectValue placeholder="Selecione um funcionário" />
                  </SelectTrigger>
                  <SelectContent>
                    {staffData.map((staff) => (
                      <SelectItem key={staff.id} value={staff.id}>
                        {staff.firstName} {staff.lastName}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              {selectedUserId && (
                <div className="flex flex-wrap gap-2">
                  <Button
                    onClick={() => clockInMutation.mutate(selectedUserId)}
                    disabled={clockInMutation.isPending}
                    data-testid="button-clock-in"
                  >
                    <LogIn className="h-4 w-4 mr-2" />
                    Registrar Entrada
                  </Button>
                  <Button
                    onClick={() => clockOutMutation.mutate(selectedUserId)}
                    disabled={clockOutMutation.isPending}
                    data-testid="button-clock-out"
                  >
                    <LogOut className="h-4 w-4 mr-2" />
                    Registrar Saída
                  </Button>
                  <Button
                    onClick={() => breakStartMutation.mutate(selectedUserId)}
                    disabled={breakStartMutation.isPending}
                    variant="outline"
                    data-testid="button-break-start"
                  >
                    <Coffee className="h-4 w-4 mr-2" />
                    Iniciar Pausa
                  </Button>
                  <Button
                    onClick={() => breakEndMutation.mutate(selectedUserId)}
                    disabled={breakEndMutation.isPending}
                    variant="outline"
                    data-testid="button-break-end"
                  >
                    <Play className="h-4 w-4 mr-2" />
                    Finalizar Pausa
                  </Button>
                </div>
              )}
            </CardContent>
          </Card>

          {selectedUserId && timeclockData && (
            <Card data-testid="card-timeclock-records">
              <CardHeader>
                <CardTitle>Últimos 10 Registros</CardTitle>
              </CardHeader>
              <CardContent>
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Tipo</TableHead>
                      <TableHead>Data/Hora</TableHead>
                      <TableHead>Registro</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {timeclockData.records.slice(0, 10).map((record) => (
                      <TableRow key={record.id} data-testid={`row-record-${record.id}`}>
                        <TableCell>{getClockTypeBadge(record.clockType)}</TableCell>
                        <TableCell data-testid={`text-timestamp-${record.id}`}>
                          {format(new Date(record.timestamp), "dd/MM/yyyy HH:mm:ss")}
                        </TableCell>
                        <TableCell>
                          <Badge variant={record.isManual ? "secondary" : "outline"}>
                            {record.isManual ? "Manual" : "Automático"}
                          </Badge>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </CardContent>
            </Card>
          )}
        </TabsContent>

        {/* Tab Relatórios */}
        <TabsContent value="relatorios" className="space-y-4">
          <Card data-testid="card-report-filters">
            <CardHeader>
              <CardTitle>Filtros do Relatório</CardTitle>
              <CardDescription>Selecione funcionário e período para gerar relatório</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div>
                  <Label htmlFor="report-employee">Funcionário</Label>
                  <Select value={reportUserId} onValueChange={setReportUserId}>
                    <SelectTrigger id="report-employee" data-testid="input-report-employee">
                      <SelectValue placeholder="Selecione" />
                    </SelectTrigger>
                    <SelectContent>
                      {staffData.map((staff) => (
                        <SelectItem key={staff.id} value={staff.id}>
                          {staff.firstName} {staff.lastName}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                <div>
                  <Label>Data Início</Label>
                  <Popover>
                    <PopoverTrigger asChild>
                      <Button variant="outline" className="w-full justify-start" data-testid="button-start-date">
                        <CalendarIcon className="mr-2 h-4 w-4" />
                        {reportStartDate ? format(reportStartDate, "dd/MM/yyyy") : "Selecione"}
                      </Button>
                    </PopoverTrigger>
                    <PopoverContent className="w-auto p-0">
                      <Calendar
                        mode="single"
                        selected={reportStartDate}
                        onSelect={setReportStartDate}
                        data-testid="input-start-date"
                      />
                    </PopoverContent>
                  </Popover>
                </div>

                <div>
                  <Label>Data Fim</Label>
                  <Popover>
                    <PopoverTrigger asChild>
                      <Button variant="outline" className="w-full justify-start" data-testid="button-end-date">
                        <CalendarIcon className="mr-2 h-4 w-4" />
                        {reportEndDate ? format(reportEndDate, "dd/MM/yyyy") : "Selecione"}
                      </Button>
                    </PopoverTrigger>
                    <PopoverContent className="w-auto p-0">
                      <Calendar
                        mode="single"
                        selected={reportEndDate}
                        onSelect={setReportEndDate}
                        data-testid="input-end-date"
                      />
                    </PopoverContent>
                  </Popover>
                </div>
              </div>
            </CardContent>
          </Card>

          {reportData && (
            <>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <Card data-testid="card-total-hours">
                  <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2 gap-2">
                    <CardTitle className="text-sm font-medium">Total de Horas</CardTitle>
                    <Clock className="h-4 w-4 text-muted-foreground" />
                  </CardHeader>
                  <CardContent>
                    <div className="text-2xl font-bold" data-testid="text-total-hours">
                      {reportData.totalHours.toFixed(2)}h
                    </div>
                  </CardContent>
                </Card>

                <Card data-testid="card-average-hours">
                  <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2 gap-2">
                    <CardTitle className="text-sm font-medium">Média Diária</CardTitle>
                    <TrendingUp className="h-4 w-4 text-muted-foreground" />
                  </CardHeader>
                  <CardContent>
                    <div className="text-2xl font-bold" data-testid="text-average-hours">
                      {reportData.averageHours.toFixed(2)}h
                    </div>
                  </CardContent>
                </Card>

                <Card data-testid="card-total-cost">
                  <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2 gap-2">
                    <CardTitle className="text-sm font-medium">Custo Total</CardTitle>
                    <DollarSign className="h-4 w-4 text-muted-foreground" />
                  </CardHeader>
                  <CardContent>
                    <div className="text-2xl font-bold" data-testid="text-total-cost">
                      {formatCurrency(reportData.totalCost)}
                    </div>
                  </CardContent>
                </Card>
              </div>

              <Card data-testid="card-hours-chart">
                <CardHeader>
                  <CardTitle>Horas Trabalhadas por Dia</CardTitle>
                </CardHeader>
                <CardContent>
                  <ResponsiveContainer width="100%" height={300}>
                    <BarChart data={reportData.dailyHours}>
                      <CartesianGrid strokeDasharray="3 3" />
                      <XAxis dataKey="date" />
                      <YAxis />
                      <Tooltip />
                      <Bar dataKey="hours" fill="hsl(var(--primary))" />
                    </BarChart>
                  </ResponsiveContainer>
                </CardContent>
              </Card>
            </>
          )}
        </TabsContent>

        {/* Tab Chatbot RH */}
        <TabsContent value="chatbot" className="space-y-4">
          <Card data-testid="card-chatbot">
            <CardHeader>
              <CardTitle>Assistente RH com IA</CardTitle>
              <CardDescription>
                Faça perguntas sobre folha de pagamento, horas trabalhadas e mais
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <ScrollArea className="h-[400px] w-full rounded-md border p-4" data-testid="scroll-chat">
                {chatMessages.length === 0 && (
                  <div className="text-center text-muted-foreground py-8">
                    <MessageSquare className="h-12 w-12 mx-auto mb-4 opacity-50" />
                    <p>Nenhuma mensagem ainda. Comece uma conversa!</p>
                  </div>
                )}
                <div className="space-y-4">
                  {chatMessages.map((msg, idx) => (
                    <div
                      key={idx}
                      className={`flex ${msg.role === "user" ? "justify-end" : "justify-start"}`}
                      data-testid={`message-${idx}`}
                    >
                      <div
                        className={`max-w-[80%] rounded-lg px-4 py-2 ${
                          msg.role === "user"
                            ? "bg-primary text-primary-foreground"
                            : "bg-muted"
                        }`}
                      >
                        <p className="text-sm">{msg.content}</p>
                      </div>
                    </div>
                  ))}
                </div>
              </ScrollArea>

              <div className="space-y-4">
                <div className="flex gap-2">
                  <Input
                    placeholder="Digite sua pergunta..."
                    value={chatInput}
                    onChange={(e) => setChatInput(e.target.value)}
                    onKeyPress={(e) => e.key === "Enter" && handleSendMessage()}
                    data-testid="input-chat-message"
                  />
                  <Button
                    onClick={handleSendMessage}
                    disabled={!chatInput.trim() || chatbotMutation.isPending}
                    data-testid="button-send-message"
                  >
                    <Send className="h-4 w-4" />
                  </Button>
                </div>

                <div className="space-y-2">
                  <p className="text-sm text-muted-foreground">Perguntas sugeridas:</p>
                  <div className="flex flex-wrap gap-2">
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => handleSuggestedQuestion("Quanto gastamos com folha este mês?")}
                      data-testid="button-suggested-payroll"
                    >
                      Quanto gastamos com folha este mês?
                    </Button>
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => handleSuggestedQuestion("Quantas horas trabalhou João?")}
                      data-testid="button-suggested-hours"
                    >
                      Quantas horas trabalhou João?
                    </Button>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      {/* Edit Staff Dialog */}
      <Dialog open={editDialogOpen} onOpenChange={setEditDialogOpen}>
        <DialogContent data-testid="dialog-edit-staff">
          <DialogHeader>
            <DialogTitle>Editar Funcionário</DialogTitle>
            <DialogDescription>
              Atualize as informações do funcionário
            </DialogDescription>
          </DialogHeader>
          {editingStaff && (
            <div className="space-y-4 py-4">
              <div>
                <Label htmlFor="edit-role">Cargo</Label>
                <Input
                  id="edit-role"
                  value={editingStaff.staffRole?.role || ""}
                  onChange={(e) =>
                    setEditingStaff({
                      ...editingStaff,
                      staffRole: { ...editingStaff.staffRole!, role: e.target.value },
                    })
                  }
                  data-testid="input-edit-role"
                />
              </div>
              <div>
                <Label htmlFor="edit-department">Departamento</Label>
                <Input
                  id="edit-department"
                  value={editingStaff.staffRole?.department || ""}
                  onChange={(e) =>
                    setEditingStaff({
                      ...editingStaff,
                      staffRole: { ...editingStaff.staffRole!, department: e.target.value },
                    })
                  }
                  data-testid="input-edit-department"
                />
              </div>
              <div>
                <Label htmlFor="edit-salary">Salário (R$)</Label>
                <Input
                  id="edit-salary"
                  type="number"
                  value={(editingStaff.staffRole?.salary || 0) / 100}
                  onChange={(e) =>
                    setEditingStaff({
                      ...editingStaff,
                      staffRole: {
                        ...editingStaff.staffRole!,
                        salary: Math.round(parseFloat(e.target.value) * 100),
                      },
                    })
                  }
                  data-testid="input-edit-salary"
                />
              </div>
            </div>
          )}
          <DialogFooter>
            <Button variant="outline" onClick={() => setEditDialogOpen(false)} data-testid="button-cancel-edit">
              Cancelar
            </Button>
            <Button onClick={handleSaveStaff} data-testid="button-save-edit">
              Salvar
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
