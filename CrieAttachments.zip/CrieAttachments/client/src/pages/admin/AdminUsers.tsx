import { useState } from "react";
import AdminLayout from "./AdminLayout";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Trash2, Edit } from "lucide-react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import type { User } from "@shared/schema";

export default function AdminUsers() {
  const [selectedUser, setSelectedUser] = useState<User | null>(null);
  const [editDialogOpen, setEditDialogOpen] = useState(false);
  const [newPlan, setNewPlan] = useState("");
  const [newPassword, setNewPassword] = useState("");
  const [showPasswordField, setShowPasswordField] = useState(false);
  const { toast } = useToast();

  const { data: usersData, refetch: refetchUsers } = useQuery<{ users: User[], count: number }>({
    queryKey: ["/api/admin/users"],
  });

  const deleteUserMutation = useMutation({
    mutationFn: async (userId: string) => {
      return await apiRequest("DELETE", `/api/admin/users/${userId}`);
    },
    onSuccess: () => {
      toast({ title: "Sucesso", description: "Usuário removido com sucesso" });
      refetchUsers();
    },
    onError: () => {
      toast({ title: "Erro", description: "Falha ao remover usuário", variant: "destructive" });
    },
  });

  const updatePlanMutation = useMutation({
    mutationFn: async ({ userId, plan }: { userId: string; plan: string }) => {
      return await apiRequest("PATCH", `/api/admin/users/${userId}/plan`, { plan });
    },
    onSuccess: () => {
      toast({ title: "Sucesso", description: "Plano atualizado com sucesso" });
      setEditDialogOpen(false);
      refetchUsers();
    },
    onError: () => {
      toast({ title: "Erro", description: "Falha ao atualizar plano", variant: "destructive" });
    },
  });

  const updateRoleMutation = useMutation({
    mutationFn: async ({ userId, isAdmin }: { userId: string; isAdmin: boolean }) => {
      return await apiRequest("PATCH", `/api/admin/users/${userId}/role`, { isAdmin });
    },
    onSuccess: () => {
      toast({ title: "Sucesso", description: "Função atualizada com sucesso" });
      refetchUsers();
    },
    onError: () => {
      toast({ title: "Erro", description: "Falha ao atualizar função", variant: "destructive" });
    },
  });

  const resetPasswordMutation = useMutation({
    mutationFn: async ({ userId, newPassword }: { userId: string; newPassword: string }) => {
      return await apiRequest("POST", `/api/admin/users/${userId}/reset-password`, { newPassword });
    },
    onSuccess: (data: any) => {
      toast({ 
        title: "Senha alterada!", 
        description: data.message,
        duration: 15000
      });
      setNewPassword("");
      setShowPasswordField(false);
      refetchUsers();
    },
    onError: (error: any) => {
      toast({ 
        title: "Erro", 
        description: error.message || "Falha ao alterar senha", 
        variant: "destructive" 
      });
    },
  });

  const users = usersData?.users || [];

  return (
    <AdminLayout>
      <div className="max-w-7xl mx-auto space-y-6">
        <div>
          <h1 className="text-3xl font-bold mb-2">Gerenciar Usuários</h1>
          <p className="text-muted-foreground">Total: {usersData?.count || 0} usuários</p>
        </div>

        <Card>
          <CardHeader>
            <CardTitle>Lista de Usuários</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {users.map((user) => (
                <div key={user.id} className="flex flex-col sm:flex-row items-start sm:items-center justify-between p-4 border rounded-lg gap-4">
                  <div className="flex-1">
                    <div className="flex items-center gap-2">
                      <p className="font-medium">{user.firstName} {user.lastName}</p>
                      {user.isAdmin && <Badge variant="default">Admin</Badge>}
                    </div>
                    <p className="text-sm text-muted-foreground">{user.email}</p>
                    <div className="flex items-center gap-2 mt-1">
                      <Badge variant="outline">{user.subscriptionPlan}</Badge>
                      <span className="text-xs text-muted-foreground">{user.points} pontos</span>
                    </div>
                  </div>

                  <div className="flex items-center gap-2 w-full sm:w-auto justify-end">
                    <Button 
                      variant="outline" 
                      size="sm"
                      className="gap-2"
                      onClick={() => {
                        setSelectedUser(user);
                        setNewPlan(user.subscriptionPlan || 'starter');
                        setEditDialogOpen(true);
                      }}
                      data-testid={`button-edit-${user.id}`}
                    >
                      <Edit className="h-4 w-4" />
                      <span className="hidden sm:inline">Editar</span>
                    </Button>

                    <Button
                      variant="outline"
                      size="sm"
                      className="gap-2"
                      onClick={() => {
                        if (confirm(`Remover usuário ${user.email}?`)) {
                          deleteUserMutation.mutate(user.id);
                        }
                      }}
                      data-testid={`button-delete-${user.id}`}
                    >
                      <Trash2 className="h-4 w-4" />
                      <span className="hidden sm:inline">Remover</span>
                    </Button>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>

      <Dialog open={editDialogOpen} onOpenChange={setEditDialogOpen}>
        <DialogContent data-testid="dialog-edit-user">
          <DialogHeader>
            <DialogTitle>Editar Usuário</DialogTitle>
            <DialogDescription>
              {selectedUser?.firstName} {selectedUser?.lastName} ({selectedUser?.email})
            </DialogDescription>
          </DialogHeader>

          <div className="space-y-4 py-4">
            <div className="space-y-2">
              <label className="text-sm font-medium">Plano de Assinatura</label>
              <Select value={newPlan} onValueChange={setNewPlan}>
                <SelectTrigger data-testid="select-plan">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="starter">Starter</SelectItem>
                  <SelectItem value="pro">PRO</SelectItem>
                  <SelectItem value="elite">Elite</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <label className="text-sm font-medium">Função</label>
              <div className="flex items-center gap-2">
                <Button
                  variant={selectedUser?.isAdmin ? "default" : "outline"}
                  size="sm"
                  onClick={() => {
                    if (selectedUser) {
                      updateRoleMutation.mutate({ userId: selectedUser.id, isAdmin: !selectedUser.isAdmin });
                    }
                  }}
                  data-testid="button-toggle-admin"
                >
                  {selectedUser?.isAdmin ? "É Admin" : "Não é Admin"}
                </Button>
              </div>
            </div>

            <div className="space-y-2">
              <label className="text-sm font-medium">Senha</label>
              {!showPasswordField ? (
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => setShowPasswordField(true)}
                  data-testid="button-show-password-field"
                >
                  Alterar Senha
                </Button>
              ) : (
                <div className="space-y-2">
                  <Input
                    type="text"
                    placeholder="Nova senha"
                    value={newPassword}
                    onChange={(e) => setNewPassword(e.target.value)}
                    data-testid="input-new-password"
                  />
                  <div className="flex gap-2">
                    <Button
                      size="sm"
                      onClick={() => {
                        if (selectedUser && newPassword) {
                          resetPasswordMutation.mutate({ userId: selectedUser.id, newPassword });
                        }
                      }}
                      disabled={!newPassword || resetPasswordMutation.isPending}
                      data-testid="button-reset-password"
                    >
                      {resetPasswordMutation.isPending ? "Alterando..." : "Confirmar"}
                    </Button>
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => {
                        setShowPasswordField(false);
                        setNewPassword("");
                      }}
                      data-testid="button-cancel-password"
                    >
                      Cancelar
                    </Button>
                  </div>
                </div>
              )}
            </div>
          </div>

          <DialogFooter>
            <Button
              onClick={() => {
                if (selectedUser) {
                  updatePlanMutation.mutate({ userId: selectedUser.id, plan: newPlan });
                }
              }}
              disabled={updatePlanMutation.isPending}
              data-testid="button-save-changes"
            >
              {updatePlanMutation.isPending ? "Salvando..." : "Salvar Mudanças"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </AdminLayout>
  );
}
