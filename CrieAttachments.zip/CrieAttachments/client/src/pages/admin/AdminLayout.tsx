import { useEffect } from "react";
import { useLocation, Link } from "wouter";
import {
  SidebarProvider,
  Sidebar,
  SidebarContent,
  SidebarGroup,
  SidebarGroupContent,
  SidebarGroupLabel,
  SidebarMenu,
  SidebarMenuButton,
  SidebarMenuItem,
  SidebarTrigger,
} from "@/components/ui/sidebar";
import { ThemeToggle } from "@/components/ThemeToggle";
import { BarChart3, Users, Zap, Share2, DollarSign, FileText, Settings, LogOut } from "lucide-react";
import { useQuery } from "@tanstack/react-query";

const menuItems = [
  { title: "Overview", icon: BarChart3, path: "/admin/overview" },
  { title: "Usuários", icon: Users, path: "/admin/users" },
  { title: "Tokens OpenAI", icon: Zap, path: "/admin/tokens" },
  { title: "Redes Sociais", icon: Share2, path: "/admin/social" },
  { title: "Finanças", icon: DollarSign, path: "/admin/finances" },
  { title: "Conteúdo", icon: FileText, path: "/admin/blog" },
  { title: "Configurações", icon: Settings, path: "/admin/settings" },
];

interface AdminLayoutProps {
  children: React.ReactNode;
}

export default function AdminLayout({ children }: AdminLayoutProps) {
  const [location, navigate] = useLocation();

  const { data: adminCheck, isLoading: isCheckingAdmin } = useQuery<{ isAdmin: boolean }>({
    queryKey: ["/api/admin/check"],
  });

  useEffect(() => {
    if (!isCheckingAdmin && (!adminCheck || !adminCheck.isAdmin)) {
      navigate("/admin/login");
    }
  }, [adminCheck, isCheckingAdmin, navigate]);

  if (isCheckingAdmin || !adminCheck?.isAdmin) {
    return null;
  }

  const style = {
    "--sidebar-width": "16rem",
  };

  return (
    <SidebarProvider style={style as React.CSSProperties}>
      <div className="flex h-screen w-full">
        <Sidebar>
          <SidebarContent>
            <SidebarGroup>
              <SidebarGroupLabel>
                <div className="flex items-center gap-2">
                  <div className="w-6 h-6 rounded-md bg-primary flex items-center justify-center">
                    <span className="text-primary-foreground font-bold text-xs">ET</span>
                  </div>
                  <span className="font-bold">Admin Panel</span>
                </div>
              </SidebarGroupLabel>
              <SidebarGroupContent>
                <SidebarMenu>
                  {menuItems.map((item) => (
                    <SidebarMenuItem key={item.title}>
                      <SidebarMenuButton
                        asChild
                        isActive={location === item.path}
                        data-testid={`sidebar-${item.title.toLowerCase()}`}
                      >
                        <Link href={item.path}>
                          <item.icon className="h-4 w-4" />
                          <span>{item.title}</span>
                        </Link>
                      </SidebarMenuButton>
                    </SidebarMenuItem>
                  ))}
                </SidebarMenu>
              </SidebarGroupContent>
            </SidebarGroup>

            <SidebarGroup className="mt-auto">
              <SidebarMenu>
                <SidebarMenuItem>
                  <SidebarMenuButton data-testid="sidebar-logout">
                    <LogOut className="h-4 w-4" />
                    <span>Sair</span>
                  </SidebarMenuButton>
                </SidebarMenuItem>
              </SidebarMenu>
            </SidebarGroup>
          </SidebarContent>
        </Sidebar>

        <div className="flex flex-col flex-1 overflow-hidden">
          <header className="flex items-center justify-between p-4 border-b gap-4">
            <SidebarTrigger data-testid="button-sidebar-toggle" />
            <ThemeToggle />
          </header>

          <main className="flex-1 overflow-y-auto p-6">
            {children}
          </main>
        </div>
      </div>
    </SidebarProvider>
  );
}
