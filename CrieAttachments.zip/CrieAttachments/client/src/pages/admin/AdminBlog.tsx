import { useState } from "react";
import AdminLayout from "./AdminLayout";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Switch } from "@/components/ui/switch";
import { Sparkles, Plus } from "lucide-react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import type { BlogPost } from "@shared/schema";

export default function AdminBlog() {
  const { toast } = useToast();

  const [manualDialogOpen, setManualDialogOpen] = useState(false);
  const [formData, setFormData] = useState({
    title: "",
    excerpt: "",
    content: "",
    category: "",
    keywords: "",
    published: true,
  });

  const { data: posts = [], refetch: refetchPosts } = useQuery<BlogPost[]>({
    queryKey: ["/api/blog"],
  });

  const generateArticleMutation = useMutation({
    mutationFn: async () => {
      return await apiRequest("POST", "/api/admin/generate-article");
    },
    onSuccess: () => {
      toast({ title: "Sucesso", description: "Artigo gerado com sucesso!" });
      refetchPosts();
    },
    onError: (error: any) => {
      toast({ 
        title: "Erro", 
        description: error.message || "Falha ao gerar artigo", 
        variant: "destructive" 
      });
    },
  });

  const createManualArticleMutation = useMutation({
    mutationFn: async (data: typeof formData) => {
      const keywordsArray = data.keywords.split(',').map(k => k.trim()).filter(k => k);
      return await apiRequest("POST", "/api/admin/blog/manual", {
        ...data,
        keywords: keywordsArray,
      });
    },
    onSuccess: () => {
      toast({ title: "Sucesso", description: "Artigo criado com sucesso!" });
      setManualDialogOpen(false);
      setFormData({ title: "", excerpt: "", content: "", category: "", keywords: "", published: true });
      refetchPosts();
    },
    onError: (error: any) => {
      toast({ title: "Erro", description: error.message || "Falha ao criar artigo", variant: "destructive" });
    },
  });

  return (
    <AdminLayout>
      <div className="max-w-7xl mx-auto space-y-6">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold mb-2">Gerenciar Conteúdo</h1>
            <p className="text-muted-foreground">Artigos e publicações do blog</p>
          </div>
          <div className="flex items-center gap-2">
            <Button
              onClick={() => setManualDialogOpen(true)}
              variant="outline"
              className="gap-2"
              data-testid="button-new-manual-article"
            >
              <Plus className="h-4 w-4" />
              Novo Artigo Manual
            </Button>
            <Button
              onClick={() => generateArticleMutation.mutate()}
              disabled={generateArticleMutation.isPending}
              className="gap-2"
              data-testid="button-generate-article"
            >
              <Sparkles className="h-4 w-4" />
              {generateArticleMutation.isPending ? "Gerando..." : "Gerar Artigo com IA"}
            </Button>
          </div>
        </div>

        <Card>
          <CardHeader>
            <CardTitle>Artigos Publicados</CardTitle>
            <CardDescription>
              Total: {posts.filter(p => p.published).length} artigos publicados
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {posts.length === 0 ? (
                <div className="text-sm text-muted-foreground text-center py-8">
                  Nenhum artigo encontrado. Clique em "Gerar Artigo com IA" para criar o primeiro.
                </div>
              ) : (
                posts.map((post) => (
                  <div key={post.id} className="flex flex-col sm:flex-row items-start sm:items-center justify-between p-4 border rounded-lg gap-4">
                    <div className="flex-1">
                      <div className="flex items-center gap-2">
                        <p className="font-medium">{post.title}</p>
                        {post.published && <Badge variant="default">Publicado</Badge>}
                        {!post.published && <Badge variant="outline">Rascunho</Badge>}
                      </div>
                      <p className="text-sm text-muted-foreground line-clamp-2 mt-1">
                        {post.excerpt}
                      </p>
                      <div className="flex items-center gap-2 mt-2 text-xs text-muted-foreground">
                        <span>{new Date(post.createdAt).toLocaleDateString('pt-BR')}</span>
                        <span>•</span>
                        <span>{post.readTime || '5'} min de leitura</span>
                      </div>
                    </div>

                    <div className="flex items-center gap-2 w-full sm:w-auto justify-end">
                      <Button 
                        variant="outline" 
                        size="sm"
                        data-testid={`button-view-${post.id}`}
                      >
                        Ver Artigo
                      </Button>
                    </div>
                  </div>
                ))
              )}
            </div>
          </CardContent>
        </Card>
      </div>

      <Dialog open={manualDialogOpen} onOpenChange={setManualDialogOpen}>
        <DialogContent className="max-w-3xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>Novo Artigo Manual</DialogTitle>
            <DialogDescription>Crie um artigo do zero com SEO otimizado</DialogDescription>
          </DialogHeader>
          
          <div className="space-y-4">
            <div>
              <Label>Título</Label>
              <Input 
                value={formData.title} 
                onChange={(e) => setFormData({...formData, title: e.target.value})} 
                placeholder="Título otimizado para SEO" 
                data-testid="input-article-title" 
              />
            </div>
            
            <div>
              <Label>Resumo (Meta Description)</Label>
              <Textarea 
                value={formData.excerpt} 
                onChange={(e) => setFormData({...formData, excerpt: e.target.value})} 
                placeholder="150-160 caracteres" 
                maxLength={160} 
                rows={2} 
                data-testid="input-article-excerpt" 
              />
            </div>
            
            <div>
              <Label>Categoria</Label>
              <Input 
                value={formData.category} 
                onChange={(e) => setFormData({...formData, category: e.target.value})} 
                placeholder="SEO, Marketing Digital, etc." 
                data-testid="input-article-category" 
              />
            </div>
            
            <div>
              <Label>Palavras-chave (separadas por vírgula)</Label>
              <Input 
                value={formData.keywords} 
                onChange={(e) => setFormData({...formData, keywords: e.target.value})} 
                placeholder="SEO, tráfego orgânico, google" 
                data-testid="input-article-keywords" 
              />
            </div>
            
            <div>
              <Label>Conteúdo (Markdown)</Label>
              <Textarea 
                value={formData.content} 
                onChange={(e) => setFormData({...formData, content: e.target.value})} 
                placeholder="# Título&#10;&#10;Conteúdo em markdown..." 
                rows={15} 
                className="font-mono text-sm" 
                data-testid="input-article-content" 
              />
              <p className="text-xs text-muted-foreground mt-1">Suporta Markdown: **negrito**, ## Títulos, - listas, etc.</p>
            </div>
            
            <div className="flex items-center space-x-2">
              <Switch 
                checked={formData.published} 
                onCheckedChange={(checked) => setFormData({...formData, published: checked})} 
                data-testid="switch-article-published" 
              />
              <Label>Publicar imediatamente</Label>
            </div>
          </div>
          
          <DialogFooter>
            <Button variant="outline" onClick={() => setManualDialogOpen(false)}>Cancelar</Button>
            <Button 
              onClick={() => createManualArticleMutation.mutate(formData)} 
              disabled={createManualArticleMutation.isPending || !formData.title || !formData.content} 
              data-testid="button-save-article"
            >
              {createManualArticleMutation.isPending ? "Salvando..." : "Criar Artigo"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </AdminLayout>
  );
}
