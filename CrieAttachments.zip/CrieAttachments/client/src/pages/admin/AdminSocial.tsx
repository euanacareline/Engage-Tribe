import { useState } from "react";
import AdminLayout from "./AdminLayout";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { useQuery } from "@tanstack/react-query";
import type { User } from "@shared/schema";

export default function AdminSocial() {
  const [selectedUserForSocial, setSelectedUserForSocial] = useState<string>("");

  const { data: usersData } = useQuery<{ users: User[], count: number }>({
    queryKey: ["/api/admin/users"],
  });

  const users = usersData?.users || [];

  return (
    <AdminLayout>
      <div className="max-w-7xl mx-auto space-y-6">
        <div>
          <h1 className="text-3xl font-bold mb-2">Gerenciar Redes Sociais</h1>
          <p className="text-muted-foreground">Configurar contas sociais e engajamento</p>
        </div>

        <Card>
          <CardHeader>
            <CardTitle>Contas Sociais por Usuário</CardTitle>
            <CardDescription>
              Selecione um usuário para ver e gerenciar suas redes sociais conectadas
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex items-center gap-4">
              <Select value={selectedUserForSocial} onValueChange={setSelectedUserForSocial}>
                <SelectTrigger className="w-full max-w-md" data-testid="select-user-for-social">
                  <SelectValue placeholder="Selecione um usuário" />
                </SelectTrigger>
                <SelectContent>
                  {users.map((user) => (
                    <SelectItem key={user.id} value={user.id}>
                      {user.firstName} {user.lastName} ({user.email})
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            {selectedUserForSocial && (
              <div className="space-y-4 pt-4 border-t">
                <div className="flex items-center justify-between">
                  <h3 className="font-medium">Contas conectadas</h3>
                  <Button 
                    variant="default" 
                    size="sm"
                    data-testid="button-add-social-account"
                  >
                    Adicionar Conta
                  </Button>
                </div>
                
                <div className="text-sm text-muted-foreground">
                  Em breve: lista de contas sociais e métricas de engajamento
                </div>
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </AdminLayout>
  );
}
