import AdminLayout from "./AdminLayout";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Users, Zap, Sparkles } from "lucide-react";
import { useQuery } from "@tanstack/react-query";
import type { User } from "@shared/schema";

export default function AdminTokens() {
  const { data: usersData } = useQuery<{ users: User[], count: number }>({
    queryKey: ["/api/admin/users"],
  });

  const users = usersData?.users || [];

  return (
    <AdminLayout>
      <div className="max-w-7xl mx-auto space-y-6">
        <div>
          <h1 className="text-3xl font-bold mb-2">Gestão de Tokens OpenAI</h1>
          <p className="text-muted-foreground">Calculadora e tracking de uso de tokens</p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2 gap-2">
              <CardTitle className="text-sm font-medium">Total Gasto</CardTitle>
              <Zap className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">
                {users.reduce((sum, u) => sum + (u.monthlyTokensUsed || 0), 0).toLocaleString()}
              </div>
              <p className="text-xs text-muted-foreground">Tokens este mês</p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2 gap-2">
              <CardTitle className="text-sm font-medium">Usuários PRO</CardTitle>
              <Users className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">
                {users.filter(u => u.subscriptionPlan === 'pro').length}
              </div>
              <p className="text-xs text-muted-foreground">10.000 tokens/mês cada</p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2 gap-2">
              <CardTitle className="text-sm font-medium">Limite Total</CardTitle>
              <Sparkles className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">
                {(users.filter(u => u.subscriptionPlan === 'pro').length * 10000).toLocaleString()}
              </div>
              <p className="text-xs text-muted-foreground">Tokens disponíveis/mês</p>
            </CardContent>
          </Card>
        </div>

        <Card>
          <CardHeader>
            <CardTitle>Uso por Usuário</CardTitle>
            <CardDescription>
              Acompanhe o consumo de tokens de cada usuário PRO
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {users.filter(u => u.subscriptionPlan === 'pro').map((user) => {
                const used = user.monthlyTokensUsed || 0;
                const limit = user.monthlyTokenLimit || 10000;
                const percentage = (used / limit) * 100;
                
                return (
                  <div key={user.id} className="flex flex-col space-y-2 p-4 border rounded-lg">
                    <div className="flex items-center justify-between">
                      <div className="flex-1">
                        <p className="font-medium">{user.firstName} {user.lastName}</p>
                        <p className="text-sm text-muted-foreground">{user.email}</p>
                      </div>
                      <div className="text-right">
                        <p className="font-bold text-lg">{used.toLocaleString()}</p>
                        <p className="text-xs text-muted-foreground">de {limit.toLocaleString()} tokens</p>
                      </div>
                    </div>
                    
                    <div className="w-full bg-muted rounded-full h-2">
                      <div 
                        className="bg-primary rounded-full h-2 transition-all"
                        style={{ width: `${Math.min(percentage, 100)}%` }}
                      />
                    </div>
                    
                    <div className="flex items-center justify-between text-xs">
                      <span className={percentage > 80 ? "text-destructive font-medium" : "text-muted-foreground"}>
                        {percentage.toFixed(1)}% usado
                      </span>
                      <span className="text-muted-foreground">
                        {(limit - used).toLocaleString()} restantes
                      </span>
                    </div>
                  </div>
                );
              })}
              
              {users.filter(u => u.subscriptionPlan === 'pro').length === 0 && (
                <div className="text-sm text-muted-foreground text-center py-8">
                  Nenhum usuário PRO cadastrado
                </div>
              )}
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Calculadora de Custos</CardTitle>
            <CardDescription>
              Estimativa de custos de tokens para diferentes operações
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-2 p-3 border rounded-lg">
                <div className="flex items-center justify-between">
                  <span className="text-sm font-medium">Artigo Blog (3000+ palavras)</span>
                  <Badge variant="outline">~1500 tokens</Badge>
                </div>
                <p className="text-xs text-muted-foreground">Geração + Imagem DALL-E</p>
              </div>

              <div className="space-y-2 p-3 border rounded-lg">
                <div className="flex items-center justify-between">
                  <span className="text-sm font-medium">Script YouTube Longo</span>
                  <Badge variant="outline">~800 tokens</Badge>
                </div>
                <p className="text-xs text-muted-foreground">Roteiro completo otimizado</p>
              </div>

              <div className="space-y-2 p-3 border rounded-lg">
                <div className="flex items-center justify-between">
                  <span className="text-sm font-medium">Script YouTube Short</span>
                  <Badge variant="outline">~400 tokens</Badge>
                </div>
                <p className="text-xs text-muted-foreground">Roteiro curto + hooks</p>
              </div>

              <div className="space-y-2 p-3 border rounded-lg">
                <div className="flex items-center justify-between">
                  <span className="text-sm font-medium">Conteúdo Instagram</span>
                  <Badge variant="outline">~300 tokens</Badge>
                </div>
                <p className="text-xs text-muted-foreground">Legenda + hashtags</p>
              </div>

              <div className="space-y-2 p-3 border rounded-lg">
                <div className="flex items-center justify-between">
                  <span className="text-sm font-medium">Post Facebook</span>
                  <Badge variant="outline">~200 tokens</Badge>
                </div>
                <p className="text-xs text-muted-foreground">Texto otimizado</p>
              </div>

              <div className="space-y-2 p-3 border rounded-lg">
                <div className="flex items-center justify-between">
                  <span className="text-sm font-medium">Atendimento Chatbot</span>
                  <Badge variant="outline">~150 tokens</Badge>
                </div>
                <p className="text-xs text-muted-foreground">Por conversa</p>
              </div>
            </div>

            <div className="mt-4 p-4 bg-muted rounded-lg">
              <p className="text-sm font-medium mb-2">Dica de Economia:</p>
              <p className="text-xs text-muted-foreground">
                Com 10.000 tokens mensais, um usuário PRO pode gerar aproximadamente:
                6 artigos completos, ou 12 scripts YouTube longos, ou 25 scripts curtos, 
                ou 33 posts Instagram por mês.
              </p>
            </div>
          </CardContent>
        </Card>
      </div>
    </AdminLayout>
  );
}
