import AdminLayout from "./AdminLayout";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Users, FileText, DollarSign, UserCog } from "lucide-react";
import { useQuery } from "@tanstack/react-query";
import type { User, BlogPost } from "@shared/schema";

export default function AdminOverview() {
  const { data: usersData } = useQuery<{ users: User[], count: number }>({
    queryKey: ["/api/admin/users"],
  });

  const { data: posts = [] } = useQuery<BlogPost[]>({
    queryKey: ["/api/blog"],
  });

  const users = usersData?.users || [];
  const totalRevenue = users.reduce((sum, u) => {
    const planValues = { starter: 39.90, pro: 497, elite: 297 };
    return sum + (planValues[u.subscriptionPlan as keyof typeof planValues] || 0);
  }, 0);

  return (
    <AdminLayout>
      <div className="max-w-7xl mx-auto space-y-6">
        <div>
          <h1 className="text-3xl font-bold mb-2">Overview</h1>
          <p className="text-muted-foreground">Visão geral da plataforma Engage Tribe</p>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2 gap-2">
              <CardTitle className="text-sm font-medium">Total Usuários</CardTitle>
              <Users className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{usersData?.count || 0}</div>
              <p className="text-xs text-muted-foreground">Membros registrados</p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2 gap-2">
              <CardTitle className="text-sm font-medium">Artigos</CardTitle>
              <FileText className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{posts.filter(p => p.published).length}</div>
              <p className="text-xs text-muted-foreground">Publicados</p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2 gap-2">
              <CardTitle className="text-sm font-medium">Receita Mensal</CardTitle>
              <DollarSign className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">R$ {totalRevenue.toLocaleString()}</div>
              <p className="text-xs text-muted-foreground">Assinaturas ativas</p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2 gap-2">
              <CardTitle className="text-sm font-medium">Admins</CardTitle>
              <UserCog className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{users.filter(u => u.isAdmin).length}</div>
              <p className="text-xs text-muted-foreground">Administradores</p>
            </CardContent>
          </Card>
        </div>
      </div>
    </AdminLayout>
  );
}
