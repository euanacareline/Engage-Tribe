import AdminLayout from "./AdminLayout";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { useQuery } from "@tanstack/react-query";
import type { User } from "@shared/schema";

export default function AdminFinances() {
  const { data: usersData } = useQuery<{ users: User[], count: number }>({
    queryKey: ["/api/admin/users"],
  });

  const users = usersData?.users || [];

  return (
    <AdminLayout>
      <div className="max-w-7xl mx-auto space-y-6">
        <div>
          <h1 className="text-3xl font-bold mb-2">Gestão Financeira</h1>
          <p className="text-muted-foreground">Receita e assinaturas</p>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
          <Card>
            <CardHeader>
              <CardTitle>Plano Starter</CardTitle>
              <p className="text-sm text-muted-foreground">R$ 39,90/mês</p>
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold">{users.filter(u => u.subscriptionPlan === 'starter').length}</div>
              <p className="text-sm text-muted-foreground">R$ {(users.filter(u => u.subscriptionPlan === 'starter').length * 39.90).toLocaleString('pt-BR', { minimumFractionDigits: 2 })}/mês</p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Plano PRO</CardTitle>
              <p className="text-sm text-muted-foreground">R$ 497 (Único)</p>
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold">{users.filter(u => u.subscriptionPlan === 'pro').length}</div>
              <p className="text-sm text-muted-foreground">R$ {(users.filter(u => u.subscriptionPlan === 'pro').length * 497).toLocaleString('pt-BR')}</p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Plano Elite</CardTitle>
              <p className="text-sm text-muted-foreground">R$ 297/mês</p>
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold">{users.filter(u => u.subscriptionPlan === 'elite').length}</div>
              <p className="text-sm text-muted-foreground">R$ {(users.filter(u => u.subscriptionPlan === 'elite').length * 297).toLocaleString('pt-BR')}/mês</p>
            </CardContent>
          </Card>
        </div>

        <Card>
          <CardHeader>
            <CardTitle>Recursos Avançados</CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-sm text-muted-foreground">
              Em breve: Gráficos de receita, histórico de pagamentos, análises detalhadas
            </p>
          </CardContent>
        </Card>
      </div>
    </AdminLayout>
  );
}
