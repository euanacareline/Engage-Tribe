# Engage Tribe - Platform Overview

## Recent Changes

### November 17, 2025 - Admin Panel & Security Fixes
- **Removed signup functionality** - all users must be created by admin
- **Fixed admin login redirect loop** - session-only authentication (no DB lookup in middleware)
- **Admin password management** - admin can change any user password; password shown in toast notification
- **Monthly token system for PRO** - 10,000 tokens/month (renewed monthly)
- **Login system uses username, not email** - accepts any identifier (including non-email formats like "acesso2026#01")
- **Security fixes**:
  - Password reset no longer returns password in API response JSON
  - Password logged securely on server and shown in toast for admin to copy
- **Fixed pricing displays**:
  - Starter: R$ 39,90/mês (was shown as "Grátis")
  - PRO: R$ 497 pagamento único (was shown as "R$ 97/mês")
  - Elite: R$ 297/mês (correct)
- **Plan migration logic**:
  - When changing user to PRO: resets monthly token counters (monthlyTokensUsed, lastMonthlyTokenReset)
  - When changing from PRO to other plans: resets daily counters with appropriate limits
- **Form UX improvements**: Auto-cleanup of password fields when closing edit dialog
- **Backend validation**: Plan changes now validated against allowed values (starter, pro, elite)

## Overview

Engage Tribe is a gamified reciprocity platform for content creators that facilitates authentic engagement and organic growth. The platform connects creators through an intelligent matching system based on niche compatibility, enabling them to exchange meaningful interactions (views, comments, shares, likes) while earning points, unlocking achievements, and progressing through levels.

The platform combines modern SaaS professionalism with community warmth and gamification elements, targeting content creators across multiple platforms (YouTube, Instagram, TikTok, etc.) who want to grow their audience organically without relying on paid advertising.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture

**Technology Stack:**
- React 18+ with TypeScript for type safety
- Vite as the build tool and development server
- Wouter for lightweight client-side routing
- TanStack Query (React Query) for server state management and caching
- Tailwind CSS with custom design system for styling

**UI Component Strategy:**
- Radix UI primitives for accessible, unstyled components
- shadcn/ui component library with "new-york" style variant
- Custom theme system supporting light/dark modes via CSS variables
- Responsive-first design with mobile, tablet, and desktop breakpoints

**Design System:**
- Typography: Inter/DM Sans for UI, JetBrains Mono for metrics
- Color system: HSL-based with CSS custom properties for theming
- Spacing: Tailwind utility classes (2, 4, 6, 8, 12, 16, 20)
- Component patterns: Cards with subtle borders, hover elevations, consistent shadows
- Inspired by Linear's clarity, Stripe's restraint, and Discord's community patterns

**State Management:**
- React Query for all API data fetching with optimistic updates
- React Context for theme management
- URL-based state for navigation and routing
- Session-based authentication state

**Key Pages:**
- Landing page with hero, features, pricing, testimonials
- Authentication (login/signup)
- User dashboard with stats, activity feed, level progress, plan benefits display, PRO tools access card
- AI Tools page (PRO exclusive) - Netflix-style interface with YouTube, Instagram, Facebook AI generators
- Admin panel for user and content management
- Blog with AI-generated SEO content with lead capture
- User profile pages

**Plan Benefits Display:**
- Starter Plan (R$ 39,90/mês):
  - +1.000 visualizações diárias em uma rede social
  - Rateio de 10% do lucro da plataforma após 6 meses
  - 5 tarefas obrigatórias por dia (visitar, curtir, comentar, compartilhar)
- PRO Plan (R$ 497,00 pagamento único - Membros Fundadores):
  - Recebe uma nova rede social
  - Participa do Conselho Consultivo (reuniões trimestrais)
  - Rateio de 15% do lucro da plataforma após 6 meses
  - Participação pessoal e intransferível (não transferível a herdeiros)

### Backend Architecture

**Technology Stack:**
- Node.js with Express.js framework
- TypeScript for type safety across the stack
- Drizzle ORM for type-safe database operations
- PostgreSQL (Neon serverless) for data persistence

**Authentication & Authorization:**
- Replit OpenID Connect (OIDC) integration via Passport.js
- Session-based authentication using express-session
- PostgreSQL session store (connect-pg-simple)
- Role-based access control (user vs admin vs PRO plan)
- Middleware guards: `isAuthenticated`, `isAdmin`, `isProPlan`

**API Architecture:**
- RESTful API endpoints under `/api/*`
- JSON request/response format
- Credential-based requests for session management
- Error handling with appropriate HTTP status codes
- Request logging middleware for debugging

**Database Schema Design:**
- Users table: Extended OIDC profile with gamification fields (points, level, daily limits)
- Social metrics: Per-platform tracking (YouTube, Instagram, TikTok, Twitter, LinkedIn)
- Activities: Engagement history (views, likes, comments, shares)
- Achievements: Unlockable milestones with keys and timestamps
- Connections: Creator-to-creator relationships with match scoring
- Blog posts: AI-generated content with SEO metadata
- Newsletter leads: Email subscribers with source tracking
- AI tools usage: History of PRO member AI generations with input/output data
- Sessions: Persistent session storage

**Core Business Logic:**
- Points system with daily limits and resets
- Level progression (Iniciante → Ativo → Power → Elite)
- Achievement unlocking system
- Subscription tier management (Starter, Pro, Elite)
- Niche-based matching algorithm for creator connections

### AI Integration

**Article Generation System:**
- OpenAI GPT integration for blog content creation (3000+ word articles)
- DALL-E integration for cover image generation
- Scheduled article publication (every 5 minutes)
- Predefined topic templates for consistent content
- Advanced SEO optimization (15-20x primary keywords, 30-40x secondary keywords)
- Automatic slug generation and duplicate prevention
- ReactMarkdown + remark-gfm for professional content rendering
- Lead capture CTA at the end of each article

**Newsletter Lead Capture:**
- Lead capture form in blog articles
- Dedicated `newsletter_leads` table for storing email subscribers
- API endpoint `/api/newsletter/subscribe` for email collection
- Duplicate prevention and validation
- Source tracking (blog, landing page, etc.)

**Content Strategy:**
- Topics focused on engagement, growth strategies, platform-specific tips
- Categories: Engajamento, Instagram, Comunidades, Conteúdo, Marketing, etc.
- Target length: 8-minute read time articles
- Automated publishing workflow with admin attribution

**PRO Plan AI Tools (Exclusive Benefit):**
- Specialized AI assistants for each social media platform
- YouTube AI: Title optimization, SEO descriptions, tags, scripts (shorts & long-form), thumbnail prompts, hook ideas
- Instagram AI: Captions, hashtags, carousel content, reel scripts, engagement questions, CTAs
- Facebook AI: Viral posts, ad copy, storytelling content, mini-articles, image prompts
- Usage tracking via `ai_tools_usage` table (stores input/output, platform, tool type)
- Protected routes with `isProPlan` middleware (requires PRO subscription)
- API endpoints: `/api/ai-tools/youtube`, `/api/ai-tools/instagram`, `/api/ai-tools/facebook`, `/api/ai-tools/history`
- Professional prompts optimized for each platform's algorithm and best practices
- Copy-to-clipboard functionality for all generated content
- History tracking for all AI generations

### Data Storage

**Database: PostgreSQL (Neon Serverless)**
- Connection pooling via @neondatabase/serverless
- WebSocket-based connections (ws library)
- Drizzle ORM for migrations and queries
- Schema defined in TypeScript for type safety

**Session Storage:**
- PostgreSQL-backed sessions table
- 7-day session TTL (time-to-live)
- HTTP-only, secure cookies for production
- Session secret for encryption

**File Storage:**
- Generated images stored in attached_assets directory
- Static assets served through Vite in development
- Build output to dist/public for production

### External Dependencies

**Payment Processing:**
- Stripe integration (@stripe/stripe-js, @stripe/react-stripe-js)
- Customer ID tracking in user records
- Subscription status management (free, active, canceled)
- Webhook support for payment events (prepared but not fully implemented)

**AI Services:**
- OpenAI API for GPT-4 content generation
- DALL-E API for image creation
- Direct OpenAI API integration (OPENAI_API_KEY)
- No Replit AI integrations - uses client's own OpenAI API key

**Authentication Provider:**
- Replit OIDC for user authentication
- Token refresh mechanism
- Claims-based user identification
- Environment variables: ISSUER_URL, REPL_ID, SESSION_SECRET

**Third-Party UI Libraries:**
- Radix UI component primitives (18+ packages)
- Lucide React for icons
- date-fns for date formatting
- class-variance-authority for variant-based styling
- tailwind-merge and clsx for className utilities

**Development Tools:**
- Vite plugins: React, runtime error overlay, Replit cartographer, dev banner
- TypeScript for compile-time type checking
- PostCSS with Tailwind and Autoprefixer
- ESBuild for server-side bundling

**Database Tools:**
- Drizzle Kit for schema migrations
- drizzle-zod for schema validation
- Zod for runtime type validation

**Monitoring & Utilities:**
- Custom request logging middleware
- Error boundaries (via Vite plugin)
- Memoization for expensive operations (memoizee)
- nanoid for unique ID generation