# Design Guidelines: Plataforma Engage Tribe

## Design Approach
**Hybrid System**: Modern SaaS professionalism (Linear/Notion clarity) combined with community engagement (Discord warmth) and gamification polish (Duolingo delight). This platform balances utility-focused dashboards with experience-focused community features.

**Core References**: Linear's typography hierarchy, Stripe's restraint and trustworthiness, Discord's community-friendly interface patterns.

## Typography System

**Font Stack**: 
- Primary: Inter or DM Sans (via Google Fonts CDN)
- Monospace: JetBrains Mono (for data/metrics)

**Hierarchy**:
- Hero/H1: text-5xl to text-6xl, font-bold, tracking-tight
- H2 (Section Headers): text-3xl to text-4xl, font-semibold
- H3 (Card Titles): text-xl to text-2xl, font-semibold
- Body: text-base, leading-relaxed
- Small/Metadata: text-sm, font-medium
- Stats/Metrics: text-2xl to text-4xl, font-bold, monospace

## Layout System

**Spacing Primitives**: Use Tailwind units of 2, 4, 6, 8, 12, 16, 20 (gap-4, p-8, mt-12, etc.)

**Container Strategy**:
- Max-width: max-w-7xl for main content
- Dashboard grids: max-w-screen-2xl
- Text content: max-w-3xl
- Consistent padding: px-4 md:px-6 lg:px-8

**Grid Patterns**:
- Stats cards: grid-cols-1 md:grid-cols-2 lg:grid-cols-4
- Features: grid-cols-1 md:grid-cols-2 lg:grid-cols-3
- Blog posts: grid-cols-1 md:grid-cols-2
- Dashboard sections: 2-column split on desktop (sidebar + main)

## Component Library

### Navigation
- **Top Nav**: Fixed header with logo left, nav center, user avatar right
- Hamburger menu on mobile with slide-out drawer
- Admin nav: Sidebar navigation (240px) with icons + labels

### Buttons
- **Primary CTA**: Large (px-8 py-4), rounded-lg, font-semibold, shadow-lg
- **Secondary**: Outlined with border-2, same sizing
- **Icon buttons**: Square (p-3), rounded-full for floating actions
- **States**: Implement transform scale-105 on hover, opacity-90 on active

### Cards
- **Standard**: rounded-xl, shadow-sm, border, p-6
- **Stat cards**: Gradient background option, icon top-left, number prominent, label small
- **Profile cards**: Avatar centered, name/tags, reputation score badge
- **Blog cards**: Featured image top, title, excerpt, read time, author info

### Forms
- **Input fields**: Rounded-lg, border-2, px-4 py-3, focus:ring-2
- **Labels**: font-medium, mb-2, text-sm
- **Validation**: Inline messages below fields (text-sm)
- **Multi-step**: Progress indicator at top (stepper component)

### Dashboard Elements
- **Metric displays**: Large number + small label + trend indicator (arrow up/down)
- **Charts**: Use Recharts with clean, minimal styling
- **Tables**: Striped rows, hover states, sortable headers
- **Progress bars**: Rounded-full, animated fill

### Gamification UI
- **Badges**: Circular or shield-shaped, 48px-64px, with glow effect
- **Level indicator**: Progress ring around avatar showing level completion
- **Points counter**: Prominent in header, animated on change
- **Leaderboard**: Ranked list with podium top-3 emphasis

### Modals/Overlays
- **Modal**: Centered, max-w-2xl, rounded-2xl, shadow-2xl
- **Backdrop**: Semi-transparent with backdrop-blur
- **Success/Error states**: Toast notifications (top-right corner)

## Page-Specific Layouts

### Landing Page
**Hero Section** (h-screen):
- Large hero image (modern workspace or community collaboration visual)
- Headline centered overlay with blurred button backgrounds
- Two CTAs: "Começar Agora" (primary) + "Saiba Mais" (secondary)

**How It Works** (3-column grid):
- Icons from Heroicons
- Step numbers (01, 02, 03) in large monospace
- Description below each

**Plans Section**:
- 3 cards side-by-side on desktop (Popular plan elevated with shadow-2xl)
- Pricing prominent, features list with checkmarks
- CTA button at bottom of each card

**Social Proof**:
- Stats row (4 metrics: users, engagements, growth, satisfaction)
- Testimonials in 2-column grid with avatars

### User Dashboard
**Layout**: Sidebar (collapsed on mobile) + main content area

**Sections**:
- Top: Welcome banner + quick stats (4 metrics in grid)
- Middle: Activity feed + recommended connections (2-column)
- Bottom: Recent achievements carousel

### Admin Panel
**Sidebar Navigation**: 
- Users, Plans, Payments, Content, Settings, Logs
- Active state with left border accent

**Main Content**:
- Page header with title + primary action button
- Filter/search bar
- Data table with pagination
- Bulk action toolbar when items selected

### Blog
**List View**: Masonry grid (2-3 columns) with featured post hero at top

**Article Page**: 
- Full-width hero image
- Max-w-3xl content container
- Table of contents (sticky on desktop)
- Related articles at bottom

## Images

**Hero Images Needed**:
- Landing page hero: Diverse creators collaborating (1920x1080)
- About section: Team/community image (1200x800)
- Feature sections: Screenshots of platform UI (mockups acceptable initially)
- Blog featured images: Relevant to article topics (1200x630)
- Profile placeholders: Avatar fallbacks with initials

**Icons**: Use Heroicons (outline style) via CDN for consistency throughout

## Responsive Breakpoints
- Mobile: Default (320px+)
- Tablet: md: (768px+) - Stack cards, collapse sidebar
- Desktop: lg: (1024px+) - Full multi-column layouts
- Large: xl: (1280px+) - Max content width expansion

## Animations
**Minimal Motion**:
- Page transitions: Fade-in only (duration-200)
- Card hovers: Subtle lift (transform translateY(-2px))
- Button clicks: Scale feedback (scale-95)
- Stat updates: Number count-up animation
- Badge unlock: Single celebratory scale-in animation

**No**: Complex scroll animations, parallax effects, or continuous motion