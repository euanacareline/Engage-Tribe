import { sql } from "drizzle-orm";
import { pgTable, text, varchar, integer, timestamp, boolean, jsonb, index } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// Session storage table (required for Replit Auth)
export const sessions = pgTable(
  "sessions",
  {
    sid: varchar("sid").primaryKey(),
    sess: jsonb("sess").notNull(),
    expire: timestamp("expire").notNull(),
  },
  (table) => [index("IDX_session_expire").on(table.expire)],
);

// User storage table (required for Replit Auth + extended for platform)
export const users = pgTable("users", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  email: varchar("email").unique(),
  passwordHash: text("password_hash"),
  firstName: varchar("first_name"),
  lastName: varchar("last_name"),
  profileImageUrl: varchar("profile_image_url"),
  
  bio: text("bio"),
  location: text("location"),
  website: text("website"),
  niches: text("niches").array().default(sql`ARRAY[]::text[]`),
  
  stripeCustomerId: text("stripe_customer_id"),
  subscriptionStatus: text("subscription_status").default("free"),
  subscriptionPlan: text("subscription_plan").default("starter"),
  subscriptionEndsAt: timestamp("subscription_ends_at"),
  
  level: text("level").default("Iniciante").notNull(),
  points: integer("points").default(0).notNull(),
  totalPoints: integer("total_points").default(0).notNull(),
  dailyPointsUsed: integer("daily_points_used").default(0).notNull(),
  dailyPointsLimit: integer("daily_points_limit").default(50).notNull(),
  lastPointsReset: timestamp("last_points_reset").defaultNow(),
  
  tokensUsedToday: integer("tokens_used_today").default(0).notNull(),
  dailyTokenLimit: integer("daily_token_limit").default(5000).notNull(),
  lastTokenReset: timestamp("last_token_reset").defaultNow(),
  
  monthlyTokensUsed: integer("monthly_tokens_used").default(0).notNull(),
  monthlyTokenLimit: integer("monthly_token_limit").default(10000).notNull(),
  lastMonthlyTokenReset: timestamp("last_monthly_token_reset").defaultNow(),
  
  isAdmin: boolean("is_admin").default(false).notNull(),
  isActive: boolean("is_active").default(true).notNull(),
  
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

export const socialMetrics = pgTable("social_metrics", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").notNull().references(() => users.id, { onDelete: "cascade" }),
  platform: text("platform").notNull(),
  
  followers: integer("followers").default(0),
  views: integer("views").default(0),
  engagementRate: integer("engagement_rate").default(0),
  posts: integer("posts").default(0),
  
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

export const activities = pgTable("activities", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").notNull().references(() => users.id, { onDelete: "cascade" }),
  fromUserId: varchar("from_user_id").references(() => users.id, { onDelete: "cascade" }),
  
  type: text("type").notNull(),
  content: text("content").notNull(),
  points: integer("points").default(0).notNull(),
  
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const achievements = pgTable("achievements", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").notNull().references(() => users.id, { onDelete: "cascade" }),
  
  achievementKey: text("achievement_key").notNull(),
  title: text("title").notNull(),
  description: text("description").notNull(),
  unlockedAt: timestamp("unlocked_at").defaultNow().notNull(),
});

export const connections = pgTable("connections", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").notNull().references(() => users.id, { onDelete: "cascade" }),
  connectedUserId: varchar("connected_user_id").notNull().references(() => users.id, { onDelete: "cascade" }),
  
  matchScore: integer("match_score").default(0),
  status: text("status").default("pending").notNull(),
  
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const blogPosts = pgTable("blog_posts", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  authorId: varchar("author_id").notNull().references(() => users.id, { onDelete: "cascade" }),
  
  title: text("title").notNull(),
  slug: text("slug").notNull().unique(),
  excerpt: text("excerpt").notNull(),
  content: text("content").notNull(),
  coverImage: text("cover_image"),
  category: text("category").notNull(),
  readTime: text("read_time").notNull(),
  published: boolean("published").default(false).notNull(),
  
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

export const newsletterLeads = pgTable("newsletter_leads", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  email: varchar("email").notNull().unique(),
  source: text("source").default("blog").notNull(),
  subscribed: boolean("subscribed").default(true).notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const aiToolsUsage = pgTable("ai_tools_usage", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").notNull().references(() => users.id, { onDelete: "cascade" }),
  
  toolType: text("tool_type").notNull(),
  platform: text("platform").notNull(),
  inputData: jsonb("input_data").notNull(),
  outputData: jsonb("output_data").notNull(),
  
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

// Social accounts table - stores connected social media accounts
export const socialAccounts = pgTable("social_accounts", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").notNull().references(() => users.id, { onDelete: "cascade" }),
  
  platform: text("platform").notNull(), // facebook, instagram, youtube
  accountId: text("account_id").notNull(), // Platform-specific account ID
  accountName: text("account_name").notNull(), // Display name/username
  accessToken: text("access_token"), // Encrypted OAuth token
  refreshToken: text("refresh_token"), // Encrypted refresh token
  tokenExpiresAt: timestamp("token_expires_at"),
  
  isActive: boolean("is_active").default(true).notNull(),
  lastSyncAt: timestamp("last_sync_at"),
  
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

// Social posts table - stores posts pulled from social networks
export const socialPosts = pgTable("social_posts", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  socialAccountId: varchar("social_account_id").notNull().references(() => socialAccounts.id, { onDelete: "cascade" }),
  userId: varchar("user_id").notNull().references(() => users.id, { onDelete: "cascade" }),
  
  platform: text("platform").notNull(),
  postId: text("post_id").notNull(), // Platform-specific post ID
  postUrl: text("post_url"),
  caption: text("caption"),
  mediaType: text("media_type"), // photo, video, reel, etc
  
  likes: integer("likes").default(0),
  comments: integer("comments").default(0),
  shares: integer("shares").default(0),
  views: integer("views").default(0),
  
  aiAnalysis: jsonb("ai_analysis"), // OpenAI analysis results
  lastAnalyzedAt: timestamp("last_analyzed_at"),
  
  postedAt: timestamp("posted_at").notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

// Engagement actions table - tracks engagement exchange between users
export const engagementActions = pgTable("engagement_actions", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  fromUserId: varchar("from_user_id").notNull().references(() => users.id, { onDelete: "cascade" }),
  toUserId: varchar("to_user_id").notNull().references(() => users.id, { onDelete: "cascade" }),
  socialPostId: varchar("social_post_id").references(() => socialPosts.id, { onDelete: "set null" }),
  
  actionType: text("action_type").notNull(), // like, follow, comment, share, view
  platform: text("platform").notNull(),
  pointsCost: integer("points_cost").default(0).notNull(),
  pointsEarned: integer("points_earned").default(0).notNull(),
  
  status: text("status").default("pending").notNull(), // pending, completed, failed
  completedAt: timestamp("completed_at"),
  
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

// Point ledger table - normalized record of all point transactions
export const pointLedger = pgTable("point_ledger", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").notNull().references(() => users.id, { onDelete: "cascade" }),
  
  amount: integer("amount").notNull(), // positive for earnings, negative for spending
  balanceBefore: integer("balance_before").notNull(),
  balanceAfter: integer("balance_after").notNull(),
  
  transactionType: text("transaction_type").notNull(), // engagement_action, daily_reset, level_up, bonus
  referenceId: varchar("reference_id"), // ID of related record (engagement action, etc)
  description: text("description").notNull(),
  
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

// Token usage logs table - detailed tracking of OpenAI token consumption with annotations
export const tokenUsageLogs = pgTable("token_usage_logs", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").notNull().references(() => users.id, { onDelete: "cascade" }),
  
  tokensUsed: integer("tokens_used").notNull(),
  tokensBefore: integer("tokens_before").notNull(),
  tokensAfter: integer("tokens_after").notNull(),
  
  usageType: text("usage_type").notNull(), // blog_generation, ai_tools, image_generation, chatbot
  model: text("model"), // gpt-4, dall-e-3, etc
  feature: text("feature"), // youtube_ai, instagram_ai, blog_auto, customer_support
  
  inputText: text("input_text"), // What was sent to OpenAI
  outputText: text("output_text"), // What OpenAI returned
  
  notes: text("notes"), // Admin annotations/observations
  
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

// Staff roles table - for admin/employee management with different permissions
export const staffRoles = pgTable("staff_roles", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").notNull().unique().references(() => users.id, { onDelete: "cascade" }),
  
  role: text("role").notNull(), // admin, manager, support, content_creator, analyst
  department: text("department"), // tech, content, support, marketing, finance
  
  permissions: text("permissions").array().default(sql`ARRAY[]::text[]`), // manage_users, manage_content, view_analytics, manage_tokens, etc
  salary: integer("salary").default(0), // Monthly salary in cents (R$)
  
  hiredAt: timestamp("hired_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

// Salary history table - track salary changes over time
export const salaryHistory = pgTable("salary_history", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  staffRoleId: varchar("staff_role_id").notNull().references(() => staffRoles.id, { onDelete: "cascade" }),
  
  previousSalary: integer("previous_salary").notNull(),
  newSalary: integer("new_salary").notNull(),
  reason: text("reason"), // promotion, adjustment, performance, etc
  
  changedBy: varchar("changed_by").references(() => users.id), // Admin who made the change
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

// Timeclock table - track employee clock in/out records
export const timeclock = pgTable("timeclock", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").notNull().references(() => users.id, { onDelete: "cascade" }),
  
  clockType: text("clock_type").notNull(), // clock_in, clock_out, break_start, break_end
  timestamp: timestamp("timestamp").defaultNow().notNull(),
  location: text("location"), // Optional: IP address, geolocation, or location name
  notes: text("notes"), // Optional: admin or employee notes
  
  recordedBy: varchar("recorded_by").references(() => users.id), // Who recorded it (self or admin)
  isManual: boolean("is_manual").default(false).notNull(), // True if admin manually recorded
  
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export type UpsertUser = typeof users.$inferInsert;
export type User = typeof users.$inferSelect;

export const insertSocialMetricsSchema = createInsertSchema(socialMetrics).omit({
  id: true,
  updatedAt: true,
});

export const insertActivitySchema = createInsertSchema(activities).omit({
  id: true,
  createdAt: true,
});

export const insertAchievementSchema = createInsertSchema(achievements).omit({
  id: true,
  unlockedAt: true,
});

export const insertConnectionSchema = createInsertSchema(connections).omit({
  id: true,
  createdAt: true,
});

export const insertBlogPostSchema = createInsertSchema(blogPosts).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export const insertNewsletterLeadSchema = createInsertSchema(newsletterLeads).omit({
  id: true,
  createdAt: true,
});

export const insertAiToolsUsageSchema = createInsertSchema(aiToolsUsage).omit({
  id: true,
  createdAt: true,
});

export const insertSocialAccountSchema = createInsertSchema(socialAccounts).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export const insertSocialPostSchema = createInsertSchema(socialPosts).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export const insertEngagementActionSchema = createInsertSchema(engagementActions).omit({
  id: true,
  createdAt: true,
});

export const insertPointLedgerSchema = createInsertSchema(pointLedger).omit({
  id: true,
  createdAt: true,
});

export const insertTokenUsageLogSchema = createInsertSchema(tokenUsageLogs).omit({
  id: true,
  createdAt: true,
});

export const insertStaffRoleSchema = createInsertSchema(staffRoles).omit({
  id: true,
  hiredAt: true,
  updatedAt: true,
});

export const insertSalaryHistorySchema = createInsertSchema(salaryHistory).omit({
  id: true,
  createdAt: true,
});

export const insertTimeclockSchema = createInsertSchema(timeclock).omit({
  id: true,
  createdAt: true,
});

export type InsertSocialMetrics = z.infer<typeof insertSocialMetricsSchema>;
export type SocialMetrics = typeof socialMetrics.$inferSelect;
export type InsertActivity = z.infer<typeof insertActivitySchema>;
export type Activity = typeof activities.$inferSelect;
export type InsertAchievement = z.infer<typeof insertAchievementSchema>;
export type Achievement = typeof achievements.$inferSelect;
export type InsertConnection = z.infer<typeof insertConnectionSchema>;
export type Connection = typeof connections.$inferSelect;
export type InsertBlogPost = z.infer<typeof insertBlogPostSchema>;
export type BlogPost = typeof blogPosts.$inferSelect;
export type InsertNewsletterLead = z.infer<typeof insertNewsletterLeadSchema>;
export type NewsletterLead = typeof newsletterLeads.$inferSelect;
export type InsertAiToolsUsage = z.infer<typeof insertAiToolsUsageSchema>;
export type AiToolsUsage = typeof aiToolsUsage.$inferSelect;

export type InsertSocialAccount = z.infer<typeof insertSocialAccountSchema>;
export type SocialAccount = typeof socialAccounts.$inferSelect;
export type InsertSocialPost = z.infer<typeof insertSocialPostSchema>;
export type SocialPost = typeof socialPosts.$inferSelect;
export type InsertEngagementAction = z.infer<typeof insertEngagementActionSchema>;
export type EngagementAction = typeof engagementActions.$inferSelect;
export type InsertPointLedger = z.infer<typeof insertPointLedgerSchema>;
export type PointLedger = typeof pointLedger.$inferSelect;
export type InsertTokenUsageLog = z.infer<typeof insertTokenUsageLogSchema>;
export type TokenUsageLog = typeof tokenUsageLogs.$inferSelect;
export type InsertStaffRole = z.infer<typeof insertStaffRoleSchema>;
export type StaffRole = typeof staffRoles.$inferSelect;
export type InsertSalaryHistory = z.infer<typeof insertSalaryHistorySchema>;
export type SalaryHistory = typeof salaryHistory.$inferSelect;
export type InsertTimeclock = z.infer<typeof insertTimeclockSchema>;
export type Timeclock = typeof timeclock.$inferSelect;
